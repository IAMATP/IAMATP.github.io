/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class RenderSettings extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Icon", "./RenderSettings/costumes/Icon.svg", {
        x: 100,
        y: 110,
      }),
    ];

    this.sounds = [];

    this.triggers = [
      new Trigger(
        Trigger.BROADCAST,
        { name: "Init: Init Renderer" },
        this.whenIReceiveInitInitRenderer
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Init: Priority" },
        this.whenIReceiveInitPriority
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "System: Physics Tick" },
        this.whenIReceiveSystemPhysicsTick
      ),
    ];

    this.vars.TimeOffset = 8898.074542233797;
  }

  *whenIReceiveInitInitRenderer() {
    yield* this.setScaleTo(276);
    yield* this.setWireframeTo(0);
    yield* this.setOnlyRedrawOnUpdateNeededTo(0);
    yield* this.setStandardResolutionTo(4);
    yield* this.setRasterResolutionTo(6);
    yield* this.setShadowResolutionTo(8);
    yield* this.setFancyTranslucentSurfacesTo(0 === "");
    yield* this.setUseMaxDrawDistanceTo(0);
    yield* this.setMaxDrawDistanceTo(4000);
    yield* this.setUseTriangleScreenClippingTo(0 === "");
    yield* this.setBaseAmbientLightTo(0.3);
    yield* this.setDayAmbientLightContributionTo(1 / 3);
    yield* this.setSunDirectionalLightContributionTo(1 / 6);
    yield* this.setMoonDirectionalLightContributionTo(1 / 12);
    yield* this.setDrawShadowsTo(0 === "");
    yield* this.setShadowLightSourceTo(0);
    yield* this.setUseShadowCullingTo(0 === "");
    yield* this.setDrawSkyTo(0 === "");
    yield* this.setDrawGroundTo(0 === "");
    yield* this.setDrawBackgroundObjectsTo(0 === "");
    yield* this.setStarCountTo(100);
    yield* this.setGroundColorToRGB(77, 189, 51);
    yield* this.setSkyLightColorToRGB(181, 255, 255);
    yield* this.setSkyDarkColorToRGB(19, 80, 134);
    yield* this.setSunColorTo("0x" + "ECE9AF");
    yield* this.setMoonColorTo("0x" + "ECEDEE");
    yield* this.setStarColorTo("0x" + "FFFFFF");
  }

  *setGroundColorTo(color) {
    yield* this.setGroundColorToRGB(
      Math.floor(this.toNumber(color) / 65536),
      Math.floor(this.toNumber(color) / 256) % 256,
      Math.floor(this.toNumber(color) % 256)
    );
  }

  *setGroundColorToRGB(r, g, b) {
    this.stage.vars.renderSettings.splice(16, 1, Math.floor(this.toNumber(r)));
    this.stage.vars.renderSettings.splice(17, 1, Math.floor(this.toNumber(g)));
    this.stage.vars.renderSettings.splice(18, 1, Math.floor(this.toNumber(b)));
  }

  *setSkyLightColorTo(color) {
    yield* this.setSkyLightColorToRGB(
      Math.floor(this.toNumber(color) / 65536),
      Math.floor(this.toNumber(color) / 256) % 256,
      Math.floor(this.toNumber(color) % 256)
    );
  }

  *setSkyLightColorToRGB(r, g, b) {
    this.stage.vars.renderSettings.splice(19, 1, Math.floor(this.toNumber(r)));
    this.stage.vars.renderSettings.splice(20, 1, Math.floor(this.toNumber(g)));
    this.stage.vars.renderSettings.splice(21, 1, Math.floor(this.toNumber(b)));
    yield* this.intUpdateSkyColorDiff();
  }

  *setSkyDarkColorTo(color) {
    yield* this.setSkyDarkColorToRGB(
      Math.floor(this.toNumber(color) / 65536),
      Math.floor(this.toNumber(color) / 256) % 256,
      Math.floor(this.toNumber(color) % 256)
    );
  }

  *setSkyDarkColorToRGB(r, g, b) {
    this.stage.vars.renderSettings.splice(22, 1, Math.floor(this.toNumber(r)));
    this.stage.vars.renderSettings.splice(23, 1, Math.floor(this.toNumber(g)));
    this.stage.vars.renderSettings.splice(24, 1, Math.floor(this.toNumber(b)));
    yield* this.intUpdateSkyColorDiff();
  }

  *intUpdateSkyColorDiff() {
    this.stage.vars.renderSettings.splice(
      25,
      1,
      this.toNumber(this.itemOf(this.stage.vars.renderSettings, 22)) -
        this.toNumber(this.itemOf(this.stage.vars.renderSettings, 19))
    );
    this.stage.vars.renderSettings.splice(
      26,
      1,
      this.toNumber(this.itemOf(this.stage.vars.renderSettings, 23)) -
        this.toNumber(this.itemOf(this.stage.vars.renderSettings, 20))
    );
    this.stage.vars.renderSettings.splice(
      27,
      1,
      this.toNumber(this.itemOf(this.stage.vars.renderSettings, 24)) -
        this.toNumber(this.itemOf(this.stage.vars.renderSettings, 21))
    );
  }

  *setSunColorTo(color) {
    this.stage.vars.renderSettings.splice(28, 1, this.toNumber(color) + 0);
  }

  *setSunColorToRGB(r, g, b) {
    yield* this.setSunColorTo(
      Math.floor(this.toNumber(r)) * 65536 +
        Math.floor(this.toNumber(g)) * 256 +
        Math.floor(this.toNumber(b))
    );
  }

  *setMoonColorTo(color) {
    this.stage.vars.renderSettings.splice(29, 1, this.toNumber(color) + 0);
  }

  *setMoonColorToRGB(r, g, b) {
    yield* this.setMoonColorTo(
      Math.floor(this.toNumber(r)) * 65536 +
        Math.floor(this.toNumber(g)) * 256 +
        Math.floor(this.toNumber(b))
    );
  }

  *setStarColorTo(color) {
    this.stage.vars.renderSettings.splice(30, 1, this.toNumber(color) + 0);
  }

  *setStarColorToRGB(r, g, b) {
    yield* this.setStarColorTo(
      Math.floor(this.toNumber(r)) * 65536 +
        Math.floor(this.toNumber(g)) * 256 +
        Math.floor(this.toNumber(b))
    );
  }

  *whenIReceiveInitPriority() {
    this.vars.TimeOffset =
      ((new Date().getTime() - new Date(2000, 0, 1)) / 1000 / 60 +
        new Date().getTimezoneOffset()) /
      60 /
      24;
  }

  *setScaleTo(value) {
    this.stage.vars.renderSettings.splice(0, 1, value);
  }

  *setWireframeTo(value) {
    this.stage.vars.renderSettings.splice(31, 1, this.toNumber(value) + 0);
  }

  *setStandardResolutionTo(value) {
    this.stage.vars.renderSettings.splice(1, 1, value);
  }

  *setRasterResolutionTo(value) {
    this.stage.vars.renderSettings.splice(2, 1, value);
  }

  *setShadowResolutionTo(value) {
    this.stage.vars.renderSettings.splice(3, 1, value);
  }

  *setUseMaxDrawDistanceTo(value) {
    this.stage.vars.renderSettings.splice(33, 1, this.toNumber(value) + 0);
  }

  *setMaxDrawDistanceTo(value) {
    this.stage.vars.renderSettings.splice(34, 1, value);
  }

  *setFancyTranslucentSurfacesTo(value) {
    this.stage.vars.renderSettings.splice(4, 1, this.toNumber(value) + 0);
  }

  *setUseTriangleScreenClippingTo(value) {
    this.stage.vars.renderSettings.splice(32, 1, this.toNumber(value) + 0);
  }

  *setBaseAmbientLightTo(value) {
    this.stage.vars.renderSettings.splice(5, 1, value);
  }

  *setDayAmbientLightContributionTo(value) {
    this.stage.vars.renderSettings.splice(6, 1, value);
  }

  *setSunDirectionalLightContributionTo(value) {
    this.stage.vars.renderSettings.splice(7, 1, value);
  }

  *setMoonDirectionalLightContributionTo(value) {
    this.stage.vars.renderSettings.splice(8, 1, value);
  }

  *setDrawShadowsTo(value) {
    this.stage.vars.renderSettings.splice(9, 1, this.toNumber(value) + 0);
  }

  *setShadowLightSourceTo(value) {
    this.stage.vars.renderSettings.splice(10, 1, this.toNumber(value) + 1);
  }

  *setUseShadowCullingTo(value) {
    this.stage.vars.renderSettings.splice(11, 1, this.toNumber(value) + 0);
  }

  *setDrawSkyTo(value) {
    this.stage.vars.renderSettings.splice(12, 1, this.toNumber(value) + 0);
  }

  *setDrawGroundTo(value) {
    this.stage.vars.renderSettings.splice(13, 1, this.toNumber(value) + 0);
  }

  *setDrawBackgroundObjectsTo(value) {
    this.stage.vars.renderSettings.splice(14, 1, this.toNumber(value) + 0);
  }

  *setStarCountTo(value) {
    this.stage.vars.renderSettings.splice(15, 1, value);
  }

  *showSettingLabels() {
    this.stage.vars.renderSettings = [];
    this.stage.vars.renderSettings.push("Scale");
    this.stage.vars.renderSettings.push("Standard Resolution");
    this.stage.vars.renderSettings.push("Raster Resolution");
    this.stage.vars.renderSettings.push("Shadow Resolution");
    this.stage.vars.renderSettings.push("Use Fancy Translucent Surfaces");
    this.stage.vars.renderSettings.push("Base Ambient Light");
    this.stage.vars.renderSettings.push("Day Ambient Light Contribution");
    this.stage.vars.renderSettings.push("Sun Directional Light Contribution");
    this.stage.vars.renderSettings.push("Moon Directional Light Contribution");
    this.stage.vars.renderSettings.push("Draw Shadows");
    this.stage.vars.renderSettings.push("Shadow Light Source");
    this.stage.vars.renderSettings.push("Use Shadow Culling");
    this.stage.vars.renderSettings.push("Draw Sky");
    this.stage.vars.renderSettings.push("Draw Ground");
    this.stage.vars.renderSettings.push("Draw Background Objects");
    this.stage.vars.renderSettings.push("Star Count");
    this.stage.vars.renderSettings.push("Ground Color: R");
    this.stage.vars.renderSettings.push("Ground Color: G");
    this.stage.vars.renderSettings.push("Ground Color: B");
    this.stage.vars.renderSettings.push("Sky Light Color: R");
    this.stage.vars.renderSettings.push("Sky Light Color: G");
    this.stage.vars.renderSettings.push("Sky Light Color: B");
    this.stage.vars.renderSettings.push("Sky Dark Color: R");
    this.stage.vars.renderSettings.push("Sky Dark Color: G");
    this.stage.vars.renderSettings.push("Sky Dark Color: B");
    this.stage.vars.renderSettings.push("Sky Color Diff: R");
    this.stage.vars.renderSettings.push("Sky Color Diff: G");
    this.stage.vars.renderSettings.push("Sky Color Diff: B");
    this.stage.vars.renderSettings.push("Sun Color");
    this.stage.vars.renderSettings.push("Moon Color");
    this.stage.vars.renderSettings.push("Star Color");
    this.stage.vars.renderSettings.push("Wireframe");
    this.stage.vars.renderSettings.push("Use Triangle Screen Clipping");
    this.stage.vars.renderSettings.push("Use Max Draw Distance");
    this.stage.vars.renderSettings.push("Max Draw Distance");
    this.stage.vars.renderSettings.push("Only Redraw on Update Needed");
    this.stage.watchers.renderSettings.visible = true;
    /* TODO: Implement stop all */ null;
  }

  *whenIReceiveSystemPhysicsTick() {
    this.stage.vars.time =
      ((((new Date().getTime() - new Date(2000, 0, 1)) / 1000 / 60 +
        new Date().getTimezoneOffset()) /
        60 /
        24 -
        this.toNumber(this.vars.TimeOffset)) *
        86400 +
        320) %
      360;
  }

  *setOnlyRedrawOnUpdateNeededTo(value) {
    this.stage.vars.renderSettings.splice(35, 1, this.toNumber(value) + 0);
  }
}
