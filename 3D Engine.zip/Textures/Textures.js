/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Textures extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("icon", "./Textures/costumes/icon.svg", { x: 184, y: 134 }),
    ];

    this.sounds = [];

    this.triggers = [
      new Trigger(
        Trigger.BROADCAST,
        { name: "Init: Create Textures" },
        this.whenIReceiveInitCreateTextures
      ),
    ];

    this.vars.Return = 0;
    this.vars.R = 0;
    this.vars.G = 0;
    this.vars.B = 0;
    this.vars.Temp2 = 1;
  }

  *clearTextures() {
    this.stage.vars.texturesR = [];
    this.stage.vars.texturesG = [];
    this.stage.vars.texturesB = [];
    this.stage.vars.texturesA = [];
    this.stage.vars.texturesSoundStart = [];
    this.stage.vars.texturesSoundEnd = [];
  }

  *intGetRgb(hue, sat, lum) {
    if (this.toNumber(sat) === 0) {
      this.vars.R = this.toNumber(lum) * 255;
      this.vars.G = this.toNumber(lum) * 255;
      this.vars.B = this.toNumber(lum) * 255;
    } else {
      if (this.compare(lum, 0.5) < 0) {
        this.vars.Temp2 = this.toNumber(lum) * (1 + this.toNumber(sat));
      } else {
        this.vars.Temp2 =
          this.toNumber(lum) +
          this.toNumber(sat) -
          this.toNumber(sat) * this.toNumber(lum);
      }
      yield* this.intHueToRgb(
        this.vars.undefined,
        this.vars.Temp2,
        (this.toNumber(hue) + 0.33333) % 1
      );
      this.vars.R = this.toNumber(this.vars.Return) * 255;
      yield* this.intHueToRgb(
        this.vars.undefined,
        this.vars.Temp2,
        this.toNumber(hue) % 1
      );
      this.vars.G = this.toNumber(this.vars.Return) * 255;
      yield* this.intHueToRgb(
        this.vars.undefined,
        this.vars.Temp2,
        (this.toNumber(hue) - 0.33333) % 1
      );
      this.vars.B = this.toNumber(this.vars.Return) * 255;
    }
  }

  *intHueToRgb(v1, v2, vh) {
    if (this.compare(this.toNumber(vh) * 6, 1) < 0) {
      this.vars.Return =
        (this.toNumber(v1) + (this.toNumber(v2) - this.toNumber(v1))) *
        6 *
        this.toNumber(vh);
    } else {
      if (this.compare(this.toNumber(vh) * 2, 1) < 0) {
        this.vars.Return = v2;
      } else {
        if (this.compare(this.toNumber(vh) * 3, 2) < 0) {
          this.vars.Return =
            (this.toNumber(v1) + (this.toNumber(v2) - this.toNumber(v1))) *
            (0.66666 - this.toNumber(vh)) *
            6;
        } else {
          this.vars.Return = v1;
        }
      }
    }
  }

  *addTextureRGBAFirstStepSoundLastStepSound(r, g, b, a, soundStart, soundEnd) {
    if (this.toNumber(a) === 255) {
      this.stage.vars.texturesA.push(0);
    } else {
      this.stage.vars.texturesA.push(a);
    }
    this.stage.vars.texturesR.push(r);
    this.stage.vars.texturesG.push(g);
    this.stage.vars.texturesB.push(b);
    this.stage.vars.texturesSoundStart.push(soundStart);
    this.stage.vars.texturesSoundEnd.push(soundEnd);
  }

  *addTextureStepSoundStartStepSoundEnd(color, soundStart, soundEnd) {
    yield* this.addTextureRGBAFirstStepSoundLastStepSound(
      Math.floor((this.toNumber(color) / 65536) % 256),
      Math.floor((this.toNumber(color) / 256) % 256),
      Math.floor(this.toNumber(color) % 256),
      Math.floor(this.toNumber(color) / 16777216),
      soundStart,
      soundEnd
    );
  }

  *addTextureHSLAStepSoundStartStepSoundEnd(h, s, l, a, soundStart, soundEnd) {
    yield* this.intGetRgb(h, s, l);
    yield* this.addTextureRGBAFirstStepSoundLastStepSound(
      this.vars.R,
      this.vars.G,
      this.vars.B,
      a,
      soundStart,
      soundEnd
    );
  }

  *addTextureRGBA(r, g, b, a) {
    yield* this.addTextureRGBAFirstStepSoundLastStepSound(r, g, b, a, -1, -1);
  }

  *addTexture(color) {
    yield* this.addTextureStepSoundStartStepSoundEnd(color, -1, -1);
  }

  *addTextureHSLA(h, s, l, a) {
    yield* this.addTextureHSLAStepSoundStartStepSoundEnd(h, s, l, a, -1, -1);
  }

  *whenIReceiveInitCreateTextures() {
    yield* this.clearTextures();
    yield* this.addTextureRGBA(242, 242, 242, 0);
    yield* this.addTextureRGBA(115, 77, 38, 0);
    yield* this.addTextureRGBA(255, 173, 51, 0);
    yield* this.addTextureRGBAFirstStepSoundLastStepSound(
      153,
      102,
      51,
      0,
      9,
      12
    );
    yield* this.addTextureRGBA(255, 83, 26, 0);
    yield* this.addTextureRGBA(102, 255, 255, 40);
    yield* this.addTextureRGBA(240, 206, 168, 0);
    yield* this.addTextureRGBAFirstStepSoundLastStepSound(
      0,
      102,
      153,
      0,
      13,
      16
    );
    yield* this.addTextureRGBA(220, 220, 220, 0);
    yield* this.addTextureRGBA(255, 173, 51, 0);
    yield* this.addTextureRGBA(153, 102, 51, 0);
    yield* this.addTextureRGBA(0, 160, 0, 0);
    yield* this.addTextureRGBAFirstStepSoundLastStepSound(
      180,
      180,
      180,
      0,
      5,
      8
    );
    yield* this.addTextureRGBAFirstStepSoundLastStepSound(
      230,
      230,
      230,
      0,
      9,
      12
    );
    yield* this.addTextureRGBA(60, 60, 60, 0);
    yield* this.addTextureRGBA(220, 220, 220, 0);
  }

  *whenbackdropswitchesto() {
    yield* this.clearTextures();
  }
}
