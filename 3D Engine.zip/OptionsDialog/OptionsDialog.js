/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class OptionsDialog extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("icon", "./OptionsDialog/costumes/icon.svg", {
        x: 173,
        y: 140,
      }),
      new Costume("Options", "./OptionsDialog/costumes/Options.svg", {
        x: 240,
        y: 180,
      }),
      new Costume("Cross", "./OptionsDialog/costumes/Cross.svg", {
        x: 91,
        y: 170,
      }),
      new Costume("FOV", "./OptionsDialog/costumes/FOV.svg", {
        x: 145.36449,
        y: 92.304,
      }),
      new Costume("Res", "./OptionsDialog/costumes/Res.svg", {
        x: 145.31449,
        y: 29.204000000000008,
      }),
      new Costume("Background", "./OptionsDialog/costumes/Background.svg", {
        x: 225.3868,
        y: -35.778999999999996,
      }),
      new Costume("Shadows", "./OptionsDialog/costumes/Shadows.svg", {
        x: 226,
        y: -93,
      }),
      new Costume("Lineframe", "./OptionsDialog/costumes/Lineframe.svg", {
        x: 226,
        y: -150,
      }),
    ];

    this.sounds = [];

    this.triggers = [
      new Trigger(
        Trigger.BROADCAST,
        { name: "init: misc" },
        this.whenIReceiveInitMisc
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "game: show options" },
        this.whenIReceiveGameShowOptions
      ),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(
        Trigger.BROADCAST,
        { name: "game: close options" },
        this.whenIReceiveGameCloseOptions
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "system: physics tick" },
        this.whenIReceiveSystemPhysicsTick
      ),
    ];

    this.vars.CloneId = -1;
    this.vars.Action = 0;
    this.vars.OptionsOpen = 0;
    this.vars.Temp = 0;
    this.vars.MouseOver = 0;
    this.vars.ActionStart = 193.179;
  }

  *whenIReceiveInitMisc() {
    this.vars.CloneId = -1;
    this.vars.Action = 0;
    this.vars.OptionsOpen = 0;
    this.goto(-192, 0);
    this.visible = false;
  }

  *whenIReceiveGameShowOptions() {
    if (this.toNumber(this.vars.OptionsOpen) === 0) {
      this.vars.OptionsOpen = 1;
      this.vars.CloneId = 1;
      for (let i = 0; i < 7; i++) {
        this.createClone();
        this.vars.CloneId++;
        yield;
      }
      this.vars.CloneId = -1;
    }
  }

  *startAsClone() {
    this.costume = this.toNumber(this.vars.CloneId) + 1;
    if (this.toNumber(this.vars.CloneId) === 1) {
      this.visible = true;
      this.stage.vars.TimeOffset = this.timer;
      while (
        !(
          this.compare(
            this.timer - this.toNumber(this.stage.vars.TimeOffset),
            0.4
          ) > 0
        )
      ) {
        this.x =
          -192 +
          -192 *
            (((this.timer - this.toNumber(this.stage.vars.TimeOffset)) / 0.4) *
              ((this.timer - this.toNumber(this.stage.vars.TimeOffset)) / 0.4 -
                2));
        yield;
      }
      this.x = 0;
    } else {
      if (this.toNumber(this.vars.CloneId) === 2) {
        this.x = 0;
      } else {
        if (this.toNumber(this.vars.CloneId) === 3) {
          this.x =
            (this.radToDeg(
              Math.atan(
                240 /
                  this.toNumber(this.itemOf(this.stage.vars.renderSettings, 0))
              )
            ) *
              2 -
              90) *
            2;
        } else {
          if (this.toNumber(this.vars.CloneId) === 4) {
            this.x =
              (4 -
                this.toNumber(this.itemOf(this.stage.vars.renderSettings, 1))) *
              26.6666;
          } else {
            if (this.toNumber(this.vars.CloneId) === 5) {
              this.x =
                this.toNumber(this.itemOf(this.stage.vars.renderSettings, 14)) *
                26;
            } else {
              if (this.toNumber(this.vars.CloneId) === 6) {
                this.x =
                  this.toNumber(
                    this.itemOf(this.stage.vars.renderSettings, 9)
                  ) * 26;
              } else {
                if (this.toNumber(this.vars.CloneId) === 7) {
                  this.x =
                    this.toNumber(
                      this.itemOf(this.stage.vars.renderSettings, 31)
                    ) * 26;
                } else {
                  null;
                }
              }
            }
          }
        }
      }
      yield* this.wait(0.4);
      this.visible = true;
    }
  }

  *whenIReceiveGameCloseOptions() {
    this.vars.OptionsOpen = 0;
    if (this.toNumber(this.vars.CloneId) === 1) {
      this.stage.vars.TimeOffset = this.timer;
      while (
        !(
          this.compare(
            this.timer - this.toNumber(this.stage.vars.TimeOffset),
            0.4
          ) > 0
        )
      ) {
        this.x =
          -192 *
          Math.E **
            (2 *
              Math.log(
                (this.timer - this.toNumber(this.stage.vars.TimeOffset)) / 0.4
              ));
        yield;
      }
    }
    this.deleteThisClone();
  }

  *whenIReceiveSystemPhysicsTick() {
    if (this.toNumber(this.vars.CloneId) === 2) {
      if (this.toNumber(this.vars.Action) === 0) {
        if (
          this.compare(this.mouse.x, -90) > 0 &&
          this.compare(this.mouse.x, -62) < 0 &&
          this.compare(this.mouse.y, 140) > 0 &&
          this.compare(this.mouse.y, 169) < 0
        ) {
          if (this.toNumber(this.vars.MouseOver) === 0) {
            this.vars.Action = 1;
            this.vars.ActionStart = this.timer;
          }
          if (this.mouse.down) {
            this.broadcast("game: close options");
          }
        } else {
          if (this.toNumber(this.vars.MouseOver) === 1) {
            this.vars.MouseOver = 0;
            this.vars.Action = 2;
            this.vars.ActionStart = this.timer;
          }
        }
      } else {
        if (this.toNumber(this.vars.Action) === 1) {
          if (
            this.compare(
              this.timer - this.toNumber(this.vars.ActionStart),
              0.2
            ) < 0
          ) {
            this.effects.brightness =
              100 *
              Math.E **
                (2 *
                  Math.log(
                    (this.timer - this.toNumber(this.vars.ActionStart)) / 0.2
                  ));
          } else {
            this.effects.brightness = 100;
            this.vars.MouseOver = 1;
            this.vars.Action = 0;
          }
        } else {
          if (
            this.compare(
              this.timer - this.toNumber(this.vars.ActionStart),
              0.2
            ) < 0
          ) {
            this.effects.brightness =
              100 -
              100 *
                Math.E **
                  (2 *
                    Math.log(
                      (this.timer - this.toNumber(this.vars.ActionStart)) / 0.2
                    ));
          } else {
            this.effects.brightness = 0;
            this.vars.Action = 0;
          }
        }
      }
    } else {
      if (this.toNumber(this.vars.CloneId) === 3) {
        if (this.toNumber(this.vars.Action) === 0) {
          if (this.touching("mouse") && this.mouse.down) {
            this.vars.Action = 1;
          }
        } else {
          if (this.mouse.down) {
            if (this.compare(this.mouse.x, -226) > 0) {
              if (this.compare(this.mouse.x, -66) < 0) {
                this.x = this.mouse.x + 146;
              } else {
                this.x = 80;
              }
            } else {
              this.x = -80;
            }
            this.stage.vars.renderSettings.splice(
              0,
              1,
              240 / this.scratchTan((this.x / 2 + 90) / 2)
            );
            this.stage.vars.updateNeeded = 1;
          } else {
            this.vars.Action = 0;
          }
        }
      } else {
        if (this.toNumber(this.vars.CloneId) === 4) {
          if (this.toNumber(this.vars.Action) === 0) {
            if (this.touching("mouse") && this.mouse.down) {
              this.vars.Action = 1;
            }
          } else {
            if (this.mouse.down) {
              if (this.compare(this.mouse.x, -226) > 0) {
                if (this.compare(this.mouse.x, -66) < 0) {
                  this.x = this.mouse.x + 146;
                } else {
                  this.x = 80;
                }
              } else {
                this.x = -80;
              }
              this.vars.Temp = Math.round(4 - this.x / 26.6666);
              this.stage.vars.renderSettings.splice(1, 1, this.vars.Temp);
              this.stage.vars.renderSettings.splice(
                2,
                1,
                Math.floor(this.toNumber(this.vars.Temp) * 1.5)
              );
              this.stage.vars.renderSettings.splice(
                3,
                1,
                this.toNumber(this.vars.Temp) * 2
              );
            } else {
              this.x =
                (4 -
                  this.toNumber(
                    this.itemOf(this.stage.vars.renderSettings, 1)
                  )) *
                26.6666;
              this.vars.Action = 0;
            }
          }
        } else {
          if (this.toNumber(this.vars.CloneId) === 5) {
            if (this.toNumber(this.vars.Action) === 0) {
              if (this.touching("mouse") && this.mouse.down) {
                this.vars.Action = 1;
              }
            } else {
              if (this.mouse.down) {
                if (this.compare(this.mouse.x, -220) > 0) {
                  if (this.compare(this.mouse.x, -194) < 0) {
                    this.x = this.mouse.x + 220;
                  } else {
                    this.x = 26;
                  }
                } else {
                  this.x = 0;
                }
                this.stage.vars.renderSettings.splice(
                  14,
                  1,
                  Math.round(this.x / 26)
                );
              } else {
                this.x =
                  this.toNumber(
                    this.itemOf(this.stage.vars.renderSettings, 14)
                  ) * 26;
                this.vars.Action = 0;
              }
            }
          } else {
            if (this.toNumber(this.vars.CloneId) === 6) {
              if (this.toNumber(this.vars.Action) === 0) {
                if (this.touching("mouse") && this.mouse.down) {
                  this.vars.Action = 1;
                }
              } else {
                if (this.mouse.down) {
                  if (this.compare(this.mouse.x, -220) > 0) {
                    if (this.compare(this.mouse.x, -194) < 0) {
                      this.x = this.mouse.x + 220;
                    } else {
                      this.x = 26;
                    }
                  } else {
                    this.x = 0;
                  }
                  this.stage.vars.renderSettings.splice(
                    9,
                    1,
                    Math.round(this.x / 26)
                  );
                } else {
                  this.x =
                    this.toNumber(
                      this.itemOf(this.stage.vars.renderSettings, 9)
                    ) * 26;
                  this.vars.Action = 0;
                }
              }
            } else {
              if (this.toNumber(this.vars.CloneId) === 7) {
                if (this.toNumber(this.vars.Action) === 0) {
                  if (this.touching("mouse") && this.mouse.down) {
                    this.vars.Action = 1;
                  }
                } else {
                  if (this.mouse.down) {
                    if (this.compare(this.mouse.x, -220) > 0) {
                      if (this.compare(this.mouse.x, -194) < 0) {
                        this.x = this.mouse.x + 220;
                      } else {
                        this.x = 26;
                      }
                    } else {
                      this.x = 0;
                    }
                    this.stage.vars.renderSettings.splice(
                      31,
                      1,
                      Math.round(this.x / 26)
                    );
                  } else {
                    this.x =
                      this.toNumber(
                        this.itemOf(this.stage.vars.renderSettings, 31)
                      ) * 26;
                    this.vars.Action = 0;
                  }
                }
              } else {
                null;
              }
            }
          }
        }
      }
    }
  }
}
