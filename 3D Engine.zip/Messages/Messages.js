/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Messages extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Arrow Controls", "./Messages/costumes/Arrow Controls.svg", {
        x: 163.23924527999998,
        y: -97.74475472,
      }),
      new Costume("Mouse Controls", "./Messages/costumes/Mouse Controls.svg", {
        x: 164,
        y: -97,
      }),
      new Costume("Press E", "./Messages/costumes/Press E.svg", {
        x: 44,
        y: -141,
      }),
    ];

    this.sounds = [];

    this.triggers = [
      new Trigger(
        Trigger.BROADCAST,
        { name: "init: misc" },
        this.whenIReceiveInitMisc
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "system: render tick" },
        this.whenIReceiveSystemRenderTick
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "game: display controls" },
        this.whenIReceiveGameDisplayControls
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "system: physics tick" },
        this.whenIReceiveSystemPhysicsTick
      ),
    ];

    this.vars.Action = 0;
    this.vars.ActionStart = 0;
    this.vars.Visible = 1;
    this.vars.DoorDistance = 574.8260606479146;
    this.vars.ControlsDisplayDone = 0;
  }

  *whenIReceiveInitMisc() {
    this.vars.Visible = 0;
    this.goto(0, 0);
    yield* this.broadcastAndWait("game: display controls");
  }

  *whenIReceiveSystemRenderTick() {
    if (
      this.toNumber(this.vars.Action) === 0 &&
      this.toNumber(this.vars.ControlsDisplayDone) === 0 &&
      this.compare(this.costumeNumber, 3) < 0 &&
      this.toNumber(this.stage.vars.updateNeeded) === 1
    ) {
      this.vars.ControlsDisplayDone = 1;
      this.vars.Action = 2;
      this.vars.ActionStart = this.timer;
    }
  }

  *whenIReceiveGameDisplayControls() {
    this.costume = 1 - this.toNumber(this.stage.vars.defaultControls) + 1;
    this.effects.ghost = 100;
    this.visible = true;
    this.vars.Action = 1;
    this.vars.ActionStart = this.timer;
    this.vars.ControlsDisplayDone = 0;
  }

  *whenIReceiveSystemPhysicsTick() {
    this.vars.DoorDistance = Math.sqrt(
      (this.toNumber(this.stage.vars.cameraX) - 285) *
        (this.toNumber(this.stage.vars.cameraX) - 285) +
        this.toNumber(this.stage.vars.cameraZ) *
          this.toNumber(this.stage.vars.cameraZ)
    );
    if (this.toNumber(this.vars.Action) === 0) {
      if (this.compare(this.vars.DoorDistance, 200) < 0) {
        if (this.toNumber(this.vars.Visible) === 0) {
          this.vars.Action = 1;
          this.vars.ActionStart = this.timer;
          this.costume = "Press E";
          this.effects.ghost = 100;
          this.visible = true;
        }
      } else {
        if (
          this.toNumber(this.vars.Visible) === 1 &&
          this.compare(this.costumeNumber, 2) > 0
        ) {
          this.vars.Action = 2;
          this.vars.ActionStart = this.timer;
        }
      }
    } else {
      if (this.toNumber(this.vars.Action) === 1) {
        if (
          this.compare(this.timer - this.toNumber(this.vars.ActionStart), 0.3) <
          0
        ) {
          this.effects.ghost =
            100 -
            100 *
              Math.E **
                (2 *
                  Math.log(
                    (this.timer - this.toNumber(this.vars.ActionStart)) / 0.3
                  ));
        } else {
          this.effects.ghost = 0;
          this.vars.Visible = 1;
          this.vars.Action = 0;
          this.vars.ActionStart = 0;
        }
      } else {
        if (
          this.compare(this.timer - this.toNumber(this.vars.ActionStart), 0.3) <
          0
        ) {
          this.effects.ghost =
            100 *
            Math.E **
              (2 *
                Math.log(
                  (this.timer - this.toNumber(this.vars.ActionStart)) / 0.3
                ));
        } else {
          this.visible = false;
          this.vars.Visible = 0;
          this.vars.Action = 0;
          this.vars.ActionStart = 0;
        }
      }
    }
  }

  *whenbackdropswitchesto() {
    this.visible = false;
  }
}
