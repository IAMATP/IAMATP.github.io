/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Controller extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("icon", "./Controller/costumes/icon.svg", { x: 147, y: 115 }),
    ];

    this.sounds = [
      new Sound("Bay of Hope", "./Controller/sounds/Bay of Hope.wav"),
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "System: Init" },
        this.whenIReceiveSystemInit
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "System: Start Tick Cycle" },
        this.whenIReceiveSystemStartTickCycle
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Init: Misc" },
        this.whenIReceiveInitMisc
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "System: Loaded" },
        this.whenIReceiveSystemLoaded
      ),
      new Trigger(Trigger.KEY_PRESSED, { key: "o" }, this.whenKeyOPressed),
      new Trigger(Trigger.KEY_PRESSED, { key: "f" }, this.whenKeyFPressed),
      new Trigger(Trigger.KEY_PRESSED, { key: "m" }, this.whenKeyMPressed),
      new Trigger(Trigger.KEY_PRESSED, { key: "p" }, this.whenKeyPPressed),
    ];

    this.vars.FrameStart = 8898.074559780092;
    this.vars.ShowFps = 0;
  }

  *whenGreenFlagClicked() {
    this.stage.costume = "Main";
    this.clearPen();
    yield* this.broadcastAndWait("System: Init");
    this.broadcast("System: Start Tick Cycle");
  }

  *whenIReceiveSystemInit() {
    yield* this.broadcastAndWait("Init: Priority");
    yield* this.broadcastAndWait("Init: Misc");
    yield* this.broadcastAndWait("Init: Create Textures");
    yield* this.broadcastAndWait("Init: Create Light Sources");
    yield* this.broadcastAndWait("Init: Create Objects");
    yield* this.broadcastAndWait("Init: Create Collisions");
    yield* this.broadcastAndWait("Init: Create Sounds");
    yield* this.broadcastAndWait("Init: Setup Camera");
    yield* this.broadcastAndWait("Init: Init Renderer");
    yield* this.broadcastAndWait("Init: Final");
    yield* this.wait(0);
    this.broadcast("System: Loaded");
  }

  *whenIReceiveSystemStartTickCycle() {
    this.vars.FrameStart =
      ((new Date().getTime() - new Date(2000, 0, 1)) / 1000 / 60 +
        new Date().getTimezoneOffset()) /
      60 /
      24;
    while (true) {
      this.stage.vars.deltaTime =
        (((new Date().getTime() - new Date(2000, 0, 1)) / 1000 / 60 +
          new Date().getTimezoneOffset()) /
          60 /
          24 -
          this.toNumber(this.vars.FrameStart)) *
        86400;
      this.stage.vars.fps = 1 / this.toNumber(this.stage.vars.deltaTime);
      this.vars.FrameStart =
        ((new Date().getTime() - new Date(2000, 0, 1)) / 1000 / 60 +
          new Date().getTimezoneOffset()) /
        60 /
        24;
      yield* this.broadcastAndWait("System: Physics Tick");
      yield* this.broadcastAndWait("System: Render Tick");
      if (this.toNumber(this.stage.vars.paused) === 1) {
        while (!(this.toNumber(this.stage.vars.paused) === 0)) {
          yield;
        }
      }
      yield;
    }
  }

  *whenIReceiveInitMisc() {
    this.vars.ShowFps = 0;
    this.stage.vars.paused = 0;
    this.stage.watchers.fps.visible = false;
  }

  *whenIReceiveSystemLoaded() {
    while (true) {
      yield* this.playSoundUntilDone("Bay of Hope");
      yield;
    }
  }

  *whenKeyOPressed() {
    this.broadcast("Game: Show Options");
  }

  *whenKeyFPressed() {
    if (this.toNumber(this.vars.ShowFps) === 0) {
      this.stage.watchers.fps.visible = true;
    } else {
      this.stage.watchers.fps.visible = false;
    }
    this.vars.ShowFps = 1 - this.toNumber(this.vars.ShowFps);
  }

  *whenKeyMPressed() {
    this.stage.vars.defaultControls =
      1 - this.toNumber(this.stage.vars.defaultControls);
    yield* this.broadcastAndWait("Game: Display Controls");
  }

  *whenKeyPPressed() {
    this.stage.vars.paused = 1 - this.toNumber(this.stage.vars.paused);
  }

  *whenbackdropswitchesto() {
    this.clearPen();
    this.stage.watchers.fps.visible = false;
    /* TODO: Implement stop all */ null;
  }
}
