/* eslint-disable require-yield, eqeqeq */

import {
  Stage as StageBase,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Stage extends StageBase {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Main", "./Stage/costumes/Main.svg", { x: 240, y: 180 }),
      new Costume("Thumb", "./Stage/costumes/Thumb.png", { x: 480, y: 360 }),
    ];

    this.sounds = [];

    this.triggers = [];

    this.vars.cameraX = 40;
    this.vars.cameraY = 120;
    this.vars.cameraZ = -520;
    this.vars.cameraRotX = 0;
    this.vars.cameraRotY = 0;
    this.vars.fps = 29.411777407645374;
    this.vars.deltaTime = 0.03399998531676829;
    this.vars.updateNeeded = 0;
    this.vars.time = 321.51599993696436;
    this.vars.defaultControls = 1;
    this.vars.paused = 0;
    this.vars.numCustomProperties = 1;
    this.vars.TimeOffset = 10458.163;
    this.vars.objectsX = [];
    this.vars.objectsY = [];
    this.vars.objectsZ = [];
    this.vars.objectsRotX = [];
    this.vars.objectsRotY = [];
    this.vars.objectsRotZ = [];
    this.vars.objectsSurfaces = [];
    this.vars.objectsSurfacesIndex = [];
    this.vars.objectsPointsIndex = [0];
    this.vars.objectsVisible = [];
    this.vars.objectsShadows = [];
    this.vars.pointDataX = [];
    this.vars.pointDataY = [];
    this.vars.pointDataZ = [];
    this.vars.worldDataX = [];
    this.vars.worldDataY = [];
    this.vars.worldDataZ = [];
    this.vars.surfacesType = [];
    this.vars.surfacesP1 = [];
    this.vars.surfacesP2 = [];
    this.vars.surfacesP3 = [];
    this.vars.surfacesP4 = [];
    this.vars.surfacesDiameter = [];
    this.vars.surfacesTexture = [];
    this.vars.surfacesLightSource = [];
    this.vars.surfacesN0 = [];
    this.vars.surfacesN1 = [];
    this.vars.surfacesN2 = [];
    this.vars.texturesR = [];
    this.vars.texturesG = [];
    this.vars.texturesB = [];
    this.vars.texturesA = [];
    this.vars.texturesSoundStart = [];
    this.vars.texturesSoundEnd = [];
    this.vars.lightSourcesX = [0];
    this.vars.lightSourcesY = [0];
    this.vars.lightSourcesZ = [0];
    this.vars.lightSourcesContrib = [0];
    this.vars.renderSettings = [
      276, 4, 6, 8, 1, 0.3, 0.3333333333333333, 0.16666666666666666,
      0.08333333333333333, 1, 1, 1, 1, 1, 1, 100, 77, 189, 51, 181, 255, 255,
      19, 80, 134, -162, -175, -121, 15526319, 15527406, 16777215, 0, 1, 0,
      4000, 0,
    ];
    this.vars.collisionBoxesX1 = [];
    this.vars.collisionBoxesY1 = [];
    this.vars.collisionBoxesZ1 = [];
    this.vars.collisionBoxesX2 = [];
    this.vars.collisionBoxesY2 = [];
    this.vars.collisionBoxesZ2 = [];
    this.vars.collisionBoxesRXData = [];
    this.vars.collisionBoxesRYData = [];
    this.vars.collisionBoxesRZData = [];
    this.vars.collisionBoxesRN0 = [];
    this.vars.collisionBoxesRN1 = [];
    this.vars.collisionBoxesRN2 = [];
    this.vars.collisionSpheresX = [];
    this.vars.collisionSpheresY = [];
    this.vars.collisionSpheresZ = [];
    this.vars.collisionSpheresRadius = [];
    this.vars.soundsVolume = [];
    this.vars.soundsHasClone = [];
    this.vars.objectsTag = [];
    this.vars.objectsCustomProperties = [];
    this.vars.MatrixOld = [];
    this.vars.MatrixTemp = [];
    this.vars.getparamListR = [];

    this.watchers.fps = new Watcher({
      label: "FPS",
      style: "normal",
      visible: false,
      value: () => this.vars.fps,
      x: 600,
      y: -148,
    });
    this.watchers.renderSettings = new Watcher({
      label: "Render Settings",
      style: "normal",
      visible: false,
      value: () => this.vars.renderSettings,
      x: 456,
      y: 177,
      width: 263,
      height: 332,
    });
  }
}
