/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Runtime extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("icon", "./Runtime/costumes/icon.svg", { x: 242, y: 175 }),
    ];

    this.sounds = [
      new Sound("Door Close", "./Runtime/sounds/Door Close.wav"),
      new Sound("Door Open", "./Runtime/sounds/Door Open.wav"),
    ];

    this.triggers = [
      new Trigger(
        Trigger.BROADCAST,
        { name: "init: misc" },
        this.whenIReceiveInitMisc
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "system: physics tick" },
        this.whenIReceiveSystemPhysicsTick
      ),
    ];

    this.audioEffects.volume = 91.8399064636101;

    this.vars.PointX = 0;
    this.vars.PointY = 0;
    this.vars.PointZ = 0;
    this.vars.SurfaceP1 = 0;
    this.vars.SurfaceP2 = 0;
    this.vars.SurfaceP3 = 0;
    this.vars.SurfaceTexture = 0;
    this.vars.SurfaceN1 = 0;
    this.vars.SurfaceN2 = 0;
    this.vars.PointId = 25;
    this.vars.SurfaceId = 26;
    this.vars.Return = 0;
    this.vars.CurrentBox = 8;
    this.vars.CurrentCollision = false;
    this.vars.DoorAction = 0;
    this.vars.DoorActionStart = 0;
    this.vars.PointX2 = 320;
    this.vars.PointY2 = 80;
    this.vars.PointZ2 = -5;
    this.vars.Edge10 = 90;
    this.vars.Edge11 = 170;
    this.vars.Edge12 = 0;
    this.vars.Edge20 = 0;
    this.vars.Edge21 = 170;
    this.vars.Edge22 = 0;
    this.vars.V0 = 0;
    this.vars.V1 = 0;
    this.vars.V2 = 15300;
    this.vars.Dist = 15300;
    this.vars.SurfaceN0 = 0;
    this.vars.SurfaceLightSource = 0;
    this.vars.SurfaceType = 0;
    this.vars.SurfaceP4 = 0;
    this.vars.SurfaceDiameter = 0;
    this.vars.CustomPropertyValue = 1;
    this.vars.Matrix = [1, 0, 0, 240, 0, 1, 0, 0, 0, 0, 1, 0];
  }

  *getIdOfPointInObject(point, object) {
    this.vars.PointId =
      this.toNumber(
        this.itemOf(this.stage.vars.objectsPointsIndex, object - 1)
      ) + this.toNumber(point);
  }

  *getPointInObject(point, object) {
    this.warp(this.getIdOfPointInObject)(point, object);
    this.vars.PointX = this.itemOf(
      this.stage.vars.pointDataX,
      this.vars.PointId - 1
    );
    this.vars.PointY = this.itemOf(
      this.stage.vars.pointDataY,
      this.vars.PointId - 1
    );
    this.vars.PointZ = this.itemOf(
      this.stage.vars.pointDataZ,
      this.vars.PointId - 1
    );
  }

  *setPointInObjectToXYZ(point, object, x, y, z) {
    this.warp(this.getIdOfPointInObject)(point, object);
    this.stage.vars.pointDataX.splice(this.vars.PointId - 1, 1, x);
    this.stage.vars.pointDataY.splice(this.vars.PointId - 1, 1, y);
    this.stage.vars.pointDataZ.splice(this.vars.PointId - 1, 1, z);
    this.warp(this.updateWorldDataForObject)(object);
  }

  *updateWorldDataForObject(object) {
    this.warp(this.intCreateObjectWorldTransformation)(
      this.itemOf(this.stage.vars.objectsX, object - 1),
      this.itemOf(this.stage.vars.objectsY, object - 1),
      this.itemOf(this.stage.vars.objectsZ, object - 1),
      Math.sin(
        this.degToRad(
          this.toNumber(this.itemOf(this.stage.vars.objectsRotX, object - 1))
        )
      ),
      Math.cos(
        this.degToRad(
          this.toNumber(this.itemOf(this.stage.vars.objectsRotX, object - 1))
        )
      ),
      Math.sin(
        this.degToRad(
          this.toNumber(this.itemOf(this.stage.vars.objectsRotY, object - 1))
        )
      ),
      Math.cos(
        this.degToRad(
          this.toNumber(this.itemOf(this.stage.vars.objectsRotY, object - 1))
        )
      ),
      Math.sin(
        this.degToRad(
          this.toNumber(this.itemOf(this.stage.vars.objectsRotZ, object - 1))
        )
      ),
      Math.cos(
        this.degToRad(
          this.toNumber(this.itemOf(this.stage.vars.objectsRotZ, object - 1))
        )
      )
    );
    this.vars.PointId =
      this.toNumber(
        this.itemOf(this.stage.vars.objectsPointsIndex, object - 1)
      ) + 1;
    for (
      let i = 0;
      i <
      this.toNumber(
        this.itemOf(this.stage.vars.objectsPointsIndex, this.toNumber(object))
      ) -
        this.toNumber(
          this.itemOf(this.stage.vars.objectsPointsIndex, object - 1)
        );
      i++
    ) {
      this.warp(this.intTransformVertex)(
        this.itemOf(this.stage.vars.pointDataX, this.vars.PointId - 1),
        this.itemOf(this.stage.vars.pointDataY, this.vars.PointId - 1),
        this.itemOf(this.stage.vars.pointDataZ, this.vars.PointId - 1)
      );
      this.stage.vars.worldDataX.splice(
        this.vars.PointId - 1,
        1,
        this.vars.PointX2
      );
      this.stage.vars.worldDataY.splice(
        this.vars.PointId - 1,
        1,
        this.vars.PointY2
      );
      this.stage.vars.worldDataZ.splice(
        this.vars.PointId - 1,
        1,
        this.vars.PointZ2
      );
      this.vars.PointId++;
    }
    this.vars.SurfaceId = this.itemOf(
      this.stage.vars.objectsSurfacesIndex,
      object - 1
    );
    for (
      let i = 0;
      i <
      this.toNumber(this.itemOf(this.stage.vars.objectsSurfaces, object - 1));
      i++
    ) {
      if (
        this.compare(
          this.itemOf(this.stage.vars.surfacesType, this.vars.SurfaceId - 1),
          3
        ) < 0
      ) {
        this.vars.Edge10 =
          this.toNumber(
            this.itemOf(
              this.stage.vars.worldDataX,
              this.itemOf(this.stage.vars.surfacesP2, this.vars.SurfaceId - 1) -
                1
            )
          ) -
          this.toNumber(
            this.itemOf(
              this.stage.vars.worldDataX,
              this.itemOf(this.stage.vars.surfacesP1, this.vars.SurfaceId - 1) -
                1
            )
          );
        this.vars.Edge11 =
          this.toNumber(
            this.itemOf(
              this.stage.vars.worldDataY,
              this.itemOf(this.stage.vars.surfacesP2, this.vars.SurfaceId - 1) -
                1
            )
          ) -
          this.toNumber(
            this.itemOf(
              this.stage.vars.worldDataY,
              this.itemOf(this.stage.vars.surfacesP1, this.vars.SurfaceId - 1) -
                1
            )
          );
        this.vars.Edge12 =
          this.toNumber(
            this.itemOf(
              this.stage.vars.worldDataZ,
              this.itemOf(this.stage.vars.surfacesP2, this.vars.SurfaceId - 1) -
                1
            )
          ) -
          this.toNumber(
            this.itemOf(
              this.stage.vars.worldDataZ,
              this.itemOf(this.stage.vars.surfacesP1, this.vars.SurfaceId - 1) -
                1
            )
          );
        this.vars.Edge20 =
          this.toNumber(
            this.itemOf(
              this.stage.vars.worldDataX,
              this.itemOf(this.stage.vars.surfacesP3, this.vars.SurfaceId - 1) -
                1
            )
          ) -
          this.toNumber(
            this.itemOf(
              this.stage.vars.worldDataX,
              this.itemOf(this.stage.vars.surfacesP1, this.vars.SurfaceId - 1) -
                1
            )
          );
        this.vars.Edge21 =
          this.toNumber(
            this.itemOf(
              this.stage.vars.worldDataY,
              this.itemOf(this.stage.vars.surfacesP3, this.vars.SurfaceId - 1) -
                1
            )
          ) -
          this.toNumber(
            this.itemOf(
              this.stage.vars.worldDataY,
              this.itemOf(this.stage.vars.surfacesP1, this.vars.SurfaceId - 1) -
                1
            )
          );
        this.vars.Edge22 =
          this.toNumber(
            this.itemOf(
              this.stage.vars.worldDataZ,
              this.itemOf(this.stage.vars.surfacesP3, this.vars.SurfaceId - 1) -
                1
            )
          ) -
          this.toNumber(
            this.itemOf(
              this.stage.vars.worldDataZ,
              this.itemOf(this.stage.vars.surfacesP1, this.vars.SurfaceId - 1) -
                1
            )
          );
        this.vars.V0 =
          this.toNumber(this.vars.Edge11) * this.toNumber(this.vars.Edge22) -
          this.toNumber(this.vars.Edge12) * this.toNumber(this.vars.Edge21);
        this.vars.V1 =
          this.toNumber(this.vars.Edge12) * this.toNumber(this.vars.Edge20) -
          this.toNumber(this.vars.Edge10) * this.toNumber(this.vars.Edge22);
        this.vars.V2 =
          this.toNumber(this.vars.Edge10) * this.toNumber(this.vars.Edge21) -
          this.toNumber(this.vars.Edge11) * this.toNumber(this.vars.Edge20);
        this.vars.Dist = Math.sqrt(
          this.toNumber(this.vars.V0) * this.toNumber(this.vars.V0) +
            (this.toNumber(this.vars.V1) * this.toNumber(this.vars.V1) +
              this.toNumber(this.vars.V2) * this.toNumber(this.vars.V2))
        );
        this.stage.vars.surfacesN0.splice(
          this.vars.SurfaceId - 1,
          1,
          this.toNumber(this.vars.V0) / this.toNumber(this.vars.Dist)
        );
        this.stage.vars.surfacesN1.splice(
          this.vars.SurfaceId - 1,
          1,
          this.toNumber(this.vars.V1) / this.toNumber(this.vars.Dist)
        );
        this.stage.vars.surfacesN2.splice(
          this.vars.SurfaceId - 1,
          1,
          this.toNumber(this.vars.V2) / this.toNumber(this.vars.Dist)
        );
      }
      this.vars.SurfaceId++;
    }
    this.stage.vars.updateNeeded = 1;
  }

  *moveObjectToXYZ(object, x, y, z) {
    this.stage.vars.objectsX.splice(object - 1, 1, x);
    this.stage.vars.objectsY.splice(object - 1, 1, y);
    this.stage.vars.objectsZ.splice(object - 1, 1, z);
    this.warp(this.updateWorldDataForObject)(object);
  }

  *rotateObjectToRotXRotYRotZ(object, x, y, z) {
    this.stage.vars.objectsRotX.splice(object - 1, 1, x);
    this.stage.vars.objectsRotY.splice(object - 1, 1, y);
    this.stage.vars.objectsRotZ.splice(object - 1, 1, z);
    this.warp(this.updateWorldDataForObject)(object);
  }

  *transformObjectXYZRotXRotYRotZ(object, x, y, z, rotX, rotY, rotZ) {
    this.stage.vars.objectsX.splice(object - 1, 1, x);
    this.stage.vars.objectsY.splice(object - 1, 1, y);
    this.stage.vars.objectsZ.splice(object - 1, 1, z);
    this.stage.vars.objectsRotX.splice(object - 1, 1, rotX);
    this.stage.vars.objectsRotY.splice(object - 1, 1, rotY);
    this.stage.vars.objectsRotZ.splice(object - 1, 1, rotZ);
    this.warp(this.updateWorldDataForObject)(object);
  }

  *addCollisionBoxXYZWidthHeightDepthPadding(
    x,
    y,
    z,
    width,
    height,
    depth,
    padding
  ) {
    if (this.compare(width, 0) < 0) {
      this.warp(this.addCollisionBoxXYZWidthHeightDepthPadding)(
        this.toNumber(x) + this.toNumber(width),
        y,
        z,
        Math.abs(this.toNumber(width)),
        height,
        depth,
        padding
      );
    } else {
      if (this.compare(height, 0) < 0) {
        this.warp(this.addCollisionBoxXYZWidthHeightDepthPadding)(
          x,
          this.toNumber(y) + this.toNumber(height),
          z,
          width,
          Math.abs(this.toNumber(height)),
          depth,
          padding
        );
      } else {
        if (this.compare(depth, 0) < 0) {
          this.warp(this.addCollisionBoxXYZWidthHeightDepthPadding)(
            x,
            y,
            this.toNumber(z) + this.toNumber(depth),
            width,
            height,
            Math.abs(this.toNumber(depth)),
            padding
          );
        } else {
          this.stage.vars.collisionBoxesX1.push(
            this.toNumber(x) - this.toNumber(padding)
          );
          this.stage.vars.collisionBoxesY1.push(
            this.toNumber(y) - this.toNumber(padding)
          );
          this.stage.vars.collisionBoxesZ1.push(
            this.toNumber(z) - this.toNumber(padding)
          );
          this.stage.vars.collisionBoxesX2.push(
            this.toNumber(x) + this.toNumber(width) + this.toNumber(padding)
          );
          this.stage.vars.collisionBoxesY2.push(
            this.toNumber(y) + this.toNumber(height) + this.toNumber(padding)
          );
          this.stage.vars.collisionBoxesZ2.push(
            this.toNumber(z) + this.toNumber(depth) + this.toNumber(padding)
          );
        }
      }
    }
  }

  *getIdOfSurfaceInObject(surface, object) {
    this.vars.SurfaceId =
      this.toNumber(
        this.itemOf(this.stage.vars.objectsSurfacesIndex, object - 1)
      ) +
      (this.toNumber(surface) - 1);
  }

  *getSurfaceInObject(surface, object) {
    this.warp(this.getIdOfSurfaceInObject)(surface, object);
    this.vars.SurfaceType = this.itemOf(
      this.stage.vars.surfacesType,
      this.vars.SurfaceId - 1
    );
    this.vars.SurfaceP1 = this.itemOf(
      this.stage.vars.surfacesP1,
      this.vars.SurfaceId - 1
    );
    this.vars.SurfaceP2 = this.itemOf(
      this.stage.vars.surfacesP2,
      this.vars.SurfaceId - 1
    );
    this.vars.SurfaceP3 = this.itemOf(
      this.stage.vars.surfacesP3,
      this.vars.SurfaceId - 1
    );
    this.vars.SurfaceP4 = this.itemOf(
      this.stage.vars.surfacesP4,
      this.vars.SurfaceId - 1
    );
    this.vars.SurfaceDiameter = this.itemOf(
      this.stage.vars.surfacesDiameter,
      this.vars.SurfaceId - 1
    );
    this.vars.SurfaceTexture = this.itemOf(
      this.stage.vars.surfacesTexture,
      this.vars.SurfaceId - 1
    );
    this.vars.SurfaceLightSource = this.itemOf(
      this.stage.vars.surfacesLightSource,
      this.vars.SurfaceId - 1
    );
    this.vars.SurfaceN0 = this.itemOf(
      this.stage.vars.surfacesN0,
      this.vars.SurfaceId - 1
    );
    this.vars.SurfaceN1 = this.itemOf(
      this.stage.vars.surfacesN1,
      this.vars.SurfaceId - 1
    );
    this.vars.SurfaceN2 = this.itemOf(
      this.stage.vars.surfacesN2,
      this.vars.SurfaceId - 1
    );
  }

  *intCreateObjectWorldTransformation(
    x,
    y,
    z,
    sinRotX,
    cosRotX,
    sinRotY,
    cosRotY,
    sinRotZ,
    cosRotZ
  ) {
    this.vars.undefined = [];
    this.vars.undefined.push(this.toNumber(cosRotZ) * this.toNumber(cosRotX));
    this.vars.undefined.push(
      this.toNumber(cosRotZ) *
        (this.toNumber(sinRotX) * this.toNumber(sinRotY)) -
        this.toNumber(sinRotZ) * this.toNumber(cosRotY)
    );
    this.vars.undefined.push(
      this.toNumber(cosRotZ) *
        (this.toNumber(sinRotX) * this.toNumber(cosRotY)) +
        this.toNumber(sinRotZ) * this.toNumber(sinRotY)
    );
    this.vars.undefined.push(x);
    this.vars.undefined.push(this.toNumber(sinRotZ) * this.toNumber(cosRotX));
    this.vars.undefined.push(
      this.toNumber(sinRotZ) *
        (this.toNumber(sinRotX) * this.toNumber(sinRotY)) +
        this.toNumber(cosRotZ) * this.toNumber(cosRotY)
    );
    this.vars.undefined.push(
      this.toNumber(sinRotZ) *
        (this.toNumber(sinRotX) * this.toNumber(cosRotY)) -
        this.toNumber(cosRotZ) * this.toNumber(sinRotY)
    );
    this.vars.undefined.push(y);
    this.vars.undefined.push(0 - this.toNumber(sinRotX));
    this.vars.undefined.push(this.toNumber(cosRotX) * this.toNumber(sinRotY));
    this.vars.undefined.push(this.toNumber(cosRotX) * this.toNumber(cosRotY));
    this.vars.undefined.push(z);
  }

  *intTransformVertex(x, y, z) {
    this.vars.PointX2 =
      this.toNumber(this.itemOf(this.vars.Matrix, 0)) * this.toNumber(x) +
      this.toNumber(this.itemOf(this.vars.Matrix, 1)) * this.toNumber(y) +
      (this.toNumber(this.itemOf(this.vars.Matrix, 2)) * this.toNumber(z) +
        this.toNumber(this.itemOf(this.vars.Matrix, 3)));
    this.vars.PointY2 =
      this.toNumber(this.itemOf(this.vars.Matrix, 4)) * this.toNumber(x) +
      this.toNumber(this.itemOf(this.vars.Matrix, 5)) * this.toNumber(y) +
      (this.toNumber(this.itemOf(this.vars.Matrix, 6)) * this.toNumber(z) +
        this.toNumber(this.itemOf(this.vars.Matrix, 7)));
    this.vars.PointZ2 =
      this.toNumber(this.itemOf(this.vars.Matrix, 8)) * this.toNumber(x) +
      this.toNumber(this.itemOf(this.vars.Matrix, 9)) * this.toNumber(y) +
      (this.toNumber(this.itemOf(this.vars.Matrix, 10)) * this.toNumber(z) +
        this.toNumber(this.itemOf(this.vars.Matrix, 11)));
  }

  *deleteCollisionBox(id) {
    this.stage.vars.collisionBoxesX1.splice(id - 1, 1);
    this.stage.vars.collisionBoxesY1.splice(id - 1, 1);
    this.stage.vars.collisionBoxesZ1.splice(id - 1, 1);
    this.stage.vars.collisionBoxesX2.splice(id - 1, 1);
    this.stage.vars.collisionBoxesY2.splice(id - 1, 1);
    this.stage.vars.collisionBoxesZ2.splice(id - 1, 1);
  }

  *setCollisionBoxToXYZWidthHeightDepthPadding(
    id,
    x,
    y,
    z,
    width,
    height,
    depth,
    padding
  ) {
    if (this.compare(width, 0) < 0) {
      this.warp(this.setCollisionBoxToXYZWidthHeightDepthPadding)(
        id,
        this.toNumber(x) + this.toNumber(width),
        y,
        z,
        Math.abs(this.toNumber(width)),
        height,
        depth,
        padding
      );
    } else {
      if (this.compare(height, 0) < 0) {
        this.warp(this.setCollisionBoxToXYZWidthHeightDepthPadding)(
          id,
          x,
          this.toNumber(y) + this.toNumber(height),
          z,
          width,
          Math.abs(this.toNumber(height)),
          depth,
          padding
        );
      } else {
        if (this.compare(depth, 0) < 0) {
          this.warp(this.setCollisionBoxToXYZWidthHeightDepthPadding)(
            id,
            x,
            y,
            this.toNumber(z) + this.toNumber(depth),
            width,
            height,
            Math.abs(this.toNumber(depth)),
            padding
          );
        } else {
          this.stage.vars.collisionBoxesX1.splice(
            id - 1,
            1,
            this.toNumber(x) - this.toNumber(padding)
          );
          this.stage.vars.collisionBoxesY1.splice(
            id - 1,
            1,
            this.toNumber(y) - this.toNumber(padding)
          );
          this.stage.vars.collisionBoxesZ1.splice(
            id - 1,
            1,
            this.toNumber(z) - this.toNumber(padding)
          );
          this.stage.vars.collisionBoxesX2.splice(
            id - 1,
            1,
            this.toNumber(x) + this.toNumber(width) + this.toNumber(padding)
          );
          this.stage.vars.collisionBoxesY2.splice(
            id - 1,
            1,
            this.toNumber(y) + this.toNumber(height) + this.toNumber(padding)
          );
          this.stage.vars.collisionBoxesZ2.splice(
            id - 1,
            1,
            this.toNumber(z) + this.toNumber(depth) + this.toNumber(padding)
          );
        }
      }
    }
  }

  *testForCollisionAtXYZ(x, y, z) {
    this.vars.Return = 0;
    this.vars.CurrentBox = 1;
    while (
      !(
        this.compare(
          this.vars.CurrentBox,
          this.stage.vars.collisionBoxesX1.length
        ) > 0 || this.toNumber(this.vars.Return) === 1
      )
    ) {
      this.warp(this.intCuboidContainsPoint)(
        x,
        y,
        z,
        this.itemOf(this.stage.vars.collisionBoxesX1, this.vars.CurrentBox - 1),
        this.itemOf(this.stage.vars.collisionBoxesY1, this.vars.CurrentBox - 1),
        this.itemOf(this.stage.vars.collisionBoxesZ1, this.vars.CurrentBox - 1),
        this.itemOf(this.stage.vars.collisionBoxesX2, this.vars.CurrentBox - 1),
        this.itemOf(this.stage.vars.collisionBoxesY2, this.vars.CurrentBox - 1),
        this.itemOf(this.stage.vars.collisionBoxesZ2, this.vars.CurrentBox - 1)
      );
      if (this.compare(this.vars.CurrentCollision, 0 === "") === 0) {
        this.vars.Return = 1;
      }
      this.vars.CurrentBox++;
    }
  }

  *testForCollisionWithBoxAtXYZ(box, x, y, z) {
    this.warp(this.intCuboidContainsPoint)(
      x,
      y,
      z,
      this.itemOf(this.stage.vars.collisionBoxesX1, box - 1),
      this.itemOf(this.stage.vars.collisionBoxesY1, box - 1),
      this.itemOf(this.stage.vars.collisionBoxesZ1, box - 1),
      this.itemOf(this.stage.vars.collisionBoxesX2, box - 1),
      this.itemOf(this.stage.vars.collisionBoxesY2, box - 1),
      this.itemOf(this.stage.vars.collisionBoxesZ2, box - 1)
    );
  }

  *intCuboidContainsPoint(x, y, z, x1, y1, z1, x2, y2, z2) {
    this.vars.CurrentCollision =
      this.compare(x, x1) > 0 &&
      this.compare(x, x2) < 0 &&
      this.compare(y, y1) > 0 &&
      this.compare(y, y2) < 0 &&
      this.compare(z, z1) > 0 &&
      this.compare(z, z2) < 0;
  }

  *testForCollisionIn(ax, bx, ay, by, az, bz) {
    this.vars.Return = 0;
    this.vars.CurrentBox = 1;
    while (
      !(
        this.compare(
          this.vars.CurrentBox,
          this.stage.vars.collisionBoxesX1.length
        ) > 0 || this.toNumber(this.vars.Return) === 1
      )
    ) {
      this.warp(this.intCuboidsIntersect)(
        ax,
        bx,
        ay,
        by,
        az,
        bz,
        this.itemOf(this.stage.vars.collisionBoxesX1, this.vars.CurrentBox - 1),
        this.itemOf(this.stage.vars.collisionBoxesX2, this.vars.CurrentBox - 1),
        this.itemOf(this.stage.vars.collisionBoxesY1, this.vars.CurrentBox - 1),
        this.itemOf(this.stage.vars.collisionBoxesY2, this.vars.CurrentBox - 1),
        this.itemOf(this.stage.vars.collisionBoxesZ1, this.vars.CurrentBox - 1),
        this.itemOf(this.stage.vars.collisionBoxesZ2, this.vars.CurrentBox - 1)
      );
      if (this.compare(this.vars.CurrentCollision, 0 === "") === 0) {
        this.vars.Return = 1;
      }
      this.vars.CurrentBox++;
    }
    if (this.toNumber(this.vars.Return) === 0) {
      this.vars.CurrentBox = 1;
      while (
        !(
          this.compare(
            this.vars.CurrentBox,
            this.stage.vars.collisionBoxesRXData.length / 6
          ) > 0 || this.toNumber(this.vars.Return) === 1
        )
      ) {
        this.warp(this.intInsersectsCuboidConvexHull)(
          ax,
          bx,
          ay,
          by,
          az,
          bz,
          this.vars.CurrentBox
        );
        if (this.toNumber(this.vars.CurrentCollision) === 1) {
          this.vars.Return = 1;
        }
        this.vars.CurrentBox++;
      }
      this.vars.CurrentBox = 0 - this.toNumber(this.vars.CurrentBox);
    }
  }

  *intCuboidsIntersect(ax, bx, ay, by, az, bz, cx, dx, cy, dy, cz, dz) {
    this.vars.CurrentCollision = !(
      this.compare(ax, dx) > 0 ||
      this.compare(bx, cx) < 0 ||
      this.compare(ay, dy) > 0 ||
      this.compare(by, cy) < 0 ||
      this.compare(az, dz) > 0 ||
      this.compare(bz, cz) < 0
    );
  }

  *intInsersectsCuboidConvexHull(x1, x2, y1, y2, z1, z2, hull) {
    this.warp(this.int2IntersectsCuboidConvexHull)(
      x1,
      x2,
      y1,
      y2,
      z1,
      z2,
      (this.toNumber(hull) - 1) * 8,
      (this.toNumber(hull) - 1) * 3
    );
  }

  *int2IntersectsCuboidConvexHull(x1, x2, y1, y2, z1, z2, pIndex, nIndex) {
    this.vars.undefined = this.itemOf(
      this.stage.vars.collisionBoxesRXData,
      this.toNumber(pIndex)
    );
    this.vars.undefined = this.vars.undefined;
    this.vars.undefined = 2;
    for (let i = 0; i < 7; i++) {
      this.vars.undefined = this.itemOf(
        this.stage.vars.collisionBoxesRXData,
        this.toNumber(pIndex) + this.toNumber(this.vars.undefined) - 1
      );
      if (this.compare(this.vars.undefined, this.vars.undefined) < 0) {
        this.vars.undefined = this.vars.undefined;
      } else {
        if (this.compare(this.vars.undefined, this.vars.undefined) > 0) {
          this.vars.undefined = this.vars.undefined;
        }
      }
      this.vars.undefined++;
    }
    if (
      this.compare(x1, this.vars.undefined) > 0 ||
      this.compare(x2, this.vars.undefined) < 0
    ) {
      this.vars.CurrentCollision = 0;
    } else {
      this.vars.undefined = this.itemOf(
        this.stage.vars.collisionBoxesRYData,
        this.toNumber(pIndex)
      );
      this.vars.undefined = this.vars.undefined;
      this.vars.undefined = 2;
      for (let i = 0; i < 7; i++) {
        this.vars.undefined = this.itemOf(
          this.stage.vars.collisionBoxesRYData,
          this.toNumber(pIndex) + this.toNumber(this.vars.undefined) - 1
        );
        if (this.compare(this.vars.undefined, this.vars.undefined) < 0) {
          this.vars.undefined = this.vars.undefined;
        } else {
          if (this.compare(this.vars.undefined, this.vars.undefined) > 0) {
            this.vars.undefined = this.vars.undefined;
          }
        }
        this.vars.undefined++;
      }
      if (
        this.compare(y1, this.vars.undefined) > 0 ||
        this.compare(y2, this.vars.undefined) < 0
      ) {
        this.vars.CurrentCollision = 0;
      } else {
        this.vars.undefined = this.itemOf(
          this.stage.vars.collisionBoxesRZData,
          this.toNumber(pIndex)
        );
        this.vars.undefined = this.vars.undefined;
        this.vars.undefined = 2;
        for (let i = 0; i < 7; i++) {
          this.vars.undefined = this.itemOf(
            this.stage.vars.collisionBoxesRZData,
            this.toNumber(pIndex) + this.toNumber(this.vars.undefined) - 1
          );
          if (this.compare(this.vars.undefined, this.vars.undefined) < 0) {
            this.vars.undefined = this.vars.undefined;
          } else {
            if (this.compare(this.vars.undefined, this.vars.undefined) > 0) {
              this.vars.undefined = this.vars.undefined;
            }
          }
          this.vars.undefined++;
        }
        if (
          this.compare(z1, this.vars.undefined) > 0 ||
          this.compare(z2, this.vars.undefined) < 0
        ) {
          this.vars.CurrentCollision = 0;
        } else {
          this.warp(this.intDoLineTest)(
            x1,
            x2,
            y1,
            y2,
            z1,
            z2,
            this.itemOf(
              this.stage.vars.collisionBoxesRN0,
              this.toNumber(nIndex)
            ),
            this.itemOf(
              this.stage.vars.collisionBoxesRN1,
              this.toNumber(nIndex)
            ),
            this.itemOf(
              this.stage.vars.collisionBoxesRN2,
              this.toNumber(nIndex)
            ),
            this.toNumber(pIndex) + 1,
            this.toNumber(pIndex) + 2
          );
          if (
            this.compare(this.vars.undefined, this.vars.undefined) > 0 ||
            this.compare(this.vars.undefined, this.vars.undefined) < 0
          ) {
            this.vars.CurrentCollision = 0;
          } else {
            this.warp(this.intDoLineTest)(
              x1,
              x2,
              y1,
              y2,
              z1,
              z2,
              this.itemOf(
                this.stage.vars.collisionBoxesRN0,
                this.toNumber(nIndex) + 1
              ),
              this.itemOf(
                this.stage.vars.collisionBoxesRN1,
                this.toNumber(nIndex) + 1
              ),
              this.itemOf(
                this.stage.vars.collisionBoxesRN2,
                this.toNumber(nIndex) + 1
              ),
              this.toNumber(pIndex) + 1,
              this.toNumber(pIndex) + 3
            );
            if (
              this.compare(this.vars.undefined, this.vars.undefined) > 0 ||
              this.compare(this.vars.undefined, this.vars.undefined) < 0
            ) {
              this.vars.CurrentCollision = 0;
            } else {
              this.warp(this.intDoLineTest)(
                x1,
                x2,
                y1,
                y2,
                z1,
                z2,
                this.itemOf(
                  this.stage.vars.collisionBoxesRN0,
                  this.toNumber(nIndex) + 2
                ),
                this.itemOf(
                  this.stage.vars.collisionBoxesRN1,
                  this.toNumber(nIndex) + 2
                ),
                this.itemOf(
                  this.stage.vars.collisionBoxesRN2,
                  this.toNumber(nIndex) + 2
                ),
                this.toNumber(pIndex) + 1,
                this.toNumber(pIndex) + 5
              );
              if (
                this.compare(this.vars.undefined, this.vars.undefined) > 0 ||
                this.compare(this.vars.undefined, this.vars.undefined) < 0
              ) {
                this.vars.CurrentCollision = 0;
              } else {
                this.vars.CurrentCollision = 1;
              }
            }
          }
        }
      }
    }
  }

  *intDoLineTest(x1, x2, y1, y2, z1, z2, n0, n1, n2, p1, p2) {
    this.vars.undefined =
      this.toNumber(x1) * this.toNumber(n0) +
      (this.toNumber(y1) * this.toNumber(n1) +
        this.toNumber(z1) * this.toNumber(n2));
    this.vars.undefined = this.vars.undefined;
    this.warp(this.intAdjustMinAndMax)(
      this.toNumber(x1) * this.toNumber(n0) +
        (this.toNumber(y1) * this.toNumber(n1) +
          this.toNumber(z2) * this.toNumber(n2))
    );
    this.warp(this.intAdjustMinAndMax)(
      this.toNumber(x1) * this.toNumber(n0) +
        (this.toNumber(y2) * this.toNumber(n1) +
          this.toNumber(z1) * this.toNumber(n2))
    );
    this.warp(this.intAdjustMinAndMax)(
      this.toNumber(x1) * this.toNumber(n0) +
        (this.toNumber(y2) * this.toNumber(n1) +
          this.toNumber(z2) * this.toNumber(n2))
    );
    this.warp(this.intAdjustMinAndMax)(
      this.toNumber(x2) * this.toNumber(n0) +
        (this.toNumber(y1) * this.toNumber(n1) +
          this.toNumber(z1) * this.toNumber(n2))
    );
    this.warp(this.intAdjustMinAndMax)(
      this.toNumber(x2) * this.toNumber(n0) +
        (this.toNumber(y1) * this.toNumber(n1) +
          this.toNumber(z2) * this.toNumber(n2))
    );
    this.warp(this.intAdjustMinAndMax)(
      this.toNumber(x2) * this.toNumber(n0) +
        (this.toNumber(y2) * this.toNumber(n1) +
          this.toNumber(z1) * this.toNumber(n2))
    );
    this.warp(this.intAdjustMinAndMax)(
      this.toNumber(x2) * this.toNumber(n0) +
        (this.toNumber(y2) * this.toNumber(n1) +
          this.toNumber(z2) * this.toNumber(n2))
    );
    this.vars.undefined =
      this.toNumber(this.itemOf(this.stage.vars.collisionBoxesRXData, p1 - 1)) *
        this.toNumber(n0) +
      (this.toNumber(
        this.itemOf(this.stage.vars.collisionBoxesRYData, p1 - 1)
      ) *
        this.toNumber(n1) +
        this.toNumber(
          this.itemOf(this.stage.vars.collisionBoxesRZData, p1 - 1)
        ) *
          this.toNumber(n2));
    this.vars.undefined =
      this.toNumber(this.itemOf(this.stage.vars.collisionBoxesRXData, p2 - 1)) *
        this.toNumber(n0) +
      (this.toNumber(
        this.itemOf(this.stage.vars.collisionBoxesRYData, p2 - 1)
      ) *
        this.toNumber(n1) +
        this.toNumber(
          this.itemOf(this.stage.vars.collisionBoxesRZData, p2 - 1)
        ) *
          this.toNumber(n2));
    if (this.compare(this.vars.undefined, this.vars.undefined) > 0) {
      this.vars.undefined = this.vars.undefined;
      this.vars.undefined = this.vars.undefined;
    } else {
      this.vars.undefined = this.vars.undefined;
      this.vars.undefined = this.vars.undefined;
    }
  }

  *intAdjustMinAndMax(value) {
    if (this.compare(value, this.vars.undefined) < 0) {
      this.vars.undefined = value;
    } else {
      if (this.compare(value, this.vars.undefined) > 0) {
        this.vars.undefined = value;
      }
    }
  }

  *getRgbFromHsl(hue, sat, lum) {
    if (this.toNumber(sat) === 0) {
      this.vars.undefined = this.toNumber(lum) * 255;
      this.vars.undefined = this.toNumber(lum) * 255;
      this.vars.undefined = this.toNumber(lum) * 255;
    } else {
      if (this.compare(lum, 0.5) < 0) {
        this.vars.undefined = this.toNumber(lum) * (1 + this.toNumber(sat));
      } else {
        this.vars.undefined =
          this.toNumber(lum) +
          this.toNumber(sat) -
          this.toNumber(sat) * this.toNumber(lum);
      }
      this.warp(this.intHueToRgb)(
        this.vars.undefined,
        this.vars.undefined,
        (this.toNumber(hue) + 0.33333) % 1
      );
      this.vars.undefined = this.toNumber(this.vars.Return) * 255;
      this.warp(this.intHueToRgb)(
        this.vars.undefined,
        this.vars.undefined,
        this.toNumber(hue) % 1
      );
      this.vars.undefined = this.toNumber(this.vars.Return) * 255;
      this.warp(this.intHueToRgb)(
        this.vars.undefined,
        this.vars.undefined,
        (this.toNumber(hue) - 0.33333) % 1
      );
      this.vars.undefined = this.toNumber(this.vars.Return) * 255;
    }
  }

  *intHueToRgb(v1, v2, vh) {
    if (this.compare(this.toNumber(vh) * 6, 1) < 0) {
      this.vars.Return =
        (this.toNumber(v1) + (this.toNumber(v2) - this.toNumber(v1))) *
        6 *
        this.toNumber(vh);
    } else {
      if (this.compare(this.toNumber(vh) * 2, 1) < 0) {
        this.vars.Return = v2;
      } else {
        if (this.compare(this.toNumber(vh) * 3, 2) < 0) {
          this.vars.Return =
            (this.toNumber(v1) + (this.toNumber(v2) - this.toNumber(v1))) *
            (0.66666 - this.toNumber(vh)) *
            6;
        } else {
          this.vars.Return = v1;
        }
      }
    }
  }

  *playSoundAtXYZRadiusMaxVolume(sound, x, y, z, radius, volume) {
    this.warp(this.playSoundAtDistanceRadiusMaxVolume)(
      sound,
      Math.sqrt(
        (this.toNumber(x) - this.toNumber(this.stage.vars.cameraX)) *
          (this.toNumber(x) - this.toNumber(this.stage.vars.cameraX)) +
          ((this.toNumber(y) - this.toNumber(this.stage.vars.cameraY)) *
            (this.toNumber(y) - this.toNumber(this.stage.vars.cameraY)) +
            (this.toNumber(z) - this.toNumber(this.stage.vars.cameraZ)) *
              (this.toNumber(z) - this.toNumber(this.stage.vars.cameraZ)))
      ),
      radius,
      volume
    );
  }

  *playSoundAtDistanceRadiusMaxVolume(sound, distance, radius, volume) {
    this.audioEffects.volume =
      ((this.toNumber(radius) - this.toNumber(distance)) /
        this.toNumber(radius)) *
      this.toNumber(volume);
    yield* this.startSound(sound);
  }

  *whenIReceiveInitMisc() {
    this.vars.DoorAction = 0;
    this.vars.DoorActionStart = 0;
  }

  *setCustomPropertyValueToCustomPropertyOfObject(property, object) {
    this.vars.CustomPropertyValue = this.itemOf(
      this.stage.vars.objectsCustomProperties,
      (this.toNumber(object) - 1) *
        this.toNumber(this.stage.vars.numCustomProperties) +
        this.toNumber(property) -
        1
    );
  }

  *setCustomPropertyOfObjectTo(property, object, value) {
    this.stage.vars.objectsCustomProperties.splice(
      (this.toNumber(object) - 1) *
        this.toNumber(this.stage.vars.numCustomProperties) +
        this.toNumber(property) -
        1,
      1,
      value
    );
  }

  *testForCollisionInExcludeCollision(ax, bx, ay, by, az, bz, exclude) {
    this.vars.Return = 0;
    this.vars.CurrentBox = 1;
    while (
      !(
        this.compare(
          this.vars.CurrentBox,
          this.stage.vars.collisionBoxesX1.length
        ) > 0 || this.toNumber(this.vars.Return) === 1
      )
    ) {
      if (!(this.compare(exclude, this.vars.CurrentBox) === 0)) {
        this.warp(this.intCuboidsIntersect)(
          ax,
          bx,
          ay,
          by,
          az,
          bz,
          this.itemOf(
            this.stage.vars.collisionBoxesX1,
            this.vars.CurrentBox - 1
          ),
          this.itemOf(
            this.stage.vars.collisionBoxesX2,
            this.vars.CurrentBox - 1
          ),
          this.itemOf(
            this.stage.vars.collisionBoxesY1,
            this.vars.CurrentBox - 1
          ),
          this.itemOf(
            this.stage.vars.collisionBoxesY2,
            this.vars.CurrentBox - 1
          ),
          this.itemOf(
            this.stage.vars.collisionBoxesZ1,
            this.vars.CurrentBox - 1
          ),
          this.itemOf(
            this.stage.vars.collisionBoxesZ2,
            this.vars.CurrentBox - 1
          )
        );
        if (this.compare(this.vars.CurrentCollision, 0 === "") === 0) {
          this.vars.Return = 1;
        }
      }
      this.vars.CurrentBox++;
    }
    if (this.toNumber(this.vars.Return) === 0) {
      this.vars.CurrentBox = 1;
      while (
        !(
          this.compare(
            this.vars.CurrentBox,
            this.stage.vars.collisionBoxesRXData.length / 6
          ) > 0 || this.toNumber(this.vars.Return) === 1
        )
      ) {
        this.warp(this.intInsersectsCuboidConvexHull)(
          ax,
          bx,
          ay,
          by,
          az,
          bz,
          this.vars.CurrentBox
        );
        if (this.toNumber(this.vars.CurrentCollision) === 1) {
          this.vars.Return = 1;
        }
        this.vars.CurrentBox++;
      }
      this.vars.CurrentBox = 0 - this.toNumber(this.vars.CurrentBox);
    }
  }

  *whenIReceiveSystemPhysicsTick() {
    if (this.toNumber(this.vars.DoorAction) === 0) {
      if (
        this.keyPressed("e") &&
        this.compare(this.sprites["Messages"].vars.DoorDistance, 200) < 0 &&
        this.compare(
          this.timer - this.toNumber(this.vars.DoorActionStart),
          0.6
        ) > 0
      ) {
        yield* this.setCustomPropertyValueToCustomPropertyOfObject(1, 3);
        this.vars.DoorActionStart = this.timer;
        this.vars.DoorAction =
          1 + (1 - this.toNumber(this.vars.CustomPropertyValue));
        yield* this.playSoundAtDistanceRadiusMaxVolume(
          this.vars.DoorAction,
          this.sprites["Messages"].vars.DoorDistance,
          1500,
          100
        );
      }
    } else {
      if (
        this.compare(
          this.timer - this.toNumber(this.vars.DoorActionStart),
          0.2
        ) < 0
      ) {
        if (this.toNumber(this.vars.DoorAction) === 2) {
          this.stage.vars.objectsRotX.splice(
            2,
            1,
            90 * ((this.timer - this.toNumber(this.vars.DoorActionStart)) / 0.2)
          );
        } else {
          this.stage.vars.objectsRotX.splice(
            2,
            1,
            90 -
              90 *
                ((this.timer - this.toNumber(this.vars.DoorActionStart)) / 0.2)
          );
        }
        yield* this.updateWorldDataForObject(3);
      } else {
        yield* this.setCustomPropertyValueToCustomPropertyOfObject(1, 3);
        yield* this.setCustomPropertyOfObjectTo(
          1,
          3,
          1 - this.toNumber(this.vars.CustomPropertyValue)
        );
        this.vars.DoorAction = 0;
        this.vars.DoorActionStart = 0;
        this.stage.vars.objectsRotX.splice(
          2,
          1,
          (1 - this.toNumber(this.vars.CustomPropertyValue)) * 90
        );
        yield* this.updateWorldDataForObject(3);
        if (this.toNumber(this.vars.CustomPropertyValue) === 1) {
          yield* this.setCollisionBoxToXYZWidthHeightDepthPadding(
            3,
            240,
            0,
            0,
            90,
            170,
            0,
            15
          );
        } else {
          yield* this.setCollisionBoxToXYZWidthHeightDepthPadding(
            3,
            240,
            0,
            -90,
            0,
            170,
            90,
            15
          );
        }
      }
    }
  }
}
