/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Objects extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("icon", "./Objects/costumes/icon.svg", { x: 242, y: 175 }),
    ];

    this.sounds = [];

    this.triggers = [
      new Trigger(
        Trigger.BROADCAST,
        { name: "init: create objects" },
        this.whenIReceiveInitCreateObjects
      ),
    ];

    this.vars.PointX = 4900;
    this.vars.PointY = 350;
    this.vars.PointZ = -1600;
    this.vars.Point = 102;
    this.vars.Edge10 = 5.916655663799986;
    this.vars.Edge11 = 0;
    this.vars.Edge12 = 12.688309017999984;
    this.vars.Edge20 = 33.10588927379999;
    this.vars.Edge21 = 0;
    this.vars.Edge22 = 0.009761166999965099;
    this.vars.Surface = 119;
    this.vars.V0 = 0;
    this.vars.V1 = 419.99999995764966;
    this.vars.V2 = 0;
    this.vars.CurrentItem = 21;
    this.vars.CurrentLetter = 2;
    this.vars.Dist = 419.99999995764966;
    this.vars.Matrix = [];
    this.vars.TempList = [];
  }

  *clearObjectData() {
    this.vars.Matrix = [];
    this.vars.TempList = [];
    this.stage.vars.objectsX = [];
    this.stage.vars.objectsY = [];
    this.stage.vars.objectsZ = [];
    this.stage.vars.objectsRotX = [];
    this.stage.vars.objectsRotY = [];
    this.stage.vars.objectsRotZ = [];
    this.stage.vars.objectsSurfaces = [];
    this.stage.vars.objectsSurfacesIndex = [];
    this.stage.vars.objectsPointsIndex = [];
    this.stage.vars.objectsVisible = [];
    this.stage.vars.objectsShadows = [];
    this.stage.vars.objectsCustomProperties = [];
    this.stage.vars.objectsTag = [];
    this.stage.vars.pointDataX = [];
    this.stage.vars.pointDataY = [];
    this.stage.vars.pointDataZ = [];
    this.stage.vars.worldDataX = [];
    this.stage.vars.worldDataY = [];
    this.stage.vars.worldDataZ = [];
    this.stage.vars.surfacesP1 = [];
    this.stage.vars.surfacesP2 = [];
    this.stage.vars.surfacesP3 = [];
    this.stage.vars.surfacesP4 = [];
    this.stage.vars.surfacesDiameter = [];
    this.stage.vars.surfacesType = [];
    this.stage.vars.surfacesTexture = [];
    this.stage.vars.surfacesLightSource = [];
    this.stage.vars.surfacesN0 = [];
    this.stage.vars.surfacesN1 = [];
    this.stage.vars.surfacesN2 = [];
    this.stage.vars.objectsPointsIndex.push(0);
  }

  *beginObjectXYZRotXRotYRotZHiddenNoShadowsTag(
    x,
    y,
    z,
    rotX,
    rotY,
    rotZ,
    hidden,
    noShadows,
    tag
  ) {
    this.stage.vars.objectsX.push(x);
    this.stage.vars.objectsY.push(y);
    this.stage.vars.objectsZ.push(z);
    this.stage.vars.objectsRotX.push(rotX);
    this.stage.vars.objectsRotY.push(rotY);
    this.stage.vars.objectsRotZ.push(rotZ);
    this.stage.vars.objectsSurfaces.push(0);
    this.stage.vars.objectsSurfacesIndex.push(
      this.stage.vars.surfacesP1.length + 1
    );
    this.stage.vars.objectsVisible.push(this.toNumber(!hidden) + 0);
    this.stage.vars.objectsShadows.push(this.toNumber(!noShadows) + 0);
    this.stage.vars.objectsTag.push(tag);
    for (
      let i = 0;
      i < this.toNumber(this.stage.vars.numCustomProperties);
      i++
    ) {
      this.stage.vars.objectsCustomProperties.push("");
    }
  }

  *addPointXYZ(x, y, z) {
    this.stage.vars.pointDataX.push(x);
    this.stage.vars.pointDataY.push(y);
    this.stage.vars.pointDataZ.push(z);
    this.stage.vars.worldDataX.push("");
    this.stage.vars.worldDataY.push("");
    this.stage.vars.worldDataZ.push("");
  }

  *addTriSurfaceP1P2P3TextureIdLightSource(
    point1,
    point2,
    point3,
    texture,
    light
  ) {
    this.stage.vars.surfacesP1.push(
      this.toNumber(point1) +
        this.toNumber(
          this.itemOf(
            this.stage.vars.objectsPointsIndex,
            this.stage.vars.objectsPointsIndex.length - 1
          )
        )
    );
    this.stage.vars.surfacesP2.push(
      this.toNumber(point2) +
        this.toNumber(
          this.itemOf(
            this.stage.vars.objectsPointsIndex,
            this.stage.vars.objectsPointsIndex.length - 1
          )
        )
    );
    this.stage.vars.surfacesP3.push(
      this.toNumber(point3) +
        this.toNumber(
          this.itemOf(
            this.stage.vars.objectsPointsIndex,
            this.stage.vars.objectsPointsIndex.length - 1
          )
        )
    );
    this.stage.vars.surfacesP4.push("");
    this.stage.vars.surfacesDiameter.push("");
    this.stage.vars.surfacesType.push(1);
    this.stage.vars.surfacesTexture.push(texture);
    this.stage.vars.surfacesLightSource.push(light);
    this.stage.vars.surfacesN0.push("");
    this.stage.vars.surfacesN1.push("");
    this.stage.vars.surfacesN2.push("");
    this.stage.vars.objectsSurfaces.splice(
      "last",
      1,
      this.toNumber(
        this.itemOf(
          this.stage.vars.objectsSurfaces,
          this.stage.vars.objectsSurfaces.length - 1
        )
      ) + 1
    );
  }

  *addLineSurfaceP1P2WidthTextureIdLightSource(
    point1,
    point2,
    width,
    textureId,
    light
  ) {
    this.stage.vars.surfacesP1.push(
      this.toNumber(point1) +
        this.toNumber(
          this.itemOf(
            this.stage.vars.objectsPointsIndex,
            this.stage.vars.objectsPointsIndex.length - 1
          )
        )
    );
    this.stage.vars.surfacesP2.push(
      this.toNumber(point2) +
        this.toNumber(
          this.itemOf(
            this.stage.vars.objectsPointsIndex,
            this.stage.vars.objectsPointsIndex.length - 1
          )
        )
    );
    this.stage.vars.surfacesP3.push("");
    this.stage.vars.surfacesP4.push("");
    this.stage.vars.surfacesDiameter.push(width);
    this.stage.vars.surfacesType.push(3);
    this.stage.vars.surfacesTexture.push(textureId);
    this.stage.vars.surfacesLightSource.push(light);
    this.stage.vars.surfacesN0.push("");
    this.stage.vars.surfacesN1.push("");
    this.stage.vars.surfacesN2.push("");
    this.stage.vars.objectsSurfaces.splice(
      "last",
      1,
      this.toNumber(
        this.itemOf(
          this.stage.vars.objectsSurfaces,
          this.stage.vars.objectsSurfaces.length - 1
        )
      ) + 1
    );
  }

  *addSphereSurfaceOriginDiameterTextureIdLightSource(
    origin,
    diameter,
    textureId,
    light
  ) {
    this.stage.vars.surfacesP1.push(
      this.toNumber(origin) +
        this.toNumber(
          this.itemOf(
            this.stage.vars.objectsPointsIndex,
            this.stage.vars.objectsPointsIndex.length - 1
          )
        )
    );
    this.stage.vars.surfacesP2.push("");
    this.stage.vars.surfacesP3.push("");
    this.stage.vars.surfacesP4.push("");
    this.stage.vars.surfacesDiameter.push(diameter);
    this.stage.vars.surfacesType.push(4);
    this.stage.vars.surfacesTexture.push(textureId);
    this.stage.vars.surfacesLightSource.push(light);
    this.stage.vars.surfacesN0.push("");
    this.stage.vars.surfacesN1.push("");
    this.stage.vars.surfacesN2.push("");
    this.stage.vars.objectsSurfaces.splice(
      "last",
      1,
      this.toNumber(
        this.itemOf(
          this.stage.vars.objectsSurfaces,
          this.stage.vars.objectsSurfaces.length - 1
        )
      ) + 1
    );
  }

  *endObject() {
    this.stage.vars.objectsPointsIndex.push(this.stage.vars.pointDataX.length);
    this.warp(this.intUpdateObjectWorldData)(this.stage.vars.objectsX.length);
  }

  *importObjFileFromMListCentreXYZRotXRotYRotZTextureLightSourceScaleBy(
    list,
    x,
    y,
    z,
    rotX,
    rotY,
    rotZ,
    texture,
    lightSource
  ) {
    this.warp(this.beginObjectXYZRotXRotYRotZHiddenNoShadowsTag)(
      x,
      y,
      z,
      rotX,
      rotY,
      rotZ,
      0,
      0,
      list
    );
    this.vars.CurrentItem = 1;
    for (let i = 0; i < this.stage.vars.getparamListR.length; i++) {
      if (
        this.compare(
          this.itemOf(this.stage.vars.getparamListR, this.vars.CurrentItem - 1)
            .length,
          0
        ) > 0
      ) {
        this.vars.TempList = [];
        this.vars.TempList.push("");
        this.vars.CurrentLetter = 1;
        for (
          let i = 0;
          i <
          this.itemOf(this.stage.vars.getparamListR, this.vars.CurrentItem - 1)
            .length;
          i++
        ) {
          if (
            this.toNumber(
              this.letterOf(
                this.itemOf(
                  this.stage.vars.getparamListR,
                  this.vars.CurrentItem - 1
                ),
                this.vars.CurrentLetter - 1
              )
            ) === 0
          ) {
            if (
              !(
                this.toNumber(
                  this.itemOf(this.vars.TempList, this.vars.TempList.length - 1)
                ) === 0
              )
            ) {
              this.vars.TempList.push("");
            }
          } else {
            this.vars.TempList.splice(
              "last",
              1,
              this.toString(
                this.itemOf(this.vars.TempList, this.vars.TempList.length - 1)
              ) +
                this.letterOf(
                  this.itemOf(
                    this.stage.vars.getparamListR,
                    this.vars.CurrentItem - 1
                  ),
                  this.vars.CurrentLetter - 1
                )
            );
          }
          this.vars.CurrentLetter++;
        }
        if (this.toString(this.itemOf(this.vars.TempList, 0)) === "v") {
          this.warp(this.addPointXYZ)(
            this.toNumber(this.itemOf(this.vars.TempList, 1)) *
              this.toNumber(undefined),
            this.toNumber(this.itemOf(this.vars.TempList, 2)) *
              this.toNumber(undefined),
            this.toNumber(this.itemOf(this.vars.TempList, 3)) *
              this.toNumber(undefined)
          );
        } else {
          if (this.toString(this.itemOf(this.vars.TempList, 0)) === "f") {
            this.warp(this.intGetPointNumber)(
              this.itemOf(this.vars.TempList, 1)
            );
            this.vars.V0 = this.vars.Point;
            this.warp(this.intGetPointNumber)(
              this.itemOf(this.vars.TempList, 2)
            );
            this.vars.V1 = this.vars.Point;
            this.warp(this.intGetPointNumber)(
              this.itemOf(this.vars.TempList, 3)
            );
            this.vars.V2 = this.vars.Point;
            if (this.vars.TempList.length === 4) {
              this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(
                this.vars.V0,
                this.vars.V1,
                this.vars.V2,
                texture,
                lightSource
              );
            } else {
              if (this.vars.TempList.length === 5) {
                this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(
                  this.vars.V0,
                  this.vars.V1,
                  this.vars.V2,
                  texture,
                  lightSource
                );
                this.warp(this.intGetPointNumber)(
                  this.itemOf(this.vars.TempList, 3)
                );
                this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(
                  this.vars.V1,
                  this.vars.V2,
                  this.vars.Point,
                  texture,
                  lightSource
                );
              } else {
                null;
              }
            }
          } else {
            null;
          }
        }
      }
      this.vars.CurrentItem++;
    }
    this.warp(this.endObject)();
  }

  *samplesTriangle() {
    this.warp(this.beginObjectXYZRotXRotYRotZHiddenNoShadowsTag)(
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    );
    this.warp(this.addPointXYZ)(-100, 0, 0);
    this.warp(this.addPointXYZ)(100, 200, 0);
    this.warp(this.addPointXYZ)(100, 0, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(1, 2, 3, 1, 0);
    this.warp(this.endObject)();
  }

  *samplesWall() {
    yield* this.beginObjectXYZRotXRotYRotZHiddenNoShadowsTag(
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    );
    yield* this.addPointXYZ(-100, 0, 0);
    yield* this.addPointXYZ(100, 200, 0);
    yield* this.addPointXYZ(100, 0, 0);
    yield* this.addPointXYZ(-100, 200, 0);
    yield* this.addTriSurfaceP1P2P3TextureIdLightSource(1, 2, 3, 1, 0);
    yield* this.addTriSurfaceP1P2P3TextureIdLightSource(1, 4, 2, 1, 0);
    yield* this.endObject();
  }

  *samplesCube() {
    yield* this.beginObjectXYZRotXRotYRotZHiddenNoShadowsTag(
      0,
      100,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    );
    yield* this.addPointXYZ(-100, -100, -100);
    yield* this.addPointXYZ(100, -100, -100);
    yield* this.addPointXYZ(100, -100, 100);
    yield* this.addPointXYZ(-100, -100, 100);
    yield* this.addPointXYZ(-100, 100, -100);
    yield* this.addPointXYZ(100, 100, -100);
    yield* this.addPointXYZ(100, 100, 100);
    yield* this.addPointXYZ(-100, 100, 100);
    yield* this.addTriSurfaceP1P2P3TextureIdLightSource(1, 6, 2, 1, 0);
    yield* this.addTriSurfaceP1P2P3TextureIdLightSource(1, 5, 6, 1, 0);
    yield* this.addTriSurfaceP1P2P3TextureIdLightSource(1, 4, 5, 1, 0);
    yield* this.addTriSurfaceP1P2P3TextureIdLightSource(4, 8, 5, 1, 0);
    yield* this.addTriSurfaceP1P2P3TextureIdLightSource(4, 3, 8, 1, 0);
    yield* this.addTriSurfaceP1P2P3TextureIdLightSource(3, 7, 8, 1, 0);
    yield* this.addTriSurfaceP1P2P3TextureIdLightSource(3, 2, 7, 1, 0);
    yield* this.addTriSurfaceP1P2P3TextureIdLightSource(6, 7, 2, 1, 0);
    yield* this.addTriSurfaceP1P2P3TextureIdLightSource(7, 6, 5, 1, 0);
    yield* this.addTriSurfaceP1P2P3TextureIdLightSource(5, 8, 7, 1, 0);
    yield* this.addTriSurfaceP1P2P3TextureIdLightSource(1, 2, 3, 1, 0);
    yield* this.addTriSurfaceP1P2P3TextureIdLightSource(3, 4, 1, 1, 0);
    yield* this.endObject();
  }

  *samplesCubeRotated() {
    this.warp(this.beginObjectXYZRotXRotYRotZHiddenNoShadowsTag)(
      350,
      300,
      -100,
      50,
      70,
      120,
      0,
      0,
      0
    );
    this.warp(this.addPointXYZ)(-100, -100, -100);
    this.warp(this.addPointXYZ)(100, -100, -100);
    this.warp(this.addPointXYZ)(100, -100, 100);
    this.warp(this.addPointXYZ)(-100, -100, 100);
    this.warp(this.addPointXYZ)(-100, 100, -100);
    this.warp(this.addPointXYZ)(100, 100, -100);
    this.warp(this.addPointXYZ)(100, 100, 100);
    this.warp(this.addPointXYZ)(-100, 100, 100);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(1, 6, 2, 1, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(1, 5, 6, 1, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(1, 4, 5, 1, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(4, 8, 5, 1, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(4, 3, 8, 1, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(3, 7, 8, 1, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(3, 2, 7, 1, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(6, 7, 2, 1, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(7, 6, 5, 1, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(5, 8, 7, 1, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(1, 2, 3, 1, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(3, 4, 1, 1, 0);
    this.warp(this.endObject)();
  }

  *samplesSphere() {
    this.warp(this.beginObjectXYZRotXRotYRotZHiddenNoShadowsTag)(
      0,
      100,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    );
    this.warp(this.addPointXYZ)(0, 0, 0);
    this.warp(this.addSphereSurfaceOriginDiameterTextureIdLightSource)(
      1,
      100,
      1,
      0
    );
    this.warp(this.endObject)();
  }

  *samplesLine() {
    this.warp(this.beginObjectXYZRotXRotYRotZHiddenNoShadowsTag)(
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    );
    this.warp(this.addPointXYZ)(0, 0, 0);
    this.warp(this.addPointXYZ)(0, 200, 0);
    this.warp(this.addLineSurfaceP1P2WidthTextureIdLightSource)(1, 2, 20, 1, 0);
    this.warp(this.endObject)();
  }

  *samplesTree() {
    this.warp(this.beginObjectXYZRotXRotYRotZHiddenNoShadowsTag)(
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    );
    this.warp(this.addPointXYZ)(0, 0, 0);
    this.warp(this.addPointXYZ)(0, 200, 0);
    this.warp(this.addPointXYZ)(0, 350, 0);
    this.warp(this.addLineSurfaceP1P2WidthTextureIdLightSource)(1, 2, 70, 1, 0);
    this.warp(this.addSphereSurfaceOriginDiameterTextureIdLightSource)(
      3,
      300,
      2,
      0
    );
    this.warp(this.endObject)();
  }

  *intUpdateObjectWorldData(object) {
    this.warp(this.intCreateObjectWorldTransformation)(
      this.itemOf(this.stage.vars.objectsX, object - 1),
      this.itemOf(this.stage.vars.objectsY, object - 1),
      this.itemOf(this.stage.vars.objectsZ, object - 1),
      Math.sin(
        this.degToRad(
          this.toNumber(this.itemOf(this.stage.vars.objectsRotX, object - 1))
        )
      ),
      Math.cos(
        this.degToRad(
          this.toNumber(this.itemOf(this.stage.vars.objectsRotX, object - 1))
        )
      ),
      Math.sin(
        this.degToRad(
          this.toNumber(this.itemOf(this.stage.vars.objectsRotY, object - 1))
        )
      ),
      Math.cos(
        this.degToRad(
          this.toNumber(this.itemOf(this.stage.vars.objectsRotY, object - 1))
        )
      ),
      Math.sin(
        this.degToRad(
          this.toNumber(this.itemOf(this.stage.vars.objectsRotZ, object - 1))
        )
      ),
      Math.cos(
        this.degToRad(
          this.toNumber(this.itemOf(this.stage.vars.objectsRotZ, object - 1))
        )
      )
    );
    this.vars.Point =
      this.toNumber(
        this.itemOf(this.stage.vars.objectsPointsIndex, object - 1)
      ) + 1;
    for (
      let i = 0;
      i <
      this.toNumber(
        this.itemOf(this.stage.vars.objectsPointsIndex, this.toNumber(object))
      ) -
        this.toNumber(
          this.itemOf(this.stage.vars.objectsPointsIndex, object - 1)
        );
      i++
    ) {
      this.warp(this.intTransformVertex)(
        this.itemOf(this.stage.vars.pointDataX, this.vars.Point - 1),
        this.itemOf(this.stage.vars.pointDataY, this.vars.Point - 1),
        this.itemOf(this.stage.vars.pointDataZ, this.vars.Point - 1)
      );
      this.stage.vars.worldDataX.splice(
        this.vars.Point - 1,
        1,
        this.vars.PointX
      );
      this.stage.vars.worldDataY.splice(
        this.vars.Point - 1,
        1,
        this.vars.PointY
      );
      this.stage.vars.worldDataZ.splice(
        this.vars.Point - 1,
        1,
        this.vars.PointZ
      );
      this.vars.Point++;
    }
    this.vars.Surface = this.itemOf(
      this.stage.vars.objectsSurfacesIndex,
      object - 1
    );
    for (
      let i = 0;
      i <
      this.toNumber(this.itemOf(this.stage.vars.objectsSurfaces, object - 1));
      i++
    ) {
      if (
        this.compare(
          this.itemOf(this.stage.vars.surfacesType, this.vars.Surface - 1),
          3
        ) < 0
      ) {
        this.vars.Edge10 =
          this.toNumber(
            this.itemOf(
              this.stage.vars.worldDataX,
              this.itemOf(this.stage.vars.surfacesP2, this.vars.Surface - 1) - 1
            )
          ) -
          this.toNumber(
            this.itemOf(
              this.stage.vars.worldDataX,
              this.itemOf(this.stage.vars.surfacesP1, this.vars.Surface - 1) - 1
            )
          );
        this.vars.Edge11 =
          this.toNumber(
            this.itemOf(
              this.stage.vars.worldDataY,
              this.itemOf(this.stage.vars.surfacesP2, this.vars.Surface - 1) - 1
            )
          ) -
          this.toNumber(
            this.itemOf(
              this.stage.vars.worldDataY,
              this.itemOf(this.stage.vars.surfacesP1, this.vars.Surface - 1) - 1
            )
          );
        this.vars.Edge12 =
          this.toNumber(
            this.itemOf(
              this.stage.vars.worldDataZ,
              this.itemOf(this.stage.vars.surfacesP2, this.vars.Surface - 1) - 1
            )
          ) -
          this.toNumber(
            this.itemOf(
              this.stage.vars.worldDataZ,
              this.itemOf(this.stage.vars.surfacesP1, this.vars.Surface - 1) - 1
            )
          );
        this.vars.Edge20 =
          this.toNumber(
            this.itemOf(
              this.stage.vars.worldDataX,
              this.itemOf(this.stage.vars.surfacesP3, this.vars.Surface - 1) - 1
            )
          ) -
          this.toNumber(
            this.itemOf(
              this.stage.vars.worldDataX,
              this.itemOf(this.stage.vars.surfacesP1, this.vars.Surface - 1) - 1
            )
          );
        this.vars.Edge21 =
          this.toNumber(
            this.itemOf(
              this.stage.vars.worldDataY,
              this.itemOf(this.stage.vars.surfacesP3, this.vars.Surface - 1) - 1
            )
          ) -
          this.toNumber(
            this.itemOf(
              this.stage.vars.worldDataY,
              this.itemOf(this.stage.vars.surfacesP1, this.vars.Surface - 1) - 1
            )
          );
        this.vars.Edge22 =
          this.toNumber(
            this.itemOf(
              this.stage.vars.worldDataZ,
              this.itemOf(this.stage.vars.surfacesP3, this.vars.Surface - 1) - 1
            )
          ) -
          this.toNumber(
            this.itemOf(
              this.stage.vars.worldDataZ,
              this.itemOf(this.stage.vars.surfacesP1, this.vars.Surface - 1) - 1
            )
          );
        this.vars.V0 =
          this.toNumber(this.vars.Edge11) * this.toNumber(this.vars.Edge22) -
          this.toNumber(this.vars.Edge12) * this.toNumber(this.vars.Edge21);
        this.vars.V1 =
          this.toNumber(this.vars.Edge12) * this.toNumber(this.vars.Edge20) -
          this.toNumber(this.vars.Edge10) * this.toNumber(this.vars.Edge22);
        this.vars.V2 =
          this.toNumber(this.vars.Edge10) * this.toNumber(this.vars.Edge21) -
          this.toNumber(this.vars.Edge11) * this.toNumber(this.vars.Edge20);
        this.vars.Dist = Math.sqrt(
          this.toNumber(this.vars.V0) * this.toNumber(this.vars.V0) +
            (this.toNumber(this.vars.V1) * this.toNumber(this.vars.V1) +
              this.toNumber(this.vars.V2) * this.toNumber(this.vars.V2))
        );
        this.stage.vars.surfacesN0.splice(
          this.vars.Surface - 1,
          1,
          this.toNumber(this.vars.V0) / this.toNumber(this.vars.Dist)
        );
        this.stage.vars.surfacesN1.splice(
          this.vars.Surface - 1,
          1,
          this.toNumber(this.vars.V1) / this.toNumber(this.vars.Dist)
        );
        this.stage.vars.surfacesN2.splice(
          this.vars.Surface - 1,
          1,
          this.toNumber(this.vars.V2) / this.toNumber(this.vars.Dist)
        );
      }
      this.vars.Surface++;
    }
  }

  *intCreateObjectWorldTransformation(
    x,
    y,
    z,
    sinRotX,
    cosRotX,
    sinRotY,
    cosRotY,
    sinRotZ,
    cosRotZ
  ) {
    this.vars.undefined = [];
    this.vars.undefined.push(this.toNumber(cosRotZ) * this.toNumber(cosRotX));
    this.vars.undefined.push(
      this.toNumber(cosRotZ) *
        (this.toNumber(sinRotX) * this.toNumber(sinRotY)) -
        this.toNumber(sinRotZ) * this.toNumber(cosRotY)
    );
    this.vars.undefined.push(
      this.toNumber(cosRotZ) *
        (this.toNumber(sinRotX) * this.toNumber(cosRotY)) +
        this.toNumber(sinRotZ) * this.toNumber(sinRotY)
    );
    this.vars.undefined.push(x);
    this.vars.undefined.push(this.toNumber(sinRotZ) * this.toNumber(cosRotX));
    this.vars.undefined.push(
      this.toNumber(sinRotZ) *
        (this.toNumber(sinRotX) * this.toNumber(sinRotY)) +
        this.toNumber(cosRotZ) * this.toNumber(cosRotY)
    );
    this.vars.undefined.push(
      this.toNumber(sinRotZ) *
        (this.toNumber(sinRotX) * this.toNumber(cosRotY)) -
        this.toNumber(cosRotZ) * this.toNumber(sinRotY)
    );
    this.vars.undefined.push(y);
    this.vars.undefined.push(0 - this.toNumber(sinRotX));
    this.vars.undefined.push(this.toNumber(cosRotX) * this.toNumber(sinRotY));
    this.vars.undefined.push(this.toNumber(cosRotX) * this.toNumber(cosRotY));
    this.vars.undefined.push(z);
  }

  *intTransformVertex(x, y, z) {
    this.vars.PointX =
      this.toNumber(this.itemOf(this.vars.Matrix, 0)) * this.toNumber(x) +
      this.toNumber(this.itemOf(this.vars.Matrix, 1)) * this.toNumber(y) +
      (this.toNumber(this.itemOf(this.vars.Matrix, 2)) * this.toNumber(z) +
        this.toNumber(this.itemOf(this.vars.Matrix, 3)));
    this.vars.PointY =
      this.toNumber(this.itemOf(this.vars.Matrix, 4)) * this.toNumber(x) +
      this.toNumber(this.itemOf(this.vars.Matrix, 5)) * this.toNumber(y) +
      (this.toNumber(this.itemOf(this.vars.Matrix, 6)) * this.toNumber(z) +
        this.toNumber(this.itemOf(this.vars.Matrix, 7)));
    this.vars.PointZ =
      this.toNumber(this.itemOf(this.vars.Matrix, 8)) * this.toNumber(x) +
      this.toNumber(this.itemOf(this.vars.Matrix, 9)) * this.toNumber(y) +
      (this.toNumber(this.itemOf(this.vars.Matrix, 10)) * this.toNumber(z) +
        this.toNumber(this.itemOf(this.vars.Matrix, 11)));
  }

  *intGetPointNumber(vertexInfo) {
    this.vars.Point = "";
    this.vars.CurrentLetter = 1;
    while (
      !(
        this.letterOf(vertexInfo, this.vars.CurrentLetter - 1) === "/" ||
        this.compare(this.vars.CurrentLetter, vertexInfo.length) > 0
      )
    ) {
      this.vars.Point =
        this.toString(this.vars.Point) +
        this.letterOf(vertexInfo, this.vars.CurrentLetter - 1);
      this.vars.CurrentLetter++;
    }
  }

  *whenIReceiveInitCreateObjects() {
    yield* this.clearObjectData();
    yield* this.giveEachObjectCustomProperties(1);
    yield* this.initClockTowerTop();
    yield* this.initClockTowerBase();
    yield* this.initDoor();
    yield* this.initMainBuilding();
    yield* this.initLadder();
    yield* this.initTable();
    yield* this.initRadio();
    yield* this.initRandTrees(10);
  }

  *initClockTowerTop() {
    this.warp(this.beginObjectXYZRotXRotYRotZHiddenNoShadowsTag)(
      -200,
      400,
      60,
      0,
      0,
      0,
      0,
      0,
      "building"
    );
    this.warp(this.addPointXYZ)(-60, 60, -60);
    this.warp(this.addPointXYZ)(60, 60, -60);
    this.warp(this.addPointXYZ)(60, -60, -60);
    this.warp(this.addPointXYZ)(-60, -60, -60);
    this.warp(this.addPointXYZ)(-60, 60, 60);
    this.warp(this.addPointXYZ)(-60, -60, 60);
    this.warp(this.addPointXYZ)(60, 60, 60);
    this.warp(this.addPointXYZ)(60, -60, 60);
    this.warp(this.addPointXYZ)(0, 220, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(1, 2, 3, 1, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(3, 4, 1, 1, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(6, 5, 1, 1, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(1, 4, 6, 1, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(2, 7, 8, 1, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(8, 3, 2, 1, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(8, 7, 5, 1, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(5, 6, 8, 1, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(1, 9, 2, 1, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(2, 9, 7, 1, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(7, 9, 5, 1, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(5, 9, 1, 1, 0);
    this.warp(this.endObject)();
  }

  *initClockTowerBase() {
    this.warp(this.beginObjectXYZRotXRotYRotZHiddenNoShadowsTag)(
      -200,
      0,
      60,
      0,
      0,
      0,
      0,
      0,
      "building"
    );
    this.warp(this.addPointXYZ)(60, 0, -60);
    this.warp(this.addPointXYZ)(-60, 0, -60);
    this.warp(this.addPointXYZ)(-60, 0, 60);
    this.warp(this.addPointXYZ)(60, 0, 60);
    this.warp(this.addPointXYZ)(60, 340, -60);
    this.warp(this.addPointXYZ)(-60, 340, -60);
    this.warp(this.addPointXYZ)(-60, 340, 60);
    this.warp(this.addPointXYZ)(60, 340, 60);
    this.warp(this.addPointXYZ)(60, 200, -60);
    this.warp(this.addPointXYZ)(60, 200, 60);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(1, 2, 6, 2, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(1, 6, 5, 2, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(5, 10, 9, 2, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(5, 8, 10, 2, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(3, 4, 8, 2, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(8, 7, 3, 2, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(2, 3, 7, 2, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(7, 6, 2, 2, 0);
    this.warp(this.endObject)();
  }

  *initDoor() {
    this.warp(this.beginObjectXYZRotXRotYRotZHiddenNoShadowsTag)(
      240,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      "door"
    );
    this.warp(this.setCustomPropertyTo)(1, 0);
    this.warp(this.addPointXYZ)(0, 0, 0);
    this.warp(this.addPointXYZ)(90, 0, 0);
    this.warp(this.addPointXYZ)(90, 170, 0);
    this.warp(this.addPointXYZ)(0, 170, 0);
    this.warp(this.addPointXYZ)(80, 80, -5);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(3, 2, 1, 3, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(4, 3, 1, 3, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(1, 2, 3, 4, 1);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(1, 3, 4, 4, 1);
    this.warp(this.addSphereSurfaceOriginDiameterTextureIdLightSource)(
      5,
      10,
      10,
      0
    );
    this.warp(this.endObject)();
  }

  *initMainBuilding() {
    this.warp(this.beginObjectXYZRotXRotYRotZHiddenNoShadowsTag)(
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      "building"
    );
    this.warp(this.addPointXYZ)(-140, 0, 0);
    this.warp(this.addPointXYZ)(360, 0, 0);
    this.warp(this.addPointXYZ)(360, 0, 300);
    this.warp(this.addPointXYZ)(-140, 0, 300);
    this.warp(this.addPointXYZ)(-140, 200, 0);
    this.warp(this.addPointXYZ)(360, 200, 0);
    this.warp(this.addPointXYZ)(360, 200, 300);
    this.warp(this.addPointXYZ)(-140, 200, 300);
    this.warp(this.addPointXYZ)(-140, 0, 120);
    this.warp(this.addPointXYZ)(-140, 200, 120);
    this.warp(this.addPointXYZ)(240, 0, 0);
    this.warp(this.addPointXYZ)(240, 170, 0);
    this.warp(this.addPointXYZ)(330, 200, 0);
    this.warp(this.addPointXYZ)(240, 200, 0);
    this.warp(this.addPointXYZ)(330, 0, 0);
    this.warp(this.addPointXYZ)(-140, 170, 0);
    this.warp(this.addPointXYZ)(330, 170, 0);
    this.warp(this.addPointXYZ)(-40, 80, 0);
    this.warp(this.addPointXYZ)(160, 80, 0);
    this.warp(this.addPointXYZ)(160, 170, 0);
    this.warp(this.addPointXYZ)(-40, 170, 0);
    this.warp(this.addPointXYZ)(160, 0, 0);
    this.warp(this.addPointXYZ)(-40, 0, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(16, 21, 1, 5, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(21, 23, 1, 5, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(22, 23, 19, 5, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(23, 18, 19, 5, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(22, 20, 12, 5, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(22, 12, 11, 5, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(20, 19, 18, 6, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(21, 20, 18, 6, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(6, 2, 15, 5, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(15, 13, 6, 5, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(12, 16, 5, 5, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(5, 14, 12, 5, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(13, 17, 12, 5, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(12, 14, 13, 5, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(6, 3, 2, 5, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(3, 6, 7, 5, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(7, 4, 3, 5, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(7, 8, 4, 5, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(10, 9, 8, 5, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(4, 8, 9, 5, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(1, 21, 16, 7, 1);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(1, 23, 21, 7, 1);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(19, 23, 22, 7, 1);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(19, 18, 23, 7, 1);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(12, 20, 22, 7, 1);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(11, 12, 22, 7, 1);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(18, 19, 20, 6, 1);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(18, 20, 21, 6, 1);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(15, 2, 6, 7, 1);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(6, 13, 15, 7, 1);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(5, 16, 12, 7, 1);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(12, 14, 5, 7, 1);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(12, 17, 13, 7, 1);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(13, 14, 12, 7, 1);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(2, 3, 6, 7, 1);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(7, 6, 3, 7, 1);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(3, 4, 7, 7, 1);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(4, 8, 7, 7, 1);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(8, 1, 5, 7, 1);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(1, 8, 4, 7, 1);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(5, 6, 8, 9, 1);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(6, 7, 8, 9, 1);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(3, 2, 1, 8, 1);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(4, 3, 1, 8, 1);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(8, 6, 5, 14, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(8, 7, 6, 14, 0);
    this.warp(this.endObject)();
  }

  *initLadder() {
    this.warp(this.beginObjectXYZRotXRotYRotZHiddenNoShadowsTag)(
      360,
      0,
      300,
      0,
      0,
      0,
      0,
      0,
      "steps"
    );
    this.warp(this.addPointXYZ)(-300, 0, 0);
    this.warp(this.addPointXYZ)(-300, 0, 100);
    this.warp(this.addPointXYZ)(-100, 200, 0);
    this.warp(this.addPointXYZ)(-100, 200, 100);
    this.warp(this.addPointXYZ)(0, 200, 0);
    this.warp(this.addPointXYZ)(0, 200, 100);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(1, 2, 3, 13, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(2, 4, 3, 13, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(3, 2, 1, 13, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(3, 4, 2, 13, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(3, 4, 5, 13, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(6, 5, 4, 13, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(5, 4, 3, 13, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(4, 5, 6, 13, 0);
    this.warp(this.endObject)();
  }

  *initTable() {
    this.warp(this.beginObjectXYZRotXRotYRotZHiddenNoShadowsTag)(
      100,
      0,
      150,
      0,
      0,
      0,
      0,
      0,
      "table"
    );
    this.warp(this.addPointXYZ)(-70, 0, -50);
    this.warp(this.addPointXYZ)(-70, 0, 50);
    this.warp(this.addPointXYZ)(70, 0, 50);
    this.warp(this.addPointXYZ)(70, 0, -50);
    this.warp(this.addPointXYZ)(-70, 50, -50);
    this.warp(this.addPointXYZ)(-70, 50, 50);
    this.warp(this.addPointXYZ)(70, 50, 50);
    this.warp(this.addPointXYZ)(70, 50, -50);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(5, 6, 7, 4, 1);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(7, 8, 5, 4, 1);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(7, 6, 5, 4, 1);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(5, 8, 7, 4, 1);
    this.warp(this.addLineSurfaceP1P2WidthTextureIdLightSource)(1, 5, 10, 4, 1);
    this.warp(this.addLineSurfaceP1P2WidthTextureIdLightSource)(2, 6, 10, 4, 1);
    this.warp(this.addLineSurfaceP1P2WidthTextureIdLightSource)(3, 7, 10, 4, 1);
    this.warp(this.addLineSurfaceP1P2WidthTextureIdLightSource)(4, 8, 10, 4, 1);
    this.warp(this.endObject)();
  }

  *initRadio() {
    this.warp(this.beginObjectXYZRotXRotYRotZHiddenNoShadowsTag)(
      100,
      50,
      150,
      25,
      0,
      0,
      0,
      0,
      "radio"
    );
    this.warp(this.addPointXYZ)(-15, 0, -7);
    this.warp(this.addPointXYZ)(15, 0, -7);
    this.warp(this.addPointXYZ)(15, 0, 7);
    this.warp(this.addPointXYZ)(-15, 0, 7);
    this.warp(this.addPointXYZ)(-15, 10, -7);
    this.warp(this.addPointXYZ)(15, 10, -7);
    this.warp(this.addPointXYZ)(15, 10, 7);
    this.warp(this.addPointXYZ)(-15, 10, 7);
    this.warp(this.addPointXYZ)(-10, 10, 0);
    this.warp(this.addPointXYZ)(-10, 20, 0);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(1, 6, 2, 15, 1);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(1, 5, 6, 15, 1);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(1, 4, 5, 15, 1);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(4, 8, 5, 15, 1);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(4, 3, 8, 15, 1);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(3, 7, 8, 15, 1);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(3, 2, 7, 15, 1);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(6, 7, 2, 15, 1);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(7, 6, 5, 15, 1);
    this.warp(this.addTriSurfaceP1P2P3TextureIdLightSource)(5, 8, 7, 15, 1);
    this.warp(this.addLineSurfaceP1P2WidthTextureIdLightSource)(
      9,
      10,
      2,
      16,
      1
    );
    this.warp(this.endObject)();
  }

  *initRandTrees(num) {
    for (let i = 0; i < this.toNumber(num); i++) {
      this.warp(this.initTree)(
        this.random(-50, 50) * 100,
        this.random(-50, 50) * 100
      );
    }
  }

  *initTree(x, z) {
    this.warp(this.beginObjectXYZRotXRotYRotZHiddenNoShadowsTag)(
      x,
      0,
      z,
      0,
      0,
      0,
      0,
      0,
      "tree"
    );
    this.warp(this.addPointXYZ)(0, 0, 0);
    this.warp(this.addPointXYZ)(0, 200, 0);
    this.warp(this.addPointXYZ)(0, 350, 0);
    this.warp(this.addLineSurfaceP1P2WidthTextureIdLightSource)(
      1,
      2,
      70,
      11,
      0
    );
    this.warp(this.addSphereSurfaceOriginDiameterTextureIdLightSource)(
      3,
      300,
      12,
      0
    );
    this.warp(this.endObject)();
  }

  *giveEachObjectCustomProperties(num) {
    this.stage.vars.numCustomProperties = num;
  }

  *whenbackdropswitchesto() {
    yield* this.clearObjectData();
  }

  *setCustomPropertyTo(property, value) {
    this.stage.vars.objectsCustomProperties.splice(
      this.stage.vars.objectsCustomProperties.length -
        (this.toNumber(this.stage.vars.numCustomProperties) -
          this.toNumber(property)) -
        1,
      1,
      value
    );
  }
}
