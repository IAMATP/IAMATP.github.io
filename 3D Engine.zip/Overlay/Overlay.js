/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Overlay extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Loading", "./Overlay/costumes/Loading.svg", {
        x: 240,
        y: 180,
      }),
    ];

    this.sounds = [new Sound("pop", "./Overlay/sounds/pop.wav")];

    this.triggers = [
      new Trigger(
        Trigger.BROADCAST,
        { name: "System: Init" },
        this.whenIReceiveSystemInit
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "System: Loaded" },
        this.whenIReceiveSystemLoaded
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "System: Render Tick" },
        this.whenIReceiveSystemRenderTick
      ),
    ];

    this.vars.Action = 0;
    this.vars.ActionStart = 0.132;
  }

  *whenIReceiveSystemInit() {
    this.goto(0, 0);
    this.moveAhead();
    this.effects.clear();
    this.visible = true;
  }

  *whenIReceiveSystemLoaded() {
    this.vars.Action = 1;
    this.vars.ActionStart = this.timer;
  }

  *whenIReceiveSystemRenderTick() {
    if (this.toNumber(this.vars.Action) === 1) {
      if (
        this.compare(this.timer - this.toNumber(this.vars.ActionStart), 0.5) < 0
      ) {
        this.effects.ghost =
          100 *
          Math.E **
            (2 *
              Math.log(
                (this.timer - this.toNumber(this.vars.ActionStart)) / 0.5
              ));
      } else {
        this.visible = false;
        this.vars.Action = 0;
      }
    } else {
      null;
    }
  }
}
