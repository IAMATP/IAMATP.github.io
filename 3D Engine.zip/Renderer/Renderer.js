/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Renderer extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("icon", "./Renderer/costumes/icon.svg", { x: 174, y: 154 }),
      new Costume("draw", "./Renderer/costumes/draw.svg", { x: 626, y: 629 }),
      new Costume("dot", "./Renderer/costumes/dot.png", { x: 0, y: 2 }),
    ];

    this.sounds = [new Sound("pop", "./Renderer/sounds/pop.wav")];

    this.triggers = [
      new Trigger(
        Trigger.BROADCAST,
        { name: "Init: Final" },
        this.whenIReceiveInitFinal
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "System: Render Tick" },
        this.whenIReceiveSystemRenderTick
      ),
    ];

    this.vars.Temp1 = 0;
    this.vars.Temp2 = 33;
    this.vars.Temp3 = 1;
    this.vars.Temp4 = 0;
    this.vars.Temp5 = 1;
    this.vars.Temp6 = 3;
    this.vars.Temp8 = -0.12811037217724916;
    this.vars.E10 = 5.916655663799986;
    this.vars.E11 = 0;
    this.vars.E12 = 12.688309017999927;
    this.vars.E20 = 33.10588927379999;
    this.vars.E21 = 0;
    this.vars.E22 = 0.009761166999851412;
    this.vars.P1X = 4419.737395507612;
    this.vars.P1Y = -120;
    this.vars.P1Z = -859.8686977538057;
    this.vars.Determiner = 0.579491681941275;
    this.vars.P2X = -7827.8196450000005;
    this.vars.P2Y = -6222.960678;
    this.vars.P2Z = 3913.9098225000002;
    this.vars.Qvec0 = 56.454570342299995;
    this.vars.Qvec1 = -60;
    this.vars.ConstNearZ = 5;
    this.vars.E00 = 0;
    this.vars.E01 = -198.99020106000003;
    this.vars.E02 = -20.07236611999997;
    this.vars.Peri = 262.94657590531716;
    this.vars.Ind = 38.81752665878541;
    this.vars.Incx = -25.319441798812427;
    this.vars.Incy = -38.37286589349527;
    this.vars.Td = 0.1564635275956634;
    this.vars.A = 369.5025629641717;
    this.vars.Rate = 0.3231433618727022;
    this.vars.Night = 0.8111480339;
    this.vars.T = 0.005181650117982861;
    this.vars.Brightness = 0.47665643122061196;
    this.vars.Qvec2 = 674.2278094781667;
    this.vars.Matrix00 = 1;
    this.vars.Matrix01 = 0;
    this.vars.Matrix02 = 0;
    this.vars.Matrix03 = -40;
    this.vars.Matrix10 = 0;
    this.vars.Matrix11 = 1;
    this.vars.Matrix12 = 0;
    this.vars.Matrix13 = -120;
    this.vars.Matrix20 = 0;
    this.vars.Matrix21 = 0;
    this.vars.Matrix22 = 1;
    this.vars.Matrix23 = 520;
    this.vars.Y = -6;
    this.vars.I = 58;
    this.vars.Pos = 58;
    this.vars.MinDist = 26050400;
    this.vars.Val = 26050400;
    this.vars.J = 58;
    this.vars.MinId = 111;
    this.vars.Distance = 51.841219240641905;
    this.vars.DrawX = 43.48604629953865;
    this.vars.DrawY = -9.28030202025255;
    this.vars.DrawSize = 5;
    this.vars.DrawPerc = 0.8106508875739645;
    this.vars.DrawXNew = 77015.54602508344;
    this.vars.DrawYNew = -4545.689530455343;
    this.vars.PointDataTransformedX = [];
    this.vars.PointDataTransformedY = [];
    this.vars.PointDataTransformedZ = [];
    this.vars.FakeSurfacesP1 = [];
    this.vars.FakeSurfacesP2 = [];
    this.vars.FakeSurfacesP3 = [];
    this.vars.SurfaceSortId = [];
    this.vars.SurfaceSortDist = [];
    this.vars.ScreenPointsX = [];
    this.vars.ScreenPointsY = [];
    this.vars.StarsX = [];
    this.vars.StarsY = [];
    this.vars.StarsZ = [];
    this.vars.ScreenStarsX = [];
    this.vars.ScreenStarsY = [];
    this.vars.FakeSurfacesTexture = [];
    this.vars.ShadowsX = [];
    this.vars.ShadowsY = [];
    this.vars.ShadowsZ = [];
    this.vars.FakeSurfacesN0 = [];
    this.vars.FakeSurfacesN1 = [];
    this.vars.FakeSurfacesN2 = [];
    this.vars.FakeSurfacesLightSource = [];
    this.vars.FakeSurfacesP4 = [];
    this.vars.FakeSurfacesType = [];
    this.vars.FakeSurfacesDiameter = [];
  }

  *createStars(amount) {
    this.vars.StarsX = [];
    this.vars.StarsY = [];
    this.vars.StarsZ = [];
    for (let i = 0; i < this.toNumber(amount); i++) {
      this.vars.StarsX.push(this.random(-20000, 20000) * 10);
      this.vars.StarsY.push(this.random(-20000, 20000) * 10);
      this.vars.StarsZ.push(this.random(-20000, 20000) * 10);
      yield;
    }
  }

  *fillTriangleResolution(ax, ay, bx, by, cx, cy, res) {
    if (this.toNumber(this.itemOf(this.stage.vars.renderSettings, 31)) === 0) {
      yield* this.fillTriInner1(
        ax,
        ay,
        bx,
        by,
        cx,
        cy,
        Math.sqrt(
          (this.toNumber(bx) - this.toNumber(cx)) *
            (this.toNumber(bx) - this.toNumber(cx)) +
            (this.toNumber(by) - this.toNumber(cy)) *
              (this.toNumber(by) - this.toNumber(cy))
        ),
        Math.sqrt(
          (this.toNumber(ax) - this.toNumber(cx)) *
            (this.toNumber(ax) - this.toNumber(cx)) +
            (this.toNumber(ay) - this.toNumber(cy)) *
              (this.toNumber(ay) - this.toNumber(cy))
        ),
        Math.sqrt(
          (this.toNumber(ax) - this.toNumber(bx)) *
            (this.toNumber(ax) - this.toNumber(bx)) +
            (this.toNumber(ay) - this.toNumber(by)) *
              (this.toNumber(ay) - this.toNumber(by))
        ),
        this.toNumber(res) * 1.7
      );
    }
    this.penSize = 1;
    this.goto(this.toNumber(ax), this.toNumber(ay));
    this.penDown = true;
    this.penSize = this.toNumber(res);
    this.goto(this.toNumber(bx), this.toNumber(by));
    this.goto(this.toNumber(cx), this.toNumber(cy));
    this.goto(this.toNumber(ax), this.toNumber(ay));
    this.penDown = false;
  }

  *transformAllPoints(scale) {
    this.vars.PointDataTransformedX = [];
    this.vars.PointDataTransformedY = [];
    this.vars.PointDataTransformedZ = [];
    this.vars.ScreenPointsX = [];
    this.vars.ScreenPointsY = [];
    this.vars.Temp2 = 1;
    for (let i = 0; i < this.stage.vars.pointDataX.length; i++) {
      yield* this.transformVertexAndAdd(
        this.itemOf(this.stage.vars.worldDataX, this.vars.Temp2 - 1),
        this.itemOf(this.stage.vars.worldDataY, this.vars.Temp2 - 1),
        this.itemOf(this.stage.vars.worldDataZ, this.vars.Temp2 - 1)
      );
      yield* this.projectLastPoint(scale);
      this.vars.Temp2++;
      yield;
    }
  }

  *updatePointsAndLoadSurfaces(scale) {
    this.stage.vars.updateNeeded = 0;
    yield* this.transformAllPoints(scale);
    this.vars.SurfaceSortId = [];
    this.vars.SurfaceSortDist = [];
    this.vars.FakeSurfacesType = [];
    this.vars.FakeSurfacesP1 = [];
    this.vars.FakeSurfacesP2 = [];
    this.vars.FakeSurfacesP3 = [];
    this.vars.FakeSurfacesP4 = [];
    this.vars.FakeSurfacesDiameter = [];
    this.vars.FakeSurfacesTexture = [];
    this.vars.FakeSurfacesLightSource = [];
    this.vars.FakeSurfacesN0 = [];
    this.vars.FakeSurfacesN1 = [];
    this.vars.FakeSurfacesN2 = [];
    this.vars.Temp1 = 1;
    for (let i = 0; i < this.stage.vars.objectsX.length; i++) {
      if (
        this.toNumber(
          this.itemOf(this.stage.vars.objectsVisible, this.vars.Temp1 - 1)
        ) === 1
      ) {
        this.vars.Temp2 = this.itemOf(
          this.stage.vars.objectsSurfacesIndex,
          this.vars.Temp1 - 1
        );
        for (
          let i = 0;
          i <
          this.toNumber(
            this.itemOf(this.stage.vars.objectsSurfaces, this.vars.Temp1 - 1)
          );
          i++
        ) {
          this.vars.Temp3 = this.itemOf(
            this.stage.vars.surfacesType,
            this.vars.Temp2 - 1
          );
          if (this.toNumber(this.vars.Temp3) === 1) {
            yield* this.loadTriSurface(
              this.vars.Temp2,
              this.itemOf(this.stage.vars.surfacesP1, this.vars.Temp2 - 1),
              this.itemOf(this.stage.vars.surfacesP2, this.vars.Temp2 - 1),
              this.itemOf(this.stage.vars.surfacesP3, this.vars.Temp2 - 1),
              scale
            );
          } else {
            if (this.toNumber(this.vars.Temp3) === 3) {
              yield* this.loadLineSurface(
                this.vars.Temp2,
                this.itemOf(this.stage.vars.surfacesP1, this.vars.Temp2 - 1),
                this.itemOf(this.stage.vars.surfacesP2, this.vars.Temp2 - 1),
                this.itemOf(
                  this.stage.vars.surfacesDiameter,
                  this.vars.Temp2 - 1
                ),
                scale
              );
            } else {
              if (this.toNumber(this.vars.Temp3) === 4) {
                yield* this.loadSphereSurface(
                  this.vars.Temp2,
                  this.itemOf(this.stage.vars.surfacesP1, this.vars.Temp2 - 1),
                  this.itemOf(
                    this.stage.vars.surfacesDiameter,
                    this.vars.Temp2 - 1
                  ),
                  scale
                );
              } else {
                null;
              }
            }
          }
          this.vars.Temp2++;
          yield;
        }
      }
      this.vars.Temp1++;
      yield;
    }
    yield* this.sortSurfaces();
  }

  *rasterFillTriangleResolution(ax, ay, bx, by, cx, cy, res) {
    if (this.toNumber(this.itemOf(this.stage.vars.renderSettings, 31)) === 0) {
      yield* this.rasterTriFillInner1(ax, ay, bx, by, cx, cy, res);
    }
    this.penSize = 1;
    this.goto(this.toNumber(ax), this.toNumber(ay));
    this.penDown = true;
    this.penSize = this.toNumber(res);
    this.goto(this.toNumber(bx), this.toNumber(by));
    this.goto(this.toNumber(cx), this.toNumber(cy));
    this.goto(this.toNumber(ax), this.toNumber(ay));
    this.penDown = false;
  }

  *combineTransformation() {
    this.stage.vars.MatrixOld = [];
    this.stage.vars.MatrixOld.push(this.itemOf(this.vars.undefined, 0));
    this.stage.vars.MatrixOld.push(this.itemOf(this.vars.undefined, 1));
    this.stage.vars.MatrixOld.push(this.itemOf(this.vars.undefined, 2));
    this.stage.vars.MatrixOld.push(this.itemOf(this.vars.undefined, 3));
    this.stage.vars.MatrixOld.push(this.itemOf(this.vars.undefined, 4));
    this.stage.vars.MatrixOld.push(this.itemOf(this.vars.undefined, 5));
    this.stage.vars.MatrixOld.push(this.itemOf(this.vars.undefined, 6));
    this.stage.vars.MatrixOld.push(this.itemOf(this.vars.undefined, 7));
    this.stage.vars.MatrixOld.push(this.itemOf(this.vars.undefined, 8));
    this.stage.vars.MatrixOld.push(this.itemOf(this.vars.undefined, 9));
    this.stage.vars.MatrixOld.push(this.itemOf(this.vars.undefined, 10));
    this.stage.vars.MatrixOld.push(this.itemOf(this.vars.undefined, 11));
    this.stage.vars.MatrixOld.push(this.itemOf(this.vars.undefined, 12));
    this.stage.vars.MatrixOld.push(this.itemOf(this.vars.undefined, 13));
    this.stage.vars.MatrixOld.push(this.itemOf(this.vars.undefined, 14));
    this.stage.vars.MatrixOld.push(this.itemOf(this.vars.undefined, 15));
    this.vars.undefined.splice(
      0,
      1,
      this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 0)) *
        this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 0)) +
        (this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 1)) *
          this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 4)) +
          (this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 2)) *
            this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 8)) +
            this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 3)) *
              this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 12))))
    );
    this.vars.undefined.splice(
      1,
      1,
      this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 0)) *
        this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 1)) +
        (this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 1)) *
          this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 5)) +
          (this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 2)) *
            this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 9)) +
            this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 3)) *
              this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 13))))
    );
    this.vars.undefined.splice(
      2,
      1,
      this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 0)) *
        this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 2)) +
        (this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 1)) *
          this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 6)) +
          (this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 2)) *
            this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 10)) +
            this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 3)) *
              this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 14))))
    );
    this.vars.undefined.splice(
      3,
      1,
      this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 0)) *
        this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 3)) +
        (this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 1)) *
          this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 7)) +
          (this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 2)) *
            this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 11)) +
            this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 3)) *
              this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 15))))
    );
    this.vars.undefined.splice(
      4,
      1,
      this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 4)) *
        this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 0)) +
        (this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 5)) *
          this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 4)) +
          (this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 6)) *
            this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 8)) +
            this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 7)) *
              this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 12))))
    );
    this.vars.undefined.splice(
      5,
      1,
      this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 4)) *
        this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 1)) +
        (this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 5)) *
          this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 5)) +
          (this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 6)) *
            this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 9)) +
            this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 7)) *
              this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 13))))
    );
    this.vars.undefined.splice(
      6,
      1,
      this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 4)) *
        this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 2)) +
        (this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 5)) *
          this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 6)) +
          (this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 6)) *
            this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 10)) +
            this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 7)) *
              this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 14))))
    );
    this.vars.undefined.splice(
      7,
      1,
      this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 4)) *
        this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 3)) +
        (this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 5)) *
          this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 7)) +
          (this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 6)) *
            this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 11)) +
            this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 7)) *
              this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 15))))
    );
    this.vars.undefined.splice(
      8,
      1,
      this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 8)) *
        this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 0)) +
        (this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 9)) *
          this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 4)) +
          (this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 10)) *
            this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 8)) +
            this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 11)) *
              this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 12))))
    );
    this.vars.undefined.splice(
      9,
      1,
      this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 8)) *
        this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 1)) +
        (this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 9)) *
          this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 5)) +
          (this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 10)) *
            this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 9)) +
            this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 11)) *
              this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 13))))
    );
    this.vars.undefined.splice(
      10,
      1,
      this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 8)) *
        this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 2)) +
        (this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 9)) *
          this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 6)) +
          (this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 10)) *
            this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 10)) +
            this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 11)) *
              this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 14))))
    );
    this.vars.undefined.splice(
      11,
      1,
      this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 8)) *
        this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 3)) +
        (this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 9)) *
          this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 7)) +
          (this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 10)) *
            this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 11)) +
            this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 11)) *
              this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 15))))
    );
    this.vars.undefined.splice(
      12,
      1,
      this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 12)) *
        this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 0)) +
        (this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 13)) *
          this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 4)) +
          (this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 14)) *
            this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 8)) +
            this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 15)) *
              this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 12))))
    );
    this.vars.undefined.splice(
      13,
      1,
      this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 12)) *
        this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 1)) +
        (this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 13)) *
          this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 5)) +
          (this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 14)) *
            this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 9)) +
            this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 15)) *
              this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 13))))
    );
    this.vars.undefined.splice(
      14,
      1,
      this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 12)) *
        this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 2)) +
        (this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 13)) *
          this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 6)) +
          (this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 14)) *
            this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 10)) +
            this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 15)) *
              this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 14))))
    );
    this.vars.undefined.splice(
      15,
      1,
      this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 12)) *
        this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 3)) +
        (this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 13)) *
          this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 7)) +
          (this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 14)) *
            this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 11)) +
            this.toNumber(this.itemOf(this.stage.vars.MatrixTemp, 15)) *
              this.toNumber(this.itemOf(this.stage.vars.MatrixOld, 15))))
    );
  }

  *translate(x, y, z) {
    yield* this.resetMatrixTemp();
    this.stage.vars.MatrixTemp.splice(3, 1, x);
    this.stage.vars.MatrixTemp.splice(7, 1, y);
    this.stage.vars.MatrixTemp.splice(11, 1, z);
    yield* this.combineTransformation();
  }

  *scale(x, y, z) {
    yield* this.resetMatrixTemp();
    this.stage.vars.MatrixTemp.splice(0, 1, x);
    this.stage.vars.MatrixTemp.splice(5, 1, y);
    this.stage.vars.MatrixTemp.splice(10, 1, z);
    yield* this.combineTransformation();
  }

  *rotateZ(angle) {
    yield* this.resetMatrixTemp();
    this.stage.vars.MatrixTemp.splice(
      0,
      1,
      Math.cos(this.degToRad(this.toNumber(angle)))
    );
    this.stage.vars.MatrixTemp.splice(
      1,
      1,
      0 - Math.sin(this.degToRad(this.toNumber(angle)))
    );
    this.stage.vars.MatrixTemp.splice(
      4,
      1,
      Math.sin(this.degToRad(this.toNumber(angle)))
    );
    this.stage.vars.MatrixTemp.splice(
      5,
      1,
      Math.cos(this.degToRad(this.toNumber(angle)))
    );
    yield* this.combineTransformation();
  }

  *rotateY(angle) {
    yield* this.resetMatrixTemp();
    this.stage.vars.MatrixTemp.splice(
      5,
      1,
      Math.cos(this.degToRad(this.toNumber(angle)))
    );
    this.stage.vars.MatrixTemp.splice(
      6,
      1,
      0 - Math.sin(this.degToRad(this.toNumber(angle)))
    );
    this.stage.vars.MatrixTemp.splice(
      9,
      1,
      Math.sin(this.degToRad(this.toNumber(angle)))
    );
    this.stage.vars.MatrixTemp.splice(
      10,
      1,
      Math.cos(this.degToRad(this.toNumber(angle)))
    );
    yield* this.combineTransformation();
  }

  *rotateX(angle) {
    yield* this.resetMatrixTemp();
    this.stage.vars.MatrixTemp.splice(
      0,
      1,
      Math.cos(this.degToRad(this.toNumber(angle)))
    );
    this.stage.vars.MatrixTemp.splice(
      2,
      1,
      Math.sin(this.degToRad(this.toNumber(angle)))
    );
    this.stage.vars.MatrixTemp.splice(
      8,
      1,
      0 - Math.sin(this.degToRad(this.toNumber(angle)))
    );
    this.stage.vars.MatrixTemp.splice(
      10,
      1,
      Math.cos(this.degToRad(this.toNumber(angle)))
    );
    yield* this.combineTransformation();
  }

  *resetMatrixTemp() {
    this.stage.vars.MatrixTemp = [];
    this.stage.vars.MatrixTemp.push(1);
    this.stage.vars.MatrixTemp.push(0);
    this.stage.vars.MatrixTemp.push(0);
    this.stage.vars.MatrixTemp.push(0);
    this.stage.vars.MatrixTemp.push(0);
    this.stage.vars.MatrixTemp.push(1);
    this.stage.vars.MatrixTemp.push(0);
    this.stage.vars.MatrixTemp.push(0);
    this.stage.vars.MatrixTemp.push(0);
    this.stage.vars.MatrixTemp.push(0);
    this.stage.vars.MatrixTemp.push(1);
    this.stage.vars.MatrixTemp.push(0);
    this.stage.vars.MatrixTemp.push(0);
    this.stage.vars.MatrixTemp.push(0);
    this.stage.vars.MatrixTemp.push(0);
    this.stage.vars.MatrixTemp.push(1);
  }

  *resetMatrix() {
    this.vars.undefined = [];
    this.vars.undefined.push(1);
    this.vars.undefined.push(0);
    this.vars.undefined.push(0);
    this.vars.undefined.push(0);
    this.vars.undefined.push(0);
    this.vars.undefined.push(1);
    this.vars.undefined.push(0);
    this.vars.undefined.push(0);
    this.vars.undefined.push(0);
    this.vars.undefined.push(0);
    this.vars.undefined.push(1);
    this.vars.undefined.push(0);
    this.vars.undefined.push(0);
    this.vars.undefined.push(0);
    this.vars.undefined.push(0);
    this.vars.undefined.push(1);
  }

  *updateStarPositions(scale) {
    this.vars.ScreenStarsX = [];
    this.vars.ScreenStarsY = [];
    if (this.toNumber(this.itemOf(this.stage.vars.renderSettings, 13)) === 1) {
      this.vars.Temp1 = 1;
      for (let i = 0; i < this.vars.StarsX.length; i++) {
        if (
          this.compare(this.itemOf(this.vars.StarsY, this.vars.Temp1 - 1), 0) >
          0
        ) {
          yield* this.transformVertex(
            this.itemOf(this.vars.StarsX, this.vars.Temp1 - 1),
            this.itemOf(this.vars.StarsY, this.vars.Temp1 - 1),
            this.itemOf(this.vars.StarsZ, this.vars.Temp1 - 1)
          );
          if (this.compare(this.vars.P1Z, 0) > 0) {
            this.vars.Temp2 =
              (this.toNumber(this.vars.P1X) * this.toNumber(scale)) /
              this.toNumber(this.vars.P1Z);
            this.vars.Temp3 =
              (this.toNumber(this.vars.P1Y) * this.toNumber(scale)) /
              this.toNumber(this.vars.P1Z);
            if (
              this.compare(Math.abs(this.toNumber(this.vars.Temp2)), 241) < 0 &&
              this.compare(Math.abs(this.toNumber(this.vars.Temp3)), 181) < 0
            ) {
              this.vars.ScreenStarsX.push(this.vars.Temp2);
              this.vars.ScreenStarsY.push(this.vars.Temp3);
            }
          }
        }
        this.vars.Temp1++;
        yield;
      }
    } else {
      this.vars.Temp1 = 1;
      for (let i = 0; i < this.vars.StarsX.length; i++) {
        yield* this.transformVertex(
          this.itemOf(this.vars.StarsX, this.vars.Temp1 - 1),
          this.itemOf(this.vars.StarsY, this.vars.Temp1 - 1),
          this.itemOf(this.vars.StarsZ, this.vars.Temp1 - 1)
        );
        if (this.compare(this.vars.P1Z, 0) > 0) {
          this.vars.Temp2 =
            (this.toNumber(this.vars.P1X) * this.toNumber(scale)) /
            this.toNumber(this.vars.P1Z);
          this.vars.Temp3 =
            (this.toNumber(this.vars.P1Y) * this.toNumber(scale)) /
            this.toNumber(this.vars.P1Z);
          if (
            this.compare(Math.abs(this.toNumber(this.vars.Temp2)), 241) < 0 &&
            this.compare(Math.abs(this.toNumber(this.vars.Temp3)), 181) < 0
          ) {
            this.vars.ScreenStarsX.push(this.vars.Temp2);
            this.vars.ScreenStarsY.push(this.vars.Temp3);
          }
        }
        this.vars.Temp1++;
        yield;
      }
    }
  }

  *rasterFillEllipse(cx, cy, rx, ry, res) {
    this.vars.Y = this.toNumber(ry) - this.toNumber(res);
    for (
      let i = 0;
      i < Math.floor(this.toNumber(ry) / this.toNumber(res)) - 1;
      i++
    ) {
      yield* this.intDrawEllipseRows(
        cx,
        cy,
        this.vars.Y,
        Math.sin(
          this.degToRad(
            this.radToDeg(
              Math.acos(this.toNumber(this.vars.Y) / this.toNumber(ry))
            )
          )
        ) * this.toNumber(rx),
        res
      );
      this.vars.Y += 0 - this.toNumber(res);
      yield;
    }
    this.goto(
      this.toNumber(cx) - this.toNumber(rx) + this.toNumber(res),
      this.toNumber(cy)
    );
    this.penSize = 1;
    this.penDown = true;
    this.penSize =
      (this.toNumber(ry) % this.toNumber(res)) * 2 + this.toNumber(res) + 1;
    this.x = this.toNumber(cx) + this.toNumber(rx) - this.toNumber(res);
    this.penDown = false;
    this.goto(this.toNumber(cx), this.toNumber(cy) + this.toNumber(ry));
    this.penSize = 1;
    this.penDown = true;
    this.penSize = this.toNumber(res);
    this.vars.Temp3 = 0;
    for (let i = 0; i < (this.toNumber(rx) + this.toNumber(ry)) / 2; i++) {
      this.goto(
        this.toNumber(cx) +
          Math.sin(this.degToRad(this.toNumber(this.vars.Temp3))) *
            this.toNumber(rx),
        this.toNumber(cy) +
          Math.cos(this.degToRad(this.toNumber(this.vars.Temp3))) *
            this.toNumber(ry)
      );
      this.vars.Temp3 += 720 / (this.toNumber(rx) + this.toNumber(ry));
      yield;
    }
    this.goto(this.toNumber(cx), this.toNumber(cy) + this.toNumber(ry));
    this.penDown = false;
  }

  *rasterTriFillInner1(x1, y1, x2, y2, x3, y3, res) {
    if (this.compare(y2, y1) < 0) {
      yield* this.rasterTriFillInner1(x2, y2, x1, y1, x3, y3, res);
    } else {
      if (this.compare(y3, y1) < 0) {
        yield* this.rasterTriFillInner1(x3, y3, x2, y2, x1, y1, res);
      } else {
        if (this.compare(y3, y2) < 0) {
          yield* this.rasterTriFillInner1(x1, y1, x3, y3, x2, y2, res);
        } else {
          yield* this.rasterTriFillInner2(
            x1,
            y1,
            x2,
            y2,
            x3,
            y3,
            res,
            (this.toNumber(x3) - this.toNumber(x1)) /
              (this.toNumber(y3) - this.toNumber(y1)),
            (this.toNumber(x2) - this.toNumber(x1)) /
              (this.toNumber(y2) - this.toNumber(y1)),
            (this.toNumber(x3) - this.toNumber(x2)) /
              (this.toNumber(y3) - this.toNumber(y2))
          );
        }
      }
    }
  }

  *rasterTriFillInner2(x1, y1, x2, y2, x3, y3, res, x31Y31, x21Y21, x32Y32) {
    this.y = Math.ceil(this.toNumber(y1) + this.toNumber(res) / 2);
    for (
      let i = 0;
      i < Math.ceil((this.toNumber(y2) - this.y) / this.toNumber(res));
      i++
    ) {
      this.penSize = 1;
      this.x =
        this.toNumber(x1) +
        this.toNumber(x31Y31) * (this.y - this.toNumber(y1));
      this.penDown = true;
      this.penSize = this.toNumber(res);
      this.x =
        this.toNumber(x1) +
        this.toNumber(x21Y21) * (this.y - this.toNumber(y1));
      this.penDown = false;
      this.y += this.toNumber(res);
      yield;
    }
    for (
      let i = 0;
      i < Math.ceil((this.toNumber(y3) - this.y) / this.toNumber(res));
      i++
    ) {
      this.penSize = 1;
      this.x =
        this.toNumber(x1) +
        this.toNumber(x31Y31) * (this.y - this.toNumber(y1));
      this.penDown = true;
      this.penSize = this.toNumber(res);
      this.x =
        this.toNumber(x2) +
        this.toNumber(x32Y32) * (this.y - this.toNumber(y2));
      this.penDown = false;
      this.y += this.toNumber(res);
      yield;
    }
  }

  *createWorldViewTransformation() {
    yield* this.createWordViewTransformation(
      this.stage.vars.cameraX,
      this.stage.vars.cameraY,
      this.stage.vars.cameraZ,
      Math.sin(this.degToRad(this.toNumber(this.stage.vars.cameraRotX))),
      Math.cos(this.degToRad(this.toNumber(this.stage.vars.cameraRotX))),
      Math.sin(this.degToRad(this.toNumber(this.stage.vars.cameraRotY))),
      Math.cos(this.degToRad(this.toNumber(this.stage.vars.cameraRotY)))
    );
  }

  *createWordViewTransformation(x, y, z, sinRotX, cosRotX, sinRotY, cosRotY) {
    this.vars.Matrix00 = cosRotX;
    this.vars.Matrix01 = 0;
    this.vars.Matrix02 = sinRotX;
    this.vars.Matrix03 =
      0 -
      this.toNumber(x) * this.toNumber(cosRotX) -
      this.toNumber(z) * this.toNumber(sinRotX);
    this.vars.Matrix10 = this.toNumber(sinRotX) * this.toNumber(sinRotY);
    this.vars.Matrix11 = cosRotY;
    this.vars.Matrix12 = 0 - this.toNumber(cosRotX) * this.toNumber(sinRotY);
    this.vars.Matrix13 =
      0 -
      this.toNumber(y) * this.toNumber(cosRotY) -
      (this.toNumber(x) * this.toNumber(sinRotX) -
        this.toNumber(z) * this.toNumber(cosRotX)) *
        this.toNumber(sinRotY);
    this.vars.Matrix20 = 0 - this.toNumber(sinRotX) * this.toNumber(cosRotY);
    this.vars.Matrix21 = sinRotY;
    this.vars.Matrix22 = this.toNumber(cosRotX) * this.toNumber(cosRotY);
    this.vars.Matrix23 =
      (this.toNumber(x) * this.toNumber(sinRotX) -
        this.toNumber(z) * this.toNumber(cosRotX)) *
        this.toNumber(cosRotY) -
      this.toNumber(y) * this.toNumber(sinRotY);
  }

  *transformVertex(x, y, z) {
    this.vars.P1X =
      this.toNumber(this.vars.Matrix00) * this.toNumber(x) +
      this.toNumber(this.vars.Matrix01) * this.toNumber(y) +
      (this.toNumber(this.vars.Matrix02) * this.toNumber(z) +
        this.toNumber(this.vars.Matrix03));
    this.vars.P1Y =
      this.toNumber(this.vars.Matrix10) * this.toNumber(x) +
      this.toNumber(this.vars.Matrix11) * this.toNumber(y) +
      (this.toNumber(this.vars.Matrix12) * this.toNumber(z) +
        this.toNumber(this.vars.Matrix13));
    this.vars.P1Z =
      this.toNumber(this.vars.Matrix20) * this.toNumber(x) +
      this.toNumber(this.vars.Matrix21) * this.toNumber(y) +
      (this.toNumber(this.vars.Matrix22) * this.toNumber(z) +
        this.toNumber(this.vars.Matrix23));
  }

  *transformVertexAndAdd(x, y, z) {
    this.vars.PointDataTransformedX.push(
      this.toNumber(this.vars.Matrix00) * this.toNumber(x) +
        this.toNumber(this.vars.Matrix01) * this.toNumber(y) +
        (this.toNumber(this.vars.Matrix02) * this.toNumber(z) +
          this.toNumber(this.vars.Matrix03))
    );
    this.vars.PointDataTransformedY.push(
      this.toNumber(this.vars.Matrix10) * this.toNumber(x) +
        this.toNumber(this.vars.Matrix11) * this.toNumber(y) +
        (this.toNumber(this.vars.Matrix12) * this.toNumber(z) +
          this.toNumber(this.vars.Matrix13))
    );
    this.vars.PointDataTransformedZ.push(
      this.toNumber(this.vars.Matrix20) * this.toNumber(x) +
        this.toNumber(this.vars.Matrix21) * this.toNumber(y) +
        (this.toNumber(this.vars.Matrix22) * this.toNumber(z) +
          this.toNumber(this.vars.Matrix23))
    );
  }

  *projectLastPoint(scale) {
    this.vars.ScreenPointsX.push(
      (this.toNumber(
        this.itemOf(
          this.vars.PointDataTransformedX,
          this.vars.PointDataTransformedX.length - 1
        )
      ) *
        this.toNumber(scale)) /
        this.toNumber(
          this.itemOf(
            this.vars.PointDataTransformedZ,
            this.vars.PointDataTransformedZ.length - 1
          )
        )
    );
    this.vars.ScreenPointsY.push(
      (this.toNumber(
        this.itemOf(
          this.vars.PointDataTransformedY,
          this.vars.PointDataTransformedY.length - 1
        )
      ) *
        this.toNumber(scale)) /
        this.toNumber(
          this.itemOf(
            this.vars.PointDataTransformedZ,
            this.vars.PointDataTransformedZ.length - 1
          )
        )
    );
  }

  *zClipTriCase1(a0, a1, a2, b0, b1, b2, c0, c1, c2, scale, newZ) {
    this.vars.E00 = this.toNumber(c0) - this.toNumber(a0);
    this.vars.E01 = this.toNumber(c1) - this.toNumber(a1);
    this.vars.E02 = this.toNumber(c2) - this.toNumber(a2);
    this.vars.E10 = this.toNumber(c0) - this.toNumber(b0);
    this.vars.E11 = this.toNumber(c1) - this.toNumber(b1);
    this.vars.E12 = this.toNumber(c2) - this.toNumber(b2);
    this.vars.T =
      (this.toNumber(c2) - this.toNumber(newZ)) / this.toNumber(this.vars.E02);
    this.vars.PointDataTransformedX.push(
      this.toNumber(c0) -
        this.toNumber(this.vars.E00) * this.toNumber(this.vars.T)
    );
    this.vars.PointDataTransformedY.push(
      this.toNumber(c1) -
        this.toNumber(this.vars.E01) * this.toNumber(this.vars.T)
    );
    this.vars.PointDataTransformedZ.push(newZ);
    yield* this.projectLastPoint(scale);
    this.vars.T =
      (this.toNumber(c2) - this.toNumber(newZ)) / this.toNumber(this.vars.E12);
    this.vars.PointDataTransformedX.push(
      this.toNumber(c0) -
        this.toNumber(this.vars.E10) * this.toNumber(this.vars.T)
    );
    this.vars.PointDataTransformedY.push(
      this.toNumber(c1) -
        this.toNumber(this.vars.E11) * this.toNumber(this.vars.T)
    );
    this.vars.PointDataTransformedZ.push(newZ);
    yield* this.projectLastPoint(scale);
  }

  *zClipTriCase2(a0, a1, a2, b0, b1, b2, c0, c1, c2, scale, newZ) {
    this.vars.E00 = this.toNumber(b0) - this.toNumber(a0);
    this.vars.E01 = this.toNumber(b1) - this.toNumber(a1);
    this.vars.E02 = this.toNumber(b2) - this.toNumber(a2);
    this.vars.E10 = this.toNumber(c0) - this.toNumber(a0);
    this.vars.E11 = this.toNumber(c1) - this.toNumber(a1);
    this.vars.E12 = this.toNumber(c2) - this.toNumber(a2);
    this.vars.T =
      (this.toNumber(b2) - this.toNumber(newZ)) / this.toNumber(this.vars.E02);
    this.vars.PointDataTransformedX.push(
      this.toNumber(b0) -
        this.toNumber(this.vars.E00) * this.toNumber(this.vars.T)
    );
    this.vars.PointDataTransformedY.push(
      this.toNumber(b1) -
        this.toNumber(this.vars.E01) * this.toNumber(this.vars.T)
    );
    this.vars.PointDataTransformedZ.push(newZ);
    yield* this.projectLastPoint(scale);
    this.vars.T =
      (this.toNumber(c2) - this.toNumber(newZ)) / this.toNumber(this.vars.E12);
    this.vars.PointDataTransformedX.push(
      this.toNumber(c0) -
        this.toNumber(this.vars.E10) * this.toNumber(this.vars.T)
    );
    this.vars.PointDataTransformedY.push(
      this.toNumber(c1) -
        this.toNumber(this.vars.E11) * this.toNumber(this.vars.T)
    );
    this.vars.PointDataTransformedZ.push(newZ);
    yield* this.projectLastPoint(scale);
  }

  *zClipLine(a0, a1, a2, b0, b1, b2, scale, newZ) {
    this.vars.E00 = this.toNumber(b0) - this.toNumber(a0);
    this.vars.E01 = this.toNumber(b1) - this.toNumber(a1);
    this.vars.E02 = this.toNumber(b2) - this.toNumber(a2);
    this.vars.T =
      (this.toNumber(b2) - this.toNumber(newZ)) / this.toNumber(this.vars.E02);
    this.vars.PointDataTransformedX.push(
      this.toNumber(b0) -
        this.toNumber(this.vars.E00) * this.toNumber(this.vars.T)
    );
    this.vars.PointDataTransformedY.push(
      this.toNumber(b1) -
        this.toNumber(this.vars.E01) * this.toNumber(this.vars.T)
    );
    this.vars.PointDataTransformedZ.push(newZ);
    yield* this.projectLastPoint(scale);
  }

  *loadTriSurface(id, p1, p2, p3, scale) {
    yield* this.loadTriSurfaceInt(
      id,
      p1,
      p2,
      p3,
      this.itemOf(this.vars.PointDataTransformedX, p1 - 1),
      this.itemOf(this.vars.PointDataTransformedY, p1 - 1),
      this.itemOf(this.vars.PointDataTransformedZ, p1 - 1),
      this.itemOf(this.vars.PointDataTransformedX, p2 - 1),
      this.itemOf(this.vars.PointDataTransformedY, p2 - 1),
      this.itemOf(this.vars.PointDataTransformedZ, p2 - 1),
      this.itemOf(this.vars.PointDataTransformedX, p3 - 1),
      this.itemOf(this.vars.PointDataTransformedY, p3 - 1),
      this.itemOf(this.vars.PointDataTransformedZ, p3 - 1),
      scale
    );
  }

  *loadTriSurfaceInt(
    id,
    p1,
    p2,
    p3,
    p10,
    p11,
    p12,
    p20,
    p21,
    p22,
    p30,
    p31,
    p32,
    scale
  ) {
    this.vars.E10 = this.toNumber(p20) - this.toNumber(p10);
    this.vars.E11 = this.toNumber(p21) - this.toNumber(p11);
    this.vars.E12 = this.toNumber(p22) - this.toNumber(p12);
    this.vars.E20 = this.toNumber(p30) - this.toNumber(p10);
    this.vars.E21 = this.toNumber(p31) - this.toNumber(p11);
    this.vars.E22 = this.toNumber(p32) - this.toNumber(p12);
    this.vars.P1X =
      this.toNumber(this.vars.E11) * this.toNumber(this.vars.E22) -
      this.toNumber(this.vars.E12) * this.toNumber(this.vars.E21);
    this.vars.P1Y =
      this.toNumber(this.vars.E12) * this.toNumber(this.vars.E20) -
      this.toNumber(this.vars.E10) * this.toNumber(this.vars.E22);
    this.vars.P1Z =
      this.toNumber(this.vars.E10) * this.toNumber(this.vars.E21) -
      this.toNumber(this.vars.E11) * this.toNumber(this.vars.E20);
    this.vars.Determiner =
      this.toNumber(this.vars.P1X) * this.toNumber(p20) +
      (this.toNumber(this.vars.P1Y) * this.toNumber(p21) +
        this.toNumber(this.vars.P1Z) * this.toNumber(p22));
    if (this.compare(this.vars.Determiner, 0) < 0) {
      this.vars.Temp3 =
        this.toNumber(this.compare(p12, this.vars.ConstNearZ) > 0) + 0;
      this.vars.Temp4 =
        this.toNumber(this.compare(p22, this.vars.ConstNearZ) > 0) + 0;
      this.vars.Temp5 =
        this.toNumber(this.compare(p32, this.vars.ConstNearZ) > 0) + 0;
      this.vars.Temp6 =
        this.toNumber(this.vars.Temp3) +
        (this.toNumber(this.vars.Temp4) + this.toNumber(this.vars.Temp5));
      if (this.toNumber(this.vars.Temp6) === 3) {
        if (
          this.toNumber(this.itemOf(this.stage.vars.renderSettings, 33)) === 0
        ) {
          if (
            !(
              this.compare(this.itemOf(this.vars.ScreenPointsX, p1 - 1), 240) >
                0 &&
              this.compare(this.itemOf(this.vars.ScreenPointsX, p2 - 1), 240) >
                0 &&
              this.compare(this.itemOf(this.vars.ScreenPointsX, p3 - 1), 240) >
                0
            )
          ) {
            if (
              !(
                this.compare(
                  this.itemOf(this.vars.ScreenPointsX, p1 - 1),
                  -240
                ) < 0 &&
                this.compare(
                  this.itemOf(this.vars.ScreenPointsX, p2 - 1),
                  -240
                ) < 0 &&
                this.compare(
                  this.itemOf(this.vars.ScreenPointsX, p3 - 1),
                  -240
                ) < 0
              )
            ) {
              if (
                !(
                  this.compare(
                    this.itemOf(this.vars.ScreenPointsY, p1 - 1),
                    -180
                  ) < 0 &&
                  this.compare(
                    this.itemOf(this.vars.ScreenPointsY, p2 - 1),
                    -180
                  ) < 0 &&
                  this.compare(
                    this.itemOf(this.vars.ScreenPointsY, p3 - 1),
                    -180
                  ) < 0
                )
              ) {
                this.vars.SurfaceSortId.push(id);
                this.vars.Qvec0 =
                  (this.toNumber(p10) +
                    (this.toNumber(p20) + this.toNumber(p30))) /
                  3;
                this.vars.Qvec1 =
                  (this.toNumber(p11) +
                    (this.toNumber(p21) + this.toNumber(p31))) /
                  3;
                this.vars.Qvec2 =
                  (this.toNumber(p12) +
                    (this.toNumber(p22) + this.toNumber(p32))) /
                  3;
                this.vars.SurfaceSortDist.push(
                  this.toNumber(this.vars.Qvec0) *
                    this.toNumber(this.vars.Qvec0) +
                    this.toNumber(this.vars.Qvec1) *
                      this.toNumber(this.vars.Qvec1) +
                    this.toNumber(this.vars.Qvec2) *
                      this.toNumber(this.vars.Qvec2)
                );
              }
            }
          }
        } else {
          this.vars.Temp3 =
            this.toNumber(
              this.compare(
                p12,
                this.itemOf(this.stage.vars.renderSettings, 34)
              ) < 0
            ) + 0;
          this.vars.Temp4 =
            this.toNumber(
              this.compare(
                p22,
                this.itemOf(this.stage.vars.renderSettings, 34)
              ) < 0
            ) + 0;
          this.vars.Temp5 =
            this.toNumber(
              this.compare(
                p32,
                this.itemOf(this.stage.vars.renderSettings, 34)
              ) < 0
            ) + 0;
          this.vars.Temp6 =
            this.toNumber(this.vars.Temp3) +
            (this.toNumber(this.vars.Temp4) + this.toNumber(this.vars.Temp5));
          if (this.toNumber(this.vars.Temp6) === 3) {
            if (
              !(
                this.compare(
                  this.itemOf(this.vars.ScreenPointsX, p1 - 1),
                  240
                ) > 0 &&
                this.compare(
                  this.itemOf(this.vars.ScreenPointsX, p2 - 1),
                  240
                ) > 0 &&
                this.compare(
                  this.itemOf(this.vars.ScreenPointsX, p3 - 1),
                  240
                ) > 0
              )
            ) {
              if (
                !(
                  this.compare(
                    this.itemOf(this.vars.ScreenPointsX, p1 - 1),
                    -240
                  ) < 0 &&
                  this.compare(
                    this.itemOf(this.vars.ScreenPointsX, p2 - 1),
                    -240
                  ) < 0 &&
                  this.compare(
                    this.itemOf(this.vars.ScreenPointsX, p3 - 1),
                    -240
                  ) < 0
                )
              ) {
                if (
                  !(
                    this.compare(
                      this.itemOf(this.vars.ScreenPointsY, p1 - 1),
                      -180
                    ) < 0 &&
                    this.compare(
                      this.itemOf(this.vars.ScreenPointsY, p2 - 1),
                      -180
                    ) < 0 &&
                    this.compare(
                      this.itemOf(this.vars.ScreenPointsY, p3 - 1),
                      -180
                    ) < 0
                  )
                ) {
                  this.vars.SurfaceSortId.push(id);
                  this.vars.Qvec0 =
                    (this.toNumber(p10) +
                      (this.toNumber(p20) + this.toNumber(p30))) /
                    3;
                  this.vars.Qvec1 =
                    (this.toNumber(p11) +
                      (this.toNumber(p21) + this.toNumber(p31))) /
                    3;
                  this.vars.Qvec2 =
                    (this.toNumber(p12) +
                      (this.toNumber(p22) + this.toNumber(p32))) /
                    3;
                  this.vars.SurfaceSortDist.push(
                    this.toNumber(this.vars.Qvec0) *
                      this.toNumber(this.vars.Qvec0) +
                      this.toNumber(this.vars.Qvec1) *
                        this.toNumber(this.vars.Qvec1) +
                      this.toNumber(this.vars.Qvec2) *
                        this.toNumber(this.vars.Qvec2)
                  );
                }
              }
            }
          } else {
            if (this.toNumber(this.vars.Temp6) === 2) {
              if (this.toNumber(this.vars.Temp3) === 0) {
                yield* this.zClipTriCase2(
                  p10,
                  p11,
                  p12,
                  p20,
                  p21,
                  p22,
                  p30,
                  p31,
                  p32,
                  scale,
                  this.itemOf(this.stage.vars.renderSettings, 34)
                );
                yield* this.addFakeTriSurface(
                  id,
                  p2,
                  p3,
                  this.vars.PointDataTransformedX.length
                );
                yield* this.addFakeTriSurface(
                  id,
                  p2,
                  this.vars.PointDataTransformedX.length - 1,
                  this.vars.PointDataTransformedX.length
                );
              } else {
                if (this.toNumber(this.vars.Temp4) === 0) {
                  yield* this.zClipTriCase2(
                    p20,
                    p21,
                    p22,
                    p10,
                    p11,
                    p12,
                    p30,
                    p31,
                    p32,
                    scale,
                    this.itemOf(this.stage.vars.renderSettings, 34)
                  );
                  yield* this.addFakeTriSurface(
                    id,
                    p1,
                    p3,
                    this.vars.PointDataTransformedX.length
                  );
                  yield* this.addFakeTriSurface(
                    id,
                    p1,
                    this.vars.PointDataTransformedX.length - 1,
                    this.vars.PointDataTransformedX.length
                  );
                } else {
                  yield* this.zClipTriCase2(
                    p30,
                    p31,
                    p32,
                    p10,
                    p11,
                    p12,
                    p20,
                    p21,
                    p22,
                    scale,
                    this.itemOf(this.stage.vars.renderSettings, 34)
                  );
                  yield* this.addFakeTriSurface(
                    id,
                    p1,
                    p2,
                    this.vars.PointDataTransformedX.length
                  );
                  yield* this.addFakeTriSurface(
                    id,
                    p1,
                    this.vars.PointDataTransformedX.length - 1,
                    this.vars.PointDataTransformedX.length
                  );
                }
              }
            } else {
              if (this.toNumber(this.vars.Temp6) === 1) {
                if (
                  this.toNumber(this.vars.Temp3) === 0 &&
                  this.toNumber(this.vars.Temp4) === 0
                ) {
                  yield* this.zClipTriCase1(
                    p10,
                    p11,
                    p12,
                    p20,
                    p21,
                    p22,
                    p30,
                    p31,
                    p32,
                    scale,
                    this.itemOf(this.stage.vars.renderSettings, 34)
                  );
                  yield* this.addFakeTriSurface(
                    id,
                    this.vars.PointDataTransformedX.length - 1,
                    this.vars.PointDataTransformedX.length,
                    p3
                  );
                } else {
                  if (
                    this.toNumber(this.vars.Temp4) === 0 &&
                    this.toNumber(this.vars.Temp5) === 0
                  ) {
                    yield* this.zClipTriCase1(
                      p20,
                      p21,
                      p22,
                      p30,
                      p31,
                      p32,
                      p10,
                      p11,
                      p12,
                      scale,
                      this.itemOf(this.stage.vars.renderSettings, 34)
                    );
                    yield* this.addFakeTriSurface(
                      id,
                      p1,
                      this.vars.PointDataTransformedX.length - 1,
                      this.vars.PointDataTransformedX.length
                    );
                  } else {
                    yield* this.zClipTriCase1(
                      p10,
                      p11,
                      p12,
                      p30,
                      p31,
                      p32,
                      p20,
                      p21,
                      p22,
                      scale,
                      this.itemOf(this.stage.vars.renderSettings, 34)
                    );
                    yield* this.addFakeTriSurface(
                      id,
                      this.vars.PointDataTransformedX.length - 1,
                      p2,
                      this.vars.PointDataTransformedX.length
                    );
                  }
                }
              }
            }
          }
        }
      } else {
        if (this.toNumber(this.vars.Temp6) === 2) {
          if (this.toNumber(this.vars.Temp3) === 0) {
            yield* this.zClipTriCase2(
              p10,
              p11,
              p12,
              p20,
              p21,
              p22,
              p30,
              p31,
              p32,
              scale,
              this.vars.ConstNearZ
            );
            yield* this.addFakeTriSurface(
              id,
              p2,
              p3,
              this.vars.PointDataTransformedX.length
            );
            yield* this.addFakeTriSurface(
              id,
              p2,
              this.vars.PointDataTransformedX.length - 1,
              this.vars.PointDataTransformedX.length
            );
          } else {
            if (this.toNumber(this.vars.Temp4) === 0) {
              yield* this.zClipTriCase2(
                p20,
                p21,
                p22,
                p10,
                p11,
                p12,
                p30,
                p31,
                p32,
                scale,
                this.vars.ConstNearZ
              );
              yield* this.addFakeTriSurface(
                id,
                p1,
                p3,
                this.vars.PointDataTransformedX.length
              );
              yield* this.addFakeTriSurface(
                id,
                p1,
                this.vars.PointDataTransformedX.length - 1,
                this.vars.PointDataTransformedX.length
              );
            } else {
              yield* this.zClipTriCase2(
                p30,
                p31,
                p32,
                p10,
                p11,
                p12,
                p20,
                p21,
                p22,
                scale,
                this.vars.ConstNearZ
              );
              yield* this.addFakeTriSurface(
                id,
                p1,
                p2,
                this.vars.PointDataTransformedX.length
              );
              yield* this.addFakeTriSurface(
                id,
                p1,
                this.vars.PointDataTransformedX.length - 1,
                this.vars.PointDataTransformedX.length
              );
            }
          }
        } else {
          if (this.toNumber(this.vars.Temp6) === 1) {
            if (
              this.toNumber(this.vars.Temp3) === 0 &&
              this.toNumber(this.vars.Temp4) === 0
            ) {
              yield* this.zClipTriCase1(
                p10,
                p11,
                p12,
                p20,
                p21,
                p22,
                p30,
                p31,
                p32,
                scale,
                this.vars.ConstNearZ
              );
              yield* this.addFakeTriSurface(
                id,
                this.vars.PointDataTransformedX.length - 1,
                this.vars.PointDataTransformedX.length,
                p3
              );
            } else {
              if (
                this.toNumber(this.vars.Temp4) === 0 &&
                this.toNumber(this.vars.Temp5) === 0
              ) {
                yield* this.zClipTriCase1(
                  p20,
                  p21,
                  p22,
                  p30,
                  p31,
                  p32,
                  p10,
                  p11,
                  p12,
                  scale,
                  this.vars.ConstNearZ
                );
                yield* this.addFakeTriSurface(
                  id,
                  p1,
                  this.vars.PointDataTransformedX.length - 1,
                  this.vars.PointDataTransformedX.length
                );
              } else {
                yield* this.zClipTriCase1(
                  p10,
                  p11,
                  p12,
                  p30,
                  p31,
                  p32,
                  p20,
                  p21,
                  p22,
                  scale,
                  this.vars.ConstNearZ
                );
                yield* this.addFakeTriSurface(
                  id,
                  this.vars.PointDataTransformedX.length - 1,
                  p2,
                  this.vars.PointDataTransformedX.length
                );
              }
            }
          }
        }
      }
    }
  }

  *intDrawEllipseRows(cx, cy, y, width, res) {
    this.goto(
      this.toNumber(cx) - this.toNumber(width),
      this.toNumber(cy) + this.toNumber(y)
    );
    this.penSize = 1;
    this.penDown = true;
    this.penSize = this.toNumber(res);
    this.x = this.toNumber(cx) + this.toNumber(width);
    this.penDown = false;
    this.goto(
      this.toNumber(cx) - this.toNumber(width),
      this.toNumber(cy) - this.toNumber(y)
    );
    this.penSize = 1;
    this.penDown = true;
    this.penSize = this.toNumber(res);
    this.x = this.toNumber(cx) + this.toNumber(width);
    this.penDown = false;
  }

  *drawShadows(scale, lightSource) {
    if (
      this.compare(
        this.itemOf(this.stage.vars.lightSourcesContrib, lightSource - 1),
        0.01
      ) > 0
    ) {
      this.vars.ShadowsX = [];
      this.vars.ShadowsY = [];
      this.vars.ShadowsZ = [];
      this.vars.Temp1 = 1;
      this.vars.Temp2 =
        this.toNumber(
          this.itemOf(this.stage.vars.lightSourcesY, lightSource - 1)
        ) /
        this.toNumber(
          this.itemOf(this.stage.vars.lightSourcesX, lightSource - 1)
        );
      this.vars.Temp3 =
        this.toNumber(
          this.itemOf(this.stage.vars.lightSourcesY, lightSource - 1)
        ) /
        this.toNumber(
          this.itemOf(this.stage.vars.lightSourcesZ, lightSource - 1)
        );
      for (let i = 0; i < this.stage.vars.worldDataX.length; i++) {
        yield* this.transformVertex(
          this.toNumber(
            this.itemOf(this.stage.vars.worldDataX, this.vars.Temp1 - 1)
          ) -
            this.toNumber(
              this.itemOf(this.stage.vars.worldDataY, this.vars.Temp1 - 1)
            ) /
              this.toNumber(this.vars.Temp2),
          0,
          this.toNumber(
            this.itemOf(this.stage.vars.worldDataZ, this.vars.Temp1 - 1)
          ) -
            this.toNumber(
              this.itemOf(this.stage.vars.worldDataY, this.vars.Temp1 - 1)
            ) /
              this.toNumber(this.vars.Temp3)
        );
        this.vars.ShadowsX.push(this.vars.P1X);
        this.vars.ShadowsY.push(this.vars.P1Y);
        this.vars.ShadowsZ.push(this.vars.P1Z);
        this.vars.Temp1++;
        yield;
      }
      this.vars.Temp2 =
        1 -
        this.toNumber(this.vars.Night) / 2 -
        this.toNumber(
          this.itemOf(this.stage.vars.lightSourcesContrib, lightSource - 1)
        ) /
          1.5;
      this.penColor = Color.num(
        Math.floor(
          this.toNumber(this.itemOf(this.stage.vars.renderSettings, 16)) *
            this.toNumber(this.vars.Temp2)
        ) *
          65536 +
          Math.floor(
            this.toNumber(this.itemOf(this.stage.vars.renderSettings, 17)) *
              this.toNumber(this.vars.Temp2)
          ) *
            256 +
          Math.floor(
            this.toNumber(this.itemOf(this.stage.vars.renderSettings, 18)) *
              this.toNumber(this.vars.Temp2)
          )
      );
      this.vars.Temp1 = 1;
      for (let i = 0; i < this.stage.vars.objectsX.length; i++) {
        if (
          this.toNumber(
            this.itemOf(this.stage.vars.objectsShadows, this.vars.Temp1 - 1)
          ) === 1
        ) {
          this.vars.Temp2 = this.itemOf(
            this.stage.vars.objectsSurfacesIndex,
            this.vars.Temp1 - 1
          );
          for (
            let i = 0;
            i <
            this.toNumber(
              this.itemOf(this.stage.vars.objectsSurfaces, this.vars.Temp1 - 1)
            );
            i++
          ) {
            if (
              this.compare(
                this.itemOf(
                  this.stage.vars.surfacesLightSource,
                  this.vars.Temp2 - 1
                ),
                this.toNumber(lightSource) - 1
              ) === 0 &&
              this.toNumber(
                this.itemOf(this.stage.vars.objectsVisible, this.vars.Temp1 - 1)
              ) === 1
            ) {
              if (
                this.compare(
                  this.itemOf(
                    this.stage.vars.surfacesType,
                    this.vars.Temp2 - 1
                  ),
                  2
                ) < 0
              ) {
                if (
                  this.toNumber(
                    this.itemOf(this.stage.vars.renderSettings, 11)
                  ) === 1
                ) {
                  this.vars.Determiner =
                    this.toNumber(
                      this.itemOf(
                        this.stage.vars.surfacesN0,
                        this.vars.Temp2 - 1
                      )
                    ) *
                      this.toNumber(
                        this.itemOf(
                          this.stage.vars.lightSourcesX,
                          lightSource - 1
                        )
                      ) +
                    (this.toNumber(
                      this.itemOf(
                        this.stage.vars.surfacesN1,
                        this.vars.Temp2 - 1
                      )
                    ) *
                      this.toNumber(
                        this.itemOf(
                          this.stage.vars.lightSourcesY,
                          lightSource - 1
                        )
                      ) +
                      this.toNumber(
                        this.itemOf(
                          this.stage.vars.surfacesN2,
                          this.vars.Temp2 - 1
                        )
                      ) *
                        this.toNumber(
                          this.itemOf(
                            this.stage.vars.lightSourcesZ,
                            lightSource - 1
                          )
                        ));
                  if (this.compare(this.vars.Determiner, 0) > 0) {
                    yield* this.drawShadowTriSurface(
                      this.itemOf(
                        this.stage.vars.surfacesP1,
                        this.vars.Temp2 - 1
                      ),
                      this.itemOf(
                        this.stage.vars.surfacesP2,
                        this.vars.Temp2 - 1
                      ),
                      this.itemOf(
                        this.stage.vars.surfacesP3,
                        this.vars.Temp2 - 1
                      ),
                      scale
                    );
                  }
                } else {
                  yield* this.drawShadowTriSurface(
                    this.itemOf(
                      this.stage.vars.surfacesP1,
                      this.vars.Temp2 - 1
                    ),
                    this.itemOf(
                      this.stage.vars.surfacesP2,
                      this.vars.Temp2 - 1
                    ),
                    this.itemOf(
                      this.stage.vars.surfacesP3,
                      this.vars.Temp2 - 1
                    ),
                    scale
                  );
                }
              } else {
                if (
                  this.toNumber(
                    this.itemOf(
                      this.stage.vars.surfacesType,
                      this.vars.Temp2 - 1
                    )
                  ) === 3
                ) {
                  yield* this.drawShadowLineSurface(
                    this.itemOf(
                      this.stage.vars.surfacesP1,
                      this.vars.Temp2 - 1
                    ),
                    this.itemOf(
                      this.stage.vars.surfacesP2,
                      this.vars.Temp2 - 1
                    ),
                    this.itemOf(
                      this.stage.vars.surfacesDiameter,
                      this.vars.Temp2 - 1
                    ),
                    scale
                  );
                } else {
                  if (
                    this.toNumber(
                      this.itemOf(
                        this.stage.vars.surfacesType,
                        this.vars.Temp2 - 1
                      )
                    ) === 4
                  ) {
                    null;
                  } else {
                    null;
                  }
                }
              }
            }
            this.vars.Temp2++;
            yield;
          }
        }
        this.vars.Temp1++;
        yield;
      }
    }
  }

  *drawTriSurface(p1, p2, p3, light, texture, n0, n1, n2) {
    this.vars.Brightness =
      (1 -
        (this.toNumber(this.itemOf(this.stage.vars.lightSourcesX, light - 1)) *
          this.toNumber(n0) +
          (this.toNumber(
            this.itemOf(this.stage.vars.lightSourcesY, light - 1)
          ) *
            this.toNumber(n1) +
            this.toNumber(
              this.itemOf(this.stage.vars.lightSourcesZ, light - 1)
            ) *
              this.toNumber(n2)))) *
      this.toNumber(
        this.itemOf(this.stage.vars.lightSourcesContrib, light - 1)
      );
    this.vars.Brightness =
      this.toNumber(this.itemOf(this.stage.vars.renderSettings, 5)) +
      (1 - this.toNumber(this.vars.Night)) *
        this.toNumber(this.itemOf(this.stage.vars.renderSettings, 6)) +
      this.toNumber(this.vars.Brightness);
    if (this.compare(this.vars.Brightness, 1) < 0) {
      this.penColor = Color.num(
        this.toNumber(this.itemOf(this.stage.vars.texturesA, texture - 1)) *
          16777216 +
          Math.floor(
            this.toNumber(this.itemOf(this.stage.vars.texturesR, texture - 1)) *
              this.toNumber(this.vars.Brightness)
          ) *
            65536 +
          (Math.floor(
            this.toNumber(this.itemOf(this.stage.vars.texturesG, texture - 1)) *
              this.toNumber(this.vars.Brightness)
          ) *
            256 +
            Math.floor(
              this.toNumber(
                this.itemOf(this.stage.vars.texturesB, texture - 1)
              ) * this.toNumber(this.vars.Brightness)
            ))
      );
    } else {
      this.penColor = Color.num(
        this.toNumber(this.itemOf(this.stage.vars.texturesA, texture - 1)) *
          16777216 +
          Math.floor(
            this.toNumber(this.itemOf(this.stage.vars.texturesR, texture - 1))
          ) *
            65536 +
          (Math.floor(
            this.toNumber(this.itemOf(this.stage.vars.texturesG, texture - 1))
          ) *
            256 +
            Math.floor(
              this.toNumber(this.itemOf(this.stage.vars.texturesB, texture - 1))
            ))
      );
    }
    if (
      this.toNumber(this.itemOf(this.stage.vars.texturesA, texture - 1)) ===
        0 ||
      this.toNumber(this.itemOf(this.stage.vars.renderSettings, 4)) === 0
    ) {
      yield* this.intClipTriangleRes(
        this.itemOf(this.vars.ScreenPointsX, p1 - 1),
        this.itemOf(this.vars.ScreenPointsY, p1 - 1),
        this.itemOf(this.vars.ScreenPointsX, p2 - 1),
        this.itemOf(this.vars.ScreenPointsY, p2 - 1),
        this.itemOf(this.vars.ScreenPointsX, p3 - 1),
        this.itemOf(this.vars.ScreenPointsY, p3 - 1),
        this.itemOf(this.stage.vars.renderSettings, 1)
      );
    } else {
      yield* this.rasterFillTriangleResolution(
        this.itemOf(this.vars.ScreenPointsX, p1 - 1),
        this.itemOf(this.vars.ScreenPointsY, p1 - 1),
        this.itemOf(this.vars.ScreenPointsX, p2 - 1),
        this.itemOf(this.vars.ScreenPointsY, p2 - 1),
        this.itemOf(this.vars.ScreenPointsX, p3 - 1),
        this.itemOf(this.vars.ScreenPointsY, p3 - 1),
        this.itemOf(this.stage.vars.renderSettings, 2)
      );
    }
  }

  *drawLineSurface(p1, p2, width, texture) {
    this.vars.Brightness =
      this.toNumber(this.itemOf(this.stage.vars.renderSettings, 5)) +
      (1 - this.toNumber(this.vars.Night)) *
        this.toNumber(this.itemOf(this.stage.vars.renderSettings, 6));
    if (this.compare(this.vars.Brightness, 1) < 0) {
      this.penColor = Color.num(
        this.toNumber(this.itemOf(this.stage.vars.texturesA, texture - 1)) *
          16777216 +
          Math.floor(
            this.toNumber(this.itemOf(this.stage.vars.texturesR, texture - 1)) *
              this.toNumber(this.vars.Brightness)
          ) *
            65536 +
          (Math.floor(
            this.toNumber(this.itemOf(this.stage.vars.texturesG, texture - 1)) *
              this.toNumber(this.vars.Brightness)
          ) *
            256 +
            Math.floor(
              this.toNumber(
                this.itemOf(this.stage.vars.texturesB, texture - 1)
              ) * this.toNumber(this.vars.Brightness)
            ))
      );
    } else {
      this.penColor = Color.num(
        this.toNumber(this.itemOf(this.stage.vars.texturesA, texture - 1)) *
          16777216 +
          Math.floor(
            this.toNumber(this.itemOf(this.stage.vars.texturesR, texture - 1))
          ) *
            65536 +
          (Math.floor(
            this.toNumber(this.itemOf(this.stage.vars.texturesG, texture - 1))
          ) *
            256 +
            Math.floor(
              this.toNumber(this.itemOf(this.stage.vars.texturesB, texture - 1))
            ))
      );
    }
    this.vars.Temp3 =
      this.toNumber(width) *
      this.toNumber(this.itemOf(this.stage.vars.renderSettings, 0));
    yield* this.drawLineFromXYToXYStartWidthEndWidth(
      this.itemOf(this.vars.ScreenPointsX, p1 - 1),
      this.itemOf(this.vars.ScreenPointsY, p1 - 1),
      this.itemOf(this.vars.ScreenPointsX, p2 - 1),
      this.itemOf(this.vars.ScreenPointsY, p2 - 1),
      Math.round(
        this.toNumber(this.vars.Temp3) /
          this.toNumber(this.itemOf(this.vars.PointDataTransformedZ, p1 - 1))
      ),
      Math.round(
        this.toNumber(this.vars.Temp3) /
          this.toNumber(this.itemOf(this.vars.PointDataTransformedZ, p2 - 1))
      )
    );
  }

  *drawSphereSurface(origin, diameter, texture) {
    this.vars.Brightness =
      this.toNumber(this.itemOf(this.stage.vars.renderSettings, 5)) +
      (1 - this.toNumber(this.vars.Night)) *
        this.toNumber(this.itemOf(this.stage.vars.renderSettings, 6));
    if (this.compare(this.vars.Brightness, 1) < 0) {
      this.penColor = Color.num(
        this.toNumber(this.itemOf(this.stage.vars.texturesA, texture - 1)) *
          16777216 +
          Math.floor(
            this.toNumber(this.itemOf(this.stage.vars.texturesR, texture - 1)) *
              this.toNumber(this.vars.Brightness)
          ) *
            65536 +
          (Math.floor(
            this.toNumber(this.itemOf(this.stage.vars.texturesG, texture - 1)) *
              this.toNumber(this.vars.Brightness)
          ) *
            256 +
            Math.floor(
              this.toNumber(
                this.itemOf(this.stage.vars.texturesB, texture - 1)
              ) * this.toNumber(this.vars.Brightness)
            ))
      );
    } else {
      this.penColor = Color.num(
        this.toNumber(this.itemOf(this.stage.vars.texturesA, texture - 1)) *
          16777216 +
          Math.floor(
            this.toNumber(this.itemOf(this.stage.vars.texturesR, texture - 1))
          ) *
            65536 +
          (Math.floor(
            this.toNumber(this.itemOf(this.stage.vars.texturesG, texture - 1))
          ) *
            256 +
            Math.floor(
              this.toNumber(this.itemOf(this.stage.vars.texturesB, texture - 1))
            ))
      );
    }
    this.vars.Temp3 =
      (this.toNumber(diameter) *
        this.toNumber(this.itemOf(this.stage.vars.renderSettings, 0))) /
      this.toNumber(this.itemOf(this.vars.PointDataTransformedZ, origin - 1));
    if (this.compare(this.vars.Temp3, 500) < 0) {
      this.penSize = this.toNumber(this.vars.Temp3);
      this.goto(
        this.toNumber(this.itemOf(this.vars.ScreenPointsX, origin - 1)),
        this.toNumber(this.itemOf(this.vars.ScreenPointsY, origin - 1))
      );
      this.penDown = true;
      this.penDown = false;
    } else {
      yield* this.rasterFillEllipse(
        this.itemOf(this.vars.ScreenPointsX, origin - 1),
        this.itemOf(this.vars.ScreenPointsY, origin - 1),
        this.toNumber(this.vars.Temp3) / 2,
        this.toNumber(this.vars.Temp3) / 2,
        this.itemOf(this.stage.vars.renderSettings, 2)
      );
    }
  }

  *drawStars() {
    if (this.compare(this.vars.Night, 0.51) > 0) {
      if (this.compare(this.vars.Night, 0.7) > 0) {
        this.penColor = Color.num(
          this.toNumber(this.itemOf(this.stage.vars.renderSettings, 30))
        );
      } else {
        this.penColor = Color.num(
          Math.floor((this.toNumber(this.vars.Night) - 0.5) * 1275) * 16777216 +
            this.toNumber(this.itemOf(this.stage.vars.renderSettings, 30))
        );
      }
      this.penSize = 3;
      this.vars.Temp2 = 1;
      for (let i = 0; i < this.vars.ScreenStarsX.length; i++) {
        this.goto(
          this.toNumber(
            this.itemOf(this.vars.ScreenStarsX, this.vars.Temp2 - 1)
          ),
          this.toNumber(
            this.itemOf(this.vars.ScreenStarsY, this.vars.Temp2 - 1)
          )
        );
        this.penDown = true;
        this.penDown = false;
        this.vars.Temp2++;
        yield;
      }
    }
  }

  *drawSunAndMoon(scale) {
    this.vars.P2X =
      Math.sin(this.degToRad(this.toNumber(this.stage.vars.time) - 90)) * 10000;
    this.vars.P2Y =
      Math.cos(this.degToRad(this.toNumber(this.stage.vars.time) - 90)) * 10000;
    this.vars.P2Z = this.toNumber(this.vars.P2X) / -2;
    this.vars.Temp2 = Math.sqrt(
      this.toNumber(this.vars.P2X) * this.toNumber(this.vars.P2X) +
        (this.toNumber(this.vars.P2Y) * this.toNumber(this.vars.P2Y) +
          this.toNumber(this.vars.P2Z) * this.toNumber(this.vars.P2Z))
    );
    if (this.compare(this.vars.P2Y, 2950) > 0) {
      this.stage.vars.lightSourcesContrib.splice(
        0,
        1,
        this.itemOf(this.stage.vars.renderSettings, 7)
      );
    } else {
      if (this.compare(this.vars.P2Y, -2950) < 0) {
        this.stage.vars.lightSourcesContrib.splice(
          0,
          1,
          this.itemOf(this.stage.vars.renderSettings, 8)
        );
      } else {
        if (this.compare(this.vars.P2Y, 0) > 0) {
          this.stage.vars.lightSourcesContrib.splice(
            0,
            1,
            this.toNumber(this.itemOf(this.stage.vars.renderSettings, 7)) *
              (this.toNumber(this.vars.P2Y) / 2950)
          );
        } else {
          this.stage.vars.lightSourcesContrib.splice(
            0,
            1,
            this.toNumber(this.itemOf(this.stage.vars.renderSettings, 8)) *
              (this.toNumber(this.vars.P2Y) / -2950)
          );
        }
      }
    }
    if (
      this.compare(this.vars.P2Y, -1500) > 0 ||
      this.toNumber(this.itemOf(this.stage.vars.renderSettings, 13)) === 0
    ) {
      this.stage.vars.lightSourcesX.splice(
        0,
        1,
        0 - this.toNumber(this.vars.P2X) / this.toNumber(this.vars.Temp2)
      );
      this.stage.vars.lightSourcesY.splice(
        0,
        1,
        0 - this.toNumber(this.vars.P2Y) / this.toNumber(this.vars.Temp2)
      );
      this.stage.vars.lightSourcesZ.splice(
        0,
        1,
        0 - this.toNumber(this.vars.P2Z) / this.toNumber(this.vars.Temp2)
      );
      yield* this.transformVertex(this.vars.P2X, this.vars.P2Y, this.vars.P2Z);
      if (this.compare(this.vars.P1Z, 0) > 0) {
        this.goto(
          (this.toNumber(this.vars.P1X) * this.toNumber(scale)) /
            this.toNumber(this.vars.P1Z),
          (this.toNumber(this.vars.P1Y) * this.toNumber(scale)) /
            this.toNumber(this.vars.P1Z)
        );
        this.penColor = Color.num(
          268435456 +
            this.toNumber(this.itemOf(this.stage.vars.renderSettings, 28))
        );
        this.penSize = 100;
        for (let i = 0; i < 10; i++) {
          this.penDown = true;
          this.penSize -= 6;
          yield;
        }
        this.penColor = Color.num(
          this.toNumber(this.itemOf(this.stage.vars.renderSettings, 28))
        );
        this.penSize = 40;
        this.penDown = true;
        this.penDown = false;
      }
    }
    if (
      this.compare(this.vars.P2Y, 1000) < 0 ||
      this.toNumber(this.itemOf(this.stage.vars.renderSettings, 13)) === 0
    ) {
      if (this.compare(this.vars.P2Y, 0) < 0) {
        this.stage.vars.lightSourcesX.splice(
          0,
          1,
          this.toNumber(this.vars.P2X) / this.toNumber(this.vars.Temp2)
        );
        this.stage.vars.lightSourcesY.splice(
          0,
          1,
          this.toNumber(this.vars.P2Y) / this.toNumber(this.vars.Temp2)
        );
        this.stage.vars.lightSourcesZ.splice(
          0,
          1,
          this.toNumber(this.vars.P2Z) / this.toNumber(this.vars.Temp2)
        );
      }
      yield* this.transformVertex(
        0 - this.toNumber(this.vars.P2X),
        0 - this.toNumber(this.vars.P2Y),
        0 - this.toNumber(this.vars.P2Z)
      );
      if (this.compare(this.vars.P1Z, 0) > 0) {
        this.goto(
          (this.toNumber(this.vars.P1X) * this.toNumber(scale)) /
            this.toNumber(this.vars.P1Z),
          (this.toNumber(this.vars.P1Y) * this.toNumber(scale)) /
            this.toNumber(this.vars.P1Z)
        );
        this.penColor = Color.num(
          100663296 +
            this.toNumber(this.itemOf(this.stage.vars.renderSettings, 29))
        );
        this.penSize = 80;
        for (let i = 0; i < 10; i++) {
          this.penDown = true;
          this.penSize -= 4;
          yield;
        }
        this.penColor = Color.num(
          this.toNumber(this.itemOf(this.stage.vars.renderSettings, 29))
        );
        this.penDown = true;
        this.penDown = false;
      }
    }
  }

  *addFakeTriSurface(oldId, p1, p2, p3) {
    if (
      !(
        this.compare(this.itemOf(this.vars.ScreenPointsX, p1 - 1), 240) > 0 &&
        this.compare(this.itemOf(this.vars.ScreenPointsX, p2 - 1), 240) > 0 &&
        this.compare(this.itemOf(this.vars.ScreenPointsX, p3 - 1), 240) > 0
      )
    ) {
      if (
        !(
          this.compare(this.itemOf(this.vars.ScreenPointsX, p1 - 1), -240) <
            0 &&
          this.compare(this.itemOf(this.vars.ScreenPointsX, p2 - 1), -240) <
            0 &&
          this.compare(this.itemOf(this.vars.ScreenPointsX, p3 - 1), -240) < 0
        )
      ) {
        if (
          !(
            this.compare(this.itemOf(this.vars.ScreenPointsY, p1 - 1), -180) <
              0 &&
            this.compare(this.itemOf(this.vars.ScreenPointsY, p2 - 1), -180) <
              0 &&
            this.compare(this.itemOf(this.vars.ScreenPointsY, p3 - 1), -180) < 0
          )
        ) {
          this.vars.FakeSurfacesType.push(1);
          this.vars.FakeSurfacesP1.push(p1);
          this.vars.FakeSurfacesP2.push(p2);
          this.vars.FakeSurfacesP3.push(p3);
          this.vars.FakeSurfacesP4.push("");
          this.vars.FakeSurfacesDiameter.push("");
          this.vars.FakeSurfacesTexture.push(
            this.itemOf(this.stage.vars.surfacesTexture, oldId - 1)
          );
          this.vars.SurfaceSortId.push(0 - this.vars.FakeSurfacesP1.length);
          this.vars.FakeSurfacesN0.push(
            this.itemOf(this.stage.vars.surfacesN0, oldId - 1)
          );
          this.vars.FakeSurfacesN1.push(
            this.itemOf(this.stage.vars.surfacesN1, oldId - 1)
          );
          this.vars.FakeSurfacesN2.push(
            this.itemOf(this.stage.vars.surfacesN2, oldId - 1)
          );
          this.vars.FakeSurfacesLightSource.push(
            this.itemOf(this.stage.vars.surfacesLightSource, oldId - 1)
          );
          this.vars.Qvec0 =
            (this.toNumber(
              this.itemOf(this.vars.PointDataTransformedX, p1 - 1)
            ) +
              (this.toNumber(
                this.itemOf(this.vars.PointDataTransformedX, p2 - 1)
              ) +
                this.toNumber(
                  this.itemOf(this.vars.PointDataTransformedX, p3 - 1)
                ))) /
            3;
          this.vars.Qvec1 =
            (this.toNumber(
              this.itemOf(this.vars.PointDataTransformedY, p1 - 1)
            ) +
              (this.toNumber(
                this.itemOf(this.vars.PointDataTransformedY, p2 - 1)
              ) +
                this.toNumber(
                  this.itemOf(this.vars.PointDataTransformedY, p3 - 1)
                ))) /
            3;
          this.vars.Qvec2 =
            (this.toNumber(
              this.itemOf(this.vars.PointDataTransformedZ, p1 - 1)
            ) +
              (this.toNumber(
                this.itemOf(this.vars.PointDataTransformedZ, p2 - 1)
              ) +
                this.toNumber(
                  this.itemOf(this.vars.PointDataTransformedZ, p3 - 1)
                ))) /
            3;
          this.vars.SurfaceSortDist.push(
            this.toNumber(this.vars.Qvec0) * this.toNumber(this.vars.Qvec0) +
              this.toNumber(this.vars.Qvec1) * this.toNumber(this.vars.Qvec1) +
              this.toNumber(this.vars.Qvec2) * this.toNumber(this.vars.Qvec2)
          );
        }
      }
    }
  }

  *loadLineSurface(id, p1, p2, width, scale) {
    yield* this.loadLineSurfaceInt(
      id,
      this.itemOf(this.vars.PointDataTransformedX, p1 - 1),
      this.itemOf(this.vars.PointDataTransformedY, p1 - 1),
      this.itemOf(this.vars.PointDataTransformedZ, p1 - 1),
      this.itemOf(this.vars.PointDataTransformedX, p2 - 1),
      this.itemOf(this.vars.PointDataTransformedY, p2 - 1),
      this.itemOf(this.vars.PointDataTransformedZ, p2 - 1),
      p1,
      p2,
      width,
      scale
    );
  }

  *loadLineSurfaceInt(id, p10, p11, p12, p20, p21, p22, p1, p2, width, scale) {
    this.vars.Temp3 =
      this.toNumber(this.compare(p12, this.vars.ConstNearZ) > 0) + 0;
    this.vars.Temp4 =
      this.toNumber(this.compare(p22, this.vars.ConstNearZ) > 0) + 0;
    if (this.toNumber(this.vars.Temp3) + this.toNumber(this.vars.Temp4) === 2) {
      if (
        this.toNumber(this.itemOf(this.stage.vars.renderSettings, 33)) === 0
      ) {
        this.vars.P1X = (this.toNumber(p10) + this.toNumber(p20)) / 2;
        this.vars.P1Y = (this.toNumber(p11) + this.toNumber(p21)) / 2;
        this.vars.P1Z = (this.toNumber(p12) + this.toNumber(p22)) / 2;
        this.vars.SurfaceSortId.push(id);
        this.vars.SurfaceSortDist.push(
          this.toNumber(this.vars.P1X) * this.toNumber(this.vars.P1X) +
            this.toNumber(this.vars.P1Y) * this.toNumber(this.vars.P1Y) +
            this.toNumber(this.vars.P1Z) * this.toNumber(this.vars.P1Z)
        );
      } else {
        this.vars.Temp3 =
          this.toNumber(
            this.compare(p12, this.itemOf(this.stage.vars.renderSettings, 34)) <
              0
          ) + 0;
        this.vars.Temp4 =
          this.toNumber(
            this.compare(p22, this.itemOf(this.stage.vars.renderSettings, 34)) <
              0
          ) + 0;
        if (
          this.toNumber(this.vars.Temp3) + this.toNumber(this.vars.Temp4) ===
          2
        ) {
          this.vars.P1X = (this.toNumber(p10) + this.toNumber(p20)) / 2;
          this.vars.P1Y = (this.toNumber(p11) + this.toNumber(p21)) / 2;
          this.vars.P1Z = (this.toNumber(p12) + this.toNumber(p22)) / 2;
          this.vars.SurfaceSortId.push(id);
          this.vars.SurfaceSortDist.push(
            this.toNumber(this.vars.P1X) * this.toNumber(this.vars.P1X) +
              this.toNumber(this.vars.P1Y) * this.toNumber(this.vars.P1Y) +
              this.toNumber(this.vars.P1Z) * this.toNumber(this.vars.P1Z)
          );
        } else {
          if (this.toNumber(this.vars.Temp3) === 1) {
            yield* this.zClipLine(
              p10,
              p11,
              p12,
              p20,
              p21,
              p22,
              scale,
              this.itemOf(this.stage.vars.renderSettings, 34)
            );
            yield* this.addFakeLineSurface(
              id,
              p1,
              this.vars.PointDataTransformedX.length
            );
          } else {
            if (this.toNumber(this.vars.Temp4) === 1) {
              yield* this.zClipLine(
                p20,
                p21,
                p22,
                p10,
                p11,
                p12,
                scale,
                this.itemOf(this.stage.vars.renderSettings, 34)
              );
              yield* this.addFakeLineSurface(
                id,
                p2,
                this.vars.PointDataTransformedX.length
              );
            }
          }
        }
      }
    } else {
      if (this.toNumber(this.vars.Temp3) === 1) {
        yield* this.zClipLine(
          p10,
          p11,
          p12,
          p20,
          p21,
          p22,
          scale,
          this.vars.ConstNearZ
        );
        yield* this.addFakeLineSurface(
          id,
          p1,
          this.vars.PointDataTransformedX.length
        );
      } else {
        if (this.toNumber(this.vars.Temp4) === 1) {
          yield* this.zClipLine(
            p20,
            p21,
            p22,
            p10,
            p11,
            p12,
            scale,
            this.vars.ConstNearZ
          );
          yield* this.addFakeLineSurface(
            id,
            p2,
            this.vars.PointDataTransformedX.length
          );
        }
      }
    }
  }

  *addFakeLineSurface(oldId, p1, p2) {
    this.vars.FakeSurfacesType.push(3);
    this.vars.FakeSurfacesP1.push(p1);
    this.vars.FakeSurfacesP2.push(p2);
    this.vars.FakeSurfacesP3.push("");
    this.vars.FakeSurfacesP4.push("");
    this.vars.FakeSurfacesDiameter.push(
      this.itemOf(this.stage.vars.surfacesDiameter, oldId - 1)
    );
    this.vars.FakeSurfacesTexture.push(
      this.itemOf(this.stage.vars.surfacesTexture, oldId - 1)
    );
    this.vars.SurfaceSortId.push(0 - this.vars.FakeSurfacesP1.length);
    this.vars.FakeSurfacesN0.push("");
    this.vars.FakeSurfacesN1.push("");
    this.vars.FakeSurfacesN2.push("");
    this.vars.FakeSurfacesLightSource.push("");
    this.vars.P1X =
      (this.toNumber(this.itemOf(this.vars.PointDataTransformedX, p1 - 1)) +
        this.toNumber(this.itemOf(this.vars.PointDataTransformedX, p2 - 1))) /
      2;
    this.vars.P1Y =
      (this.toNumber(this.itemOf(this.vars.PointDataTransformedY, p1 - 1)) +
        this.toNumber(this.itemOf(this.vars.PointDataTransformedY, p2 - 1))) /
      2;
    this.vars.P1Z =
      (this.toNumber(this.itemOf(this.vars.PointDataTransformedZ, p1 - 1)) +
        this.toNumber(this.itemOf(this.vars.PointDataTransformedZ, p2 - 1))) /
      2;
    this.vars.SurfaceSortDist.push(
      this.toNumber(this.vars.P1X) * this.toNumber(this.vars.P1X) +
        this.toNumber(this.vars.P1Y) * this.toNumber(this.vars.P1Y) +
        this.toNumber(this.vars.P1Z) * this.toNumber(this.vars.P1Z)
    );
  }

  *fillTriInner1(ax, ay, bx, by, cx, cy, lena, lenb, lenc, res14) {
    this.vars.Peri =
      this.toNumber(lena) + this.toNumber(lenb) + this.toNumber(lenc);
    this.vars.Ind =
      Math.sqrt(
        ((this.toNumber(lenb) + this.toNumber(lenc) - this.toNumber(lena)) *
          (this.toNumber(lenc) + this.toNumber(lena) - this.toNumber(lenb)) *
          (this.toNumber(lena) + this.toNumber(lenb) - this.toNumber(lenc))) /
          this.toNumber(this.vars.Peri)
      ) +
      this.toNumber(res14) / 1.5;
    if (this.compare(this.vars.Ind, res14) > 0) {
      this.vars.Incx =
        (this.toNumber(lena) * this.toNumber(ax) +
          this.toNumber(lenb) * this.toNumber(bx) +
          this.toNumber(lenc) * this.toNumber(cx)) /
        this.toNumber(this.vars.Peri);
      this.vars.Incy =
        (this.toNumber(lena) * this.toNumber(ay) +
          this.toNumber(lenb) * this.toNumber(by) +
          this.toNumber(lenc) * this.toNumber(cy)) /
        this.toNumber(this.vars.Peri);
      if (this.compare(this.vars.Ind, 255) > 0) {
        yield* this.fillBigTri(
          ax,
          ay,
          bx,
          by,
          cx,
          cy,
          this.vars.Incx,
          this.vars.Incy,
          this.vars.Ind,
          res14,
          this.toNumber(this.vars.Incx) - this.toNumber(ax),
          this.toNumber(this.vars.Incy) - this.toNumber(ay),
          this.toNumber(this.vars.Incx) - this.toNumber(bx),
          this.toNumber(this.vars.Incy) - this.toNumber(by),
          this.toNumber(this.vars.Incx) - this.toNumber(cx),
          this.toNumber(this.vars.Incy) - this.toNumber(cy),
          lena,
          lenb,
          lenc
        );
      } else {
        if (
          this.compare(
            this.toNumber(this.vars.Peri) + 2500,
            this.toNumber(this.vars.Ind) * this.toNumber(this.vars.Ind)
          ) < 0
        ) {
          this.penSize = 1;
          this.goto(
            (this.toNumber(ax) + this.toNumber(this.vars.Incx)) * 0.5,
            (this.toNumber(ay) + this.toNumber(this.vars.Incy)) * 0.5
          );
          this.penDown = true;
          this.penSize = this.toNumber(this.vars.Ind) * 0.5;
          this.goto(
            (this.toNumber(bx) + this.toNumber(this.vars.Incx)) * 0.5,
            (this.toNumber(by) + this.toNumber(this.vars.Incy)) * 0.5
          );
          this.goto(
            (this.toNumber(cx) + this.toNumber(this.vars.Incx)) * 0.5,
            (this.toNumber(cy) + this.toNumber(this.vars.Incy)) * 0.5
          );
          this.goto(
            (this.toNumber(ax) + this.toNumber(this.vars.Incx)) * 0.5,
            (this.toNumber(ay) + this.toNumber(this.vars.Incy)) * 0.5
          );
          this.penDown = false;
          yield* this.fillCorners(
            ax,
            ay,
            bx,
            by,
            cx,
            cy,
            this.toNumber(this.vars.Incx) - this.toNumber(ax),
            this.toNumber(this.vars.Incy) - this.toNumber(ay),
            this.toNumber(this.vars.Incx) - this.toNumber(bx),
            this.toNumber(this.vars.Incy) - this.toNumber(by),
            this.toNumber(this.vars.Incx) - this.toNumber(cx),
            this.toNumber(this.vars.Incy) - this.toNumber(cy),
            this.vars.Ind,
            res14
          );
        } else {
          if (this.compare(lena, lenb) < 0 && this.compare(lena, lenc) < 0) {
            yield* this.fillTriInner2(
              ax,
              ay,
              bx,
              by,
              cx,
              cy,
              this.toNumber(this.vars.Incx) - this.toNumber(ax),
              this.toNumber(this.vars.Incy) - this.toNumber(ay),
              this.toNumber(this.vars.Incx) - this.toNumber(bx),
              this.toNumber(this.vars.Incy) - this.toNumber(by),
              this.toNumber(this.vars.Incx) - this.toNumber(cx),
              this.toNumber(this.vars.Incy) - this.toNumber(cy),
              this.vars.Ind,
              -0.5 -
                this.toNumber(this.vars.Ind) /
                  (Math.sqrt(
                    (this.toNumber(this.vars.Incx) - this.toNumber(ax)) *
                      (this.toNumber(this.vars.Incx) - this.toNumber(ax)) +
                      (this.toNumber(this.vars.Incy) - this.toNumber(ay)) *
                        (this.toNumber(this.vars.Incy) - this.toNumber(ay))
                  ) *
                    4.1),
              res14
            );
          } else {
            if (this.compare(lenb, lena) > 0 || this.compare(lenb, lenc) > 0) {
              yield* this.fillTriInner2(
                cx,
                cy,
                bx,
                by,
                ax,
                ay,
                this.toNumber(this.vars.Incx) - this.toNumber(cx),
                this.toNumber(this.vars.Incy) - this.toNumber(cy),
                this.toNumber(this.vars.Incx) - this.toNumber(bx),
                this.toNumber(this.vars.Incy) - this.toNumber(by),
                this.toNumber(this.vars.Incx) - this.toNumber(ax),
                this.toNumber(this.vars.Incy) - this.toNumber(ay),
                this.vars.Ind,
                -0.5 -
                  this.toNumber(this.vars.Ind) /
                    (Math.sqrt(
                      (this.toNumber(this.vars.Incx) - this.toNumber(cx)) *
                        (this.toNumber(this.vars.Incx) - this.toNumber(cx)) +
                        (this.toNumber(this.vars.Incy) - this.toNumber(cy)) *
                          (this.toNumber(this.vars.Incy) - this.toNumber(cy))
                    ) *
                      4.1),
                res14
              );
            } else {
              yield* this.fillTriInner2(
                bx,
                by,
                ax,
                ay,
                cx,
                cy,
                this.toNumber(this.vars.Incx) - this.toNumber(bx),
                this.toNumber(this.vars.Incy) - this.toNumber(by),
                this.toNumber(this.vars.Incx) - this.toNumber(ax),
                this.toNumber(this.vars.Incy) - this.toNumber(ay),
                this.toNumber(this.vars.Incx) - this.toNumber(cx),
                this.toNumber(this.vars.Incy) - this.toNumber(cy),
                this.vars.Ind,
                -0.5 -
                  this.toNumber(this.vars.Ind) /
                    (Math.sqrt(
                      (this.toNumber(this.vars.Incx) - this.toNumber(bx)) *
                        (this.toNumber(this.vars.Incx) - this.toNumber(bx)) +
                        (this.toNumber(this.vars.Incy) - this.toNumber(by)) *
                          (this.toNumber(this.vars.Incy) - this.toNumber(by))
                    ) *
                      4.1),
                res14
              );
            }
          }
        }
      }
    }
  }

  *fillCorners(
    ax,
    ay,
    bx,
    by,
    cx,
    cy,
    aox,
    aoy,
    box,
    boy,
    cox,
    coy,
    ind,
    res14
  ) {
    yield* this.fillCorner(
      ax,
      ay,
      this.toNumber(bx) - (this.toNumber(ax) - this.toNumber(aox)),
      this.toNumber(by) - (this.toNumber(ay) - this.toNumber(aoy)),
      this.toNumber(cx) - (this.toNumber(ax) - this.toNumber(aox)),
      this.toNumber(cy) - (this.toNumber(ay) - this.toNumber(aoy)),
      aox,
      aoy,
      ind,
      -0.5 -
        this.toNumber(ind) /
          (Math.sqrt(
            this.toNumber(aox) * this.toNumber(aox) +
              this.toNumber(aoy) * this.toNumber(aoy)
          ) *
            4.1),
      res14
    );
    yield* this.fillCorner(
      bx,
      by,
      this.toNumber(ax) - (this.toNumber(bx) - this.toNumber(box)),
      this.toNumber(ay) - (this.toNumber(by) - this.toNumber(boy)),
      this.toNumber(cx) - (this.toNumber(bx) - this.toNumber(box)),
      this.toNumber(cy) - (this.toNumber(by) - this.toNumber(boy)),
      box,
      boy,
      ind,
      -0.5 -
        this.toNumber(ind) /
          (Math.sqrt(
            this.toNumber(box) * this.toNumber(box) +
              this.toNumber(boy) * this.toNumber(boy)
          ) *
            4.1),
      res14
    );
    yield* this.fillCorner(
      cx,
      cy,
      this.toNumber(ax) - (this.toNumber(cx) - this.toNumber(cox)),
      this.toNumber(ay) - (this.toNumber(cy) - this.toNumber(coy)),
      this.toNumber(bx) - (this.toNumber(cx) - this.toNumber(cox)),
      this.toNumber(by) - (this.toNumber(cy) - this.toNumber(coy)),
      cox,
      coy,
      ind,
      -0.5 -
        this.toNumber(ind) /
          (Math.sqrt(
            this.toNumber(cox) * this.toNumber(cox) +
              this.toNumber(coy) * this.toNumber(coy)
          ) *
            4.1),
      res14
    );
  }

  *fillCorner(ax, ay, bAx, bAy, cAx, cAy, aox, aoy, ind, rate, res14) {
    if (
      this.compare(this.toNumber(ind) * (this.toNumber(rate) + 1), res14) > 0
    ) {
      this.vars.Td = (this.toNumber(rate) + 1) * 0.56;
      while (
        !(
          this.compare(
            this.toNumber(ind) * this.toNumber(this.vars.Td),
            res14
          ) < 0
        )
      ) {
        this.penSize = 1;
        this.goto(
          this.toNumber(ax) + this.toNumber(bAx) * this.toNumber(this.vars.Td),
          this.toNumber(ay) + this.toNumber(bAy) * this.toNumber(this.vars.Td)
        );
        this.penDown = true;
        this.penSize = this.toNumber(ind) * this.toNumber(this.vars.Td);
        this.goto(
          this.toNumber(ax) + this.toNumber(aox) * this.toNumber(this.vars.Td),
          this.toNumber(ay) + this.toNumber(aoy) * this.toNumber(this.vars.Td)
        );
        this.goto(
          this.toNumber(ax) + this.toNumber(cAx) * this.toNumber(this.vars.Td),
          this.toNumber(ay) + this.toNumber(cAy) * this.toNumber(this.vars.Td)
        );
        this.penDown = false;
        this.vars.Td += this.toNumber(this.vars.Td) * this.toNumber(rate);
        yield;
      }
      this.penSize = 1;
      this.goto(
        this.toNumber(ax) + this.toNumber(bAx) * this.toNumber(this.vars.Td),
        this.toNumber(ay) + this.toNumber(bAy) * this.toNumber(this.vars.Td)
      );
      this.penDown = true;
      this.penSize = this.toNumber(ind) * this.toNumber(this.vars.Td);
      this.goto(
        this.toNumber(ax) + this.toNumber(aox) * this.toNumber(this.vars.Td),
        this.toNumber(ay) + this.toNumber(aoy) * this.toNumber(this.vars.Td)
      );
      this.goto(
        this.toNumber(ax) + this.toNumber(cAx) * this.toNumber(this.vars.Td),
        this.toNumber(ay) + this.toNumber(cAy) * this.toNumber(this.vars.Td)
      );
      this.penDown = false;
    }
  }

  *fillTriInner2(
    ax,
    ay,
    bx,
    by,
    cx,
    cy,
    aox,
    aoy,
    box,
    boy,
    cox,
    coy,
    ind,
    rate,
    res14
  ) {
    this.goto(
      Math.round(this.toNumber(this.vars.Incx)),
      Math.round(this.toNumber(this.vars.Incy))
    );
    this.penSize = this.toNumber(ind);
    this.penDown = true;
    this.penDown = false;
    this.vars.Td = this.toNumber(rate) + 1;
    while (
      !(
        this.compare(this.toNumber(ind) * this.toNumber(this.vars.Td), res14) <
        0
      )
    ) {
      this.penSize = 1;
      this.goto(
        this.toNumber(aox) * this.toNumber(this.vars.Td) + this.toNumber(ax),
        this.toNumber(aoy) * this.toNumber(this.vars.Td) + this.toNumber(ay)
      );
      this.penDown = true;
      this.penSize = this.toNumber(ind) * this.toNumber(this.vars.Td);
      this.goto(
        this.toNumber(box) * this.toNumber(this.vars.Td) + this.toNumber(bx),
        this.toNumber(boy) * this.toNumber(this.vars.Td) + this.toNumber(by)
      );
      this.goto(
        this.toNumber(cox) * this.toNumber(this.vars.Td) + this.toNumber(cx),
        this.toNumber(coy) * this.toNumber(this.vars.Td) + this.toNumber(cy)
      );
      this.goto(
        this.toNumber(aox) * this.toNumber(this.vars.Td) + this.toNumber(ax),
        this.toNumber(aoy) * this.toNumber(this.vars.Td) + this.toNumber(ay)
      );
      this.penDown = false;
      this.vars.Td += this.toNumber(this.vars.Td) * this.toNumber(rate);
      yield;
    }
    this.penSize = 1;
    this.goto(
      this.toNumber(aox) * this.toNumber(this.vars.Td) + this.toNumber(ax),
      this.toNumber(aoy) * this.toNumber(this.vars.Td) + this.toNumber(ay)
    );
    this.penDown = true;
    this.penSize = this.toNumber(ind) * this.toNumber(this.vars.Td);
    this.goto(
      this.toNumber(box) * this.toNumber(this.vars.Td) + this.toNumber(bx),
      this.toNumber(boy) * this.toNumber(this.vars.Td) + this.toNumber(by)
    );
    this.goto(
      this.toNumber(cox) * this.toNumber(this.vars.Td) + this.toNumber(cx),
      this.toNumber(coy) * this.toNumber(this.vars.Td) + this.toNumber(cy)
    );
    this.goto(
      this.toNumber(aox) * this.toNumber(this.vars.Td) + this.toNumber(ax),
      this.toNumber(aoy) * this.toNumber(this.vars.Td) + this.toNumber(ay)
    );
    this.penDown = false;
  }

  *fillBigTri(
    ax,
    ay,
    bx,
    by,
    cx,
    cy,
    incx,
    incy,
    ind,
    minsz,
    aox,
    aoy,
    box,
    boy,
    cox,
    coy,
    lena,
    lenb,
    lenc
  ) {
    if (this.compare(lena, lenb) < 0 && this.compare(lena, lenc) < 0) {
      this.vars.A = Math.sqrt(
        this.toNumber(aox) * this.toNumber(aox) +
          this.toNumber(aoy) * this.toNumber(aoy)
      );
    } else {
      if (!(this.compare(lenb, lena) > 0 || this.compare(lenb, lenc) > 0)) {
        this.vars.A = Math.sqrt(
          this.toNumber(box) * this.toNumber(box) +
            this.toNumber(boy) * this.toNumber(boy)
        );
      } else {
        this.vars.A = Math.sqrt(
          this.toNumber(cox) * this.toNumber(cox) +
            this.toNumber(coy) * this.toNumber(coy)
        );
      }
    }
    this.vars.Rate =
      0.5 - this.toNumber(ind) / (this.toNumber(this.vars.A) * 4);
    this.vars.Td = 0.5;
    if (this.compare(ind, 512) > 0) {
      this.vars.Td = 1 - 255 / this.toNumber(this.vars.A);
      while (
        !(
          this.compare(this.toNumber(ind) * this.toNumber(this.vars.Td), 256) <
          0
        )
      ) {
        this.penSize = 255;
        this.goto(
          this.toNumber(aox) * this.toNumber(this.vars.Td) + this.toNumber(ax),
          this.toNumber(aoy) * this.toNumber(this.vars.Td) + this.toNumber(ay)
        );
        this.penDown = true;
        this.goto(
          this.toNumber(box) * this.toNumber(this.vars.Td) + this.toNumber(bx),
          this.toNumber(boy) * this.toNumber(this.vars.Td) + this.toNumber(by)
        );
        this.goto(
          this.toNumber(cox) * this.toNumber(this.vars.Td) + this.toNumber(cx),
          this.toNumber(coy) * this.toNumber(this.vars.Td) + this.toNumber(cy)
        );
        this.goto(
          this.toNumber(aox) * this.toNumber(this.vars.Td) + this.toNumber(ax),
          this.toNumber(aoy) * this.toNumber(this.vars.Td) + this.toNumber(ay)
        );
        this.penDown = false;
        this.vars.Td += -127 / this.toNumber(this.vars.A);
        yield;
      }
    }
    while (
      !(
        this.compare(this.toNumber(ind) * this.toNumber(this.vars.Td), minsz) <
        0
      )
    ) {
      this.penSize = this.toNumber(ind) * this.toNumber(this.vars.Td);
      this.goto(
        this.toNumber(aox) * this.toNumber(this.vars.Td) + this.toNumber(ax),
        this.toNumber(aoy) * this.toNumber(this.vars.Td) + this.toNumber(ay)
      );
      this.penDown = true;
      this.goto(
        this.toNumber(box) * this.toNumber(this.vars.Td) + this.toNumber(bx),
        this.toNumber(boy) * this.toNumber(this.vars.Td) + this.toNumber(by)
      );
      this.goto(
        this.toNumber(cox) * this.toNumber(this.vars.Td) + this.toNumber(cx),
        this.toNumber(coy) * this.toNumber(this.vars.Td) + this.toNumber(cy)
      );
      this.goto(
        this.toNumber(aox) * this.toNumber(this.vars.Td) + this.toNumber(ax),
        this.toNumber(aoy) * this.toNumber(this.vars.Td) + this.toNumber(ay)
      );
      this.penDown = false;
      this.vars.Td =
        this.toNumber(this.vars.Td) * this.toNumber(this.vars.Rate);
      yield;
    }
    this.penSize = this.toNumber(ind) * this.toNumber(this.vars.Td);
    this.goto(
      this.toNumber(aox) * this.toNumber(this.vars.Td) + this.toNumber(ax),
      this.toNumber(aoy) * this.toNumber(this.vars.Td) + this.toNumber(ay)
    );
    this.penDown = true;
    this.goto(
      this.toNumber(box) * this.toNumber(this.vars.Td) + this.toNumber(bx),
      this.toNumber(boy) * this.toNumber(this.vars.Td) + this.toNumber(by)
    );
    this.goto(
      this.toNumber(cox) * this.toNumber(this.vars.Td) + this.toNumber(cx),
      this.toNumber(coy) * this.toNumber(this.vars.Td) + this.toNumber(cy)
    );
    this.goto(
      this.toNumber(aox) * this.toNumber(this.vars.Td) + this.toNumber(ax),
      this.toNumber(aoy) * this.toNumber(this.vars.Td) + this.toNumber(ay)
    );
    this.penDown = false;
  }

  *loadSphereSurface(id, origin, diameter, scale) {
    this.vars.Temp3 = this.itemOf(this.vars.PointDataTransformedZ, origin - 1);
    if (
      this.compare(this.vars.Temp3, this.vars.ConstNearZ) > 0 &&
      (this.toNumber(this.itemOf(this.stage.vars.renderSettings, 33)) === 0 ||
        this.compare(
          this.vars.Temp3,
          this.itemOf(this.stage.vars.renderSettings, 34)
        ) < 0)
    ) {
      this.vars.Temp3 =
        (this.toNumber(diameter) * this.toNumber(scale)) /
        (this.toNumber(this.vars.Temp3) * 2);
      this.vars.Temp4 = this.itemOf(this.vars.ScreenPointsX, origin - 1);
      this.vars.Temp5 = this.itemOf(this.vars.ScreenPointsY, origin - 1);
      if (
        this.compare(
          this.toNumber(this.vars.Temp4) + this.toNumber(this.vars.Temp3),
          -240
        ) > 0 &&
        this.compare(
          this.toNumber(this.vars.Temp4) - this.toNumber(this.vars.Temp3),
          240
        ) < 0
      ) {
        if (
          this.compare(
            this.toNumber(this.vars.Temp5) + this.toNumber(this.vars.Temp3),
            -180
          ) > 0 &&
          this.compare(
            this.toNumber(this.vars.Temp5) - this.toNumber(this.vars.Temp3),
            180
          ) < 0
        ) {
          this.vars.SurfaceSortId.push(id);
          this.vars.SurfaceSortDist.push(
            this.toNumber(
              this.itemOf(this.vars.PointDataTransformedX, origin - 1)
            ) *
              this.toNumber(
                this.itemOf(this.vars.PointDataTransformedX, origin - 1)
              ) +
              this.toNumber(
                this.itemOf(this.vars.PointDataTransformedY, origin - 1)
              ) *
                this.toNumber(
                  this.itemOf(this.vars.PointDataTransformedY, origin - 1)
                ) +
              this.toNumber(
                this.itemOf(this.vars.PointDataTransformedZ, origin - 1)
              ) *
                this.toNumber(
                  this.itemOf(this.vars.PointDataTransformedZ, origin - 1)
                )
          );
        }
      }
    }
  }

  *sortSurfaces() {
    yield* this.sortSurfacesFromTo(1, this.vars.SurfaceSortDist.length);
  }

  *sortSurfacesFromTo(start, end) {
    if (this.compare(this.toNumber(end) - this.toNumber(start), 13) > 0) {
      this.vars.I = Math.floor(
        Math.sqrt(this.toNumber(end) - this.toNumber(start)) + 1
      );
      this.vars.Pos = start;
      this.vars.MinDist = this.itemOf(this.vars.SurfaceSortDist, start - 1);
      this.vars.Val = this.vars.MinDist;
      for (
        let i = 0;
        i <
        Math.floor(
          (this.toNumber(end) - this.toNumber(start)) /
            this.toNumber(this.vars.I)
        );
        i++
      ) {
        if (
          this.compare(
            this.itemOf(this.vars.SurfaceSortDist, this.vars.Pos - 1),
            this.vars.MinDist
          ) < 0
        ) {
          this.vars.MinDist = this.itemOf(
            this.vars.SurfaceSortDist,
            this.vars.Pos - 1
          );
        } else {
          if (
            this.compare(
              this.itemOf(this.vars.SurfaceSortDist, this.vars.Pos - 1),
              this.vars.Val
            ) > 0
          ) {
            this.vars.Val = this.itemOf(
              this.vars.SurfaceSortDist,
              this.vars.Pos - 1
            );
          }
        }
        this.vars.Pos += this.toNumber(this.vars.I);
        yield;
      }
      if (this.compare(this.vars.MinDist, this.vars.Val) === 0) {
        this.vars.Pos = start;
        for (let i = 0; i < this.toNumber(end) - this.toNumber(start); i++) {
          this.vars.Pos++;
          if (
            this.compare(
              this.itemOf(this.vars.SurfaceSortDist, this.vars.Pos - 1),
              this.vars.MinDist
            ) < 0
          ) {
            this.vars.MinDist = this.itemOf(
              this.vars.SurfaceSortDist,
              this.vars.Pos - 1
            );
          } else {
            if (
              this.compare(
                this.itemOf(this.vars.SurfaceSortDist, this.vars.Pos - 1),
                this.vars.Val
              ) > 0
            ) {
              this.vars.Val = this.itemOf(
                this.vars.SurfaceSortDist,
                this.vars.Pos - 1
              );
            }
          }
          yield;
        }
      }
      if (this.compare(this.vars.MinDist, this.vars.Val) < 0) {
        this.vars.MinDist =
          (this.toNumber(this.vars.MinDist) + this.toNumber(this.vars.Val)) / 2;
        this.vars.I = start;
        this.vars.J = end;
        while (
          !!(
            this.compare(
              this.itemOf(this.vars.SurfaceSortDist, this.vars.I - 1),
              this.vars.MinDist
            ) < 0
          )
        ) {
          this.vars.I++;
          yield;
        }
        while (
          !(
            this.compare(
              this.itemOf(this.vars.SurfaceSortDist, this.vars.J - 1),
              this.vars.MinDist
            ) < 0
          )
        ) {
          this.vars.J--;
          yield;
        }
        while (!(this.compare(this.vars.I, this.vars.J) > 0)) {
          this.vars.Val = this.itemOf(this.vars.SurfaceSortId, this.vars.J - 1);
          this.vars.SurfaceSortId.splice(
            this.vars.J - 1,
            1,
            this.itemOf(this.vars.SurfaceSortId, this.vars.I - 1)
          );
          this.vars.SurfaceSortId.splice(this.vars.I - 1, 1, this.vars.Val);
          this.vars.Val = this.itemOf(
            this.vars.SurfaceSortDist,
            this.vars.J - 1
          );
          this.vars.SurfaceSortDist.splice(
            this.vars.J - 1,
            1,
            this.itemOf(this.vars.SurfaceSortDist, this.vars.I - 1)
          );
          this.vars.SurfaceSortDist.splice(this.vars.I - 1, 1, this.vars.Val);
          this.vars.I++;
          this.vars.J--;
          while (
            !!(
              this.compare(
                this.itemOf(this.vars.SurfaceSortDist, this.vars.I - 1),
                this.vars.MinDist
              ) < 0
            )
          ) {
            this.vars.I++;
            yield;
          }
          while (
            !(
              this.compare(
                this.itemOf(this.vars.SurfaceSortDist, this.vars.J - 1),
                this.vars.MinDist
              ) < 0
            )
          ) {
            this.vars.J--;
            yield;
          }
          yield;
        }
        this.vars.SurfaceSortDist.push(this.vars.J);
        yield* this.sortSurfacesFromTo(start, this.vars.J);
        yield* this.sortSurfacesFromTo(
          this.toNumber(
            this.itemOf(
              this.vars.SurfaceSortDist,
              this.vars.SurfaceSortDist.length - 1
            )
          ) + 1,
          end
        );
        this.vars.SurfaceSortDist.splice(
          this.vars.SurfaceSortDist.length - 1,
          1
        );
      }
    } else {
      if (this.compare(end, start) > 0) {
        this.vars.I = start;
        this.vars.Val = -1 / 0;
        for (let i = 0; i < this.toNumber(end) - this.toNumber(start); i++) {
          this.vars.MinDist = this.itemOf(
            this.vars.SurfaceSortDist,
            this.vars.I - 1
          );
          this.vars.MinId = this.itemOf(
            this.vars.SurfaceSortId,
            this.vars.I - 1
          );
          if (this.compare(this.vars.MinDist, this.vars.Val) > 0) {
            this.vars.Pos = this.vars.I;
            this.vars.J = this.vars.I;
            for (
              let i = 0;
              i < this.toNumber(end) - this.toNumber(this.vars.J);
              i++
            ) {
              this.vars.J++;
              if (
                this.compare(
                  this.itemOf(this.vars.SurfaceSortDist, this.vars.J - 1),
                  this.vars.MinDist
                ) < 0
              ) {
                this.vars.MinDist = this.itemOf(
                  this.vars.SurfaceSortDist,
                  this.vars.J - 1
                );
                this.vars.MinId = this.itemOf(
                  this.vars.SurfaceSortId,
                  this.vars.J - 1
                );
                this.vars.Pos = this.vars.J;
              }
              yield;
            }
            if (this.compare(this.vars.Pos, this.vars.I) > 0) {
              this.vars.SurfaceSortDist.splice(
                this.vars.Pos - 1,
                1,
                this.itemOf(this.vars.SurfaceSortDist, this.vars.I - 1)
              );
              this.vars.SurfaceSortDist.splice(
                this.vars.I - 1,
                1,
                this.vars.MinDist
              );
              this.vars.SurfaceSortId.splice(
                this.vars.Pos - 1,
                1,
                this.itemOf(this.vars.SurfaceSortId, this.vars.I - 1)
              );
              this.vars.SurfaceSortId.splice(
                this.vars.I - 1,
                1,
                this.vars.MinId
              );
            }
            this.vars.Val = this.vars.MinDist;
          }
          this.vars.I++;
          yield;
        }
      }
    }
  }

  *drawShadowTriSurface(p1, p2, p3, scale) {
    yield* this.intDrawShadowTriSurface(
      p1,
      p2,
      p3,
      (this.toNumber(this.itemOf(this.vars.ShadowsX, p1 - 1)) *
        this.toNumber(scale)) /
        this.toNumber(this.itemOf(this.vars.ShadowsZ, p1 - 1)),
      (this.toNumber(this.itemOf(this.vars.ShadowsY, p1 - 1)) *
        this.toNumber(scale)) /
        this.toNumber(this.itemOf(this.vars.ShadowsZ, p1 - 1)),
      (this.toNumber(this.itemOf(this.vars.ShadowsX, p2 - 1)) *
        this.toNumber(scale)) /
        this.toNumber(this.itemOf(this.vars.ShadowsZ, p2 - 1)),
      (this.toNumber(this.itemOf(this.vars.ShadowsY, p2 - 1)) *
        this.toNumber(scale)) /
        this.toNumber(this.itemOf(this.vars.ShadowsZ, p2 - 1)),
      (this.toNumber(this.itemOf(this.vars.ShadowsX, p3 - 1)) *
        this.toNumber(scale)) /
        this.toNumber(this.itemOf(this.vars.ShadowsZ, p3 - 1)),
      (this.toNumber(this.itemOf(this.vars.ShadowsY, p3 - 1)) *
        this.toNumber(scale)) /
        this.toNumber(this.itemOf(this.vars.ShadowsZ, p3 - 1)),
      scale,
      this.itemOf(this.stage.vars.renderSettings, 3)
    );
  }

  *intDrawShadowTriSurface(p1, p2, p3, ax, ay, bx, by, cx, cy, scale, res) {
    this.vars.Temp3 =
      this.toNumber(
        this.compare(
          this.itemOf(this.vars.ShadowsZ, p1 - 1),
          this.vars.ConstNearZ
        ) > 0
      ) + 0;
    this.vars.Temp4 =
      this.toNumber(
        this.compare(
          this.itemOf(this.vars.ShadowsZ, p2 - 1),
          this.vars.ConstNearZ
        ) > 0
      ) + 0;
    this.vars.Temp5 =
      this.toNumber(
        this.compare(
          this.itemOf(this.vars.ShadowsZ, p3 - 1),
          this.vars.ConstNearZ
        ) > 0
      ) + 0;
    this.vars.Temp6 =
      this.toNumber(this.vars.Temp3) +
      (this.toNumber(this.vars.Temp4) + this.toNumber(this.vars.Temp5));
    if (this.toNumber(this.vars.Temp6) === 3) {
      if (
        this.toNumber(this.itemOf(this.stage.vars.renderSettings, 33)) === 0
      ) {
        yield* this.cullClipAndFillTriangleRes(ax, ay, bx, by, cx, cy, res);
      } else {
        this.vars.Temp3 =
          this.toNumber(
            this.compare(
              this.itemOf(this.vars.ShadowsZ, p1 - 1),
              this.itemOf(this.stage.vars.renderSettings, 34)
            ) < 0
          ) + 0;
        this.vars.Temp4 =
          this.toNumber(
            this.compare(
              this.itemOf(this.vars.ShadowsZ, p2 - 1),
              this.itemOf(this.stage.vars.renderSettings, 34)
            ) < 0
          ) + 0;
        this.vars.Temp5 =
          this.toNumber(
            this.compare(
              this.itemOf(this.vars.ShadowsZ, p3 - 1),
              this.itemOf(this.stage.vars.renderSettings, 34)
            ) < 0
          ) + 0;
        this.vars.Temp6 =
          this.toNumber(this.vars.Temp3) +
          (this.toNumber(this.vars.Temp4) + this.toNumber(this.vars.Temp5));
        if (this.toNumber(this.vars.Temp6) === 3) {
          yield* this.cullClipAndFillTriangleRes(ax, ay, bx, by, cx, cy, res);
        } else {
          if (this.toNumber(this.vars.Temp6) === 2) {
            if (this.toNumber(this.vars.Temp3) === 0) {
              yield* this.zClipTriShadowCase2(
                p1,
                p2,
                p3,
                this.itemOf(this.stage.vars.renderSettings, 34)
              );
              yield* this.cullClipAndFillTriangleRes(
                bx,
                by,
                cx,
                cy,
                (this.toNumber(this.vars.P2X) * this.toNumber(scale)) /
                  this.toNumber(this.vars.P2Z),
                (this.toNumber(this.vars.P2Y) * this.toNumber(scale)) /
                  this.toNumber(this.vars.P2Z),
                res
              );
              yield* this.cullClipAndFillTriangleRes(
                bx,
                by,
                (this.toNumber(this.vars.P1X) * this.toNumber(scale)) /
                  this.toNumber(this.vars.P1Z),
                (this.toNumber(this.vars.P1Y) * this.toNumber(scale)) /
                  this.toNumber(this.vars.P1Z),
                (this.toNumber(this.vars.P2X) * this.toNumber(scale)) /
                  this.toNumber(this.vars.P2Z),
                (this.toNumber(this.vars.P2Y) * this.toNumber(scale)) /
                  this.toNumber(this.vars.P2Z),
                res
              );
            } else {
              if (this.toNumber(this.vars.Temp4) === 0) {
                yield* this.zClipTriShadowCase2(
                  p2,
                  p1,
                  p3,
                  this.itemOf(this.stage.vars.renderSettings, 34)
                );
                yield* this.cullClipAndFillTriangleRes(
                  ax,
                  ay,
                  cx,
                  cy,
                  (this.toNumber(this.vars.P2X) * this.toNumber(scale)) /
                    this.toNumber(this.vars.P2Z),
                  (this.toNumber(this.vars.P2Y) * this.toNumber(scale)) /
                    this.toNumber(this.vars.P2Z),
                  res
                );
                yield* this.cullClipAndFillTriangleRes(
                  ax,
                  ay,
                  (this.toNumber(this.vars.P1X) * this.toNumber(scale)) /
                    this.toNumber(this.vars.P1Z),
                  (this.toNumber(this.vars.P1Y) * this.toNumber(scale)) /
                    this.toNumber(this.vars.P1Z),
                  (this.toNumber(this.vars.P2X) * this.toNumber(scale)) /
                    this.toNumber(this.vars.P2Z),
                  (this.toNumber(this.vars.P2Y) * this.toNumber(scale)) /
                    this.toNumber(this.vars.P2Z),
                  res
                );
              } else {
                yield* this.zClipTriShadowCase2(
                  p3,
                  p1,
                  p2,
                  this.itemOf(this.stage.vars.renderSettings, 34)
                );
                yield* this.cullClipAndFillTriangleRes(
                  ax,
                  ay,
                  bx,
                  by,
                  (this.toNumber(this.vars.P2X) * this.toNumber(scale)) /
                    this.toNumber(this.vars.P2Z),
                  (this.toNumber(this.vars.P2Y) * this.toNumber(scale)) /
                    this.toNumber(this.vars.P2Z),
                  res
                );
                yield* this.cullClipAndFillTriangleRes(
                  ax,
                  ay,
                  (this.toNumber(this.vars.P1X) * this.toNumber(scale)) /
                    this.toNumber(this.vars.P1Z),
                  (this.toNumber(this.vars.P1Y) * this.toNumber(scale)) /
                    this.toNumber(this.vars.P1Z),
                  (this.toNumber(this.vars.P2X) * this.toNumber(scale)) /
                    this.toNumber(this.vars.P2Z),
                  (this.toNumber(this.vars.P2Y) * this.toNumber(scale)) /
                    this.toNumber(this.vars.P2Z),
                  res
                );
              }
            }
          } else {
            if (this.toNumber(this.vars.Temp6) === 1) {
              if (
                this.toNumber(this.vars.Temp3) === 0 &&
                this.toNumber(this.vars.Temp4) === 0
              ) {
                yield* this.zClipTriShadowCase1(
                  p1,
                  p2,
                  p3,
                  this.itemOf(this.stage.vars.renderSettings, 34)
                );
                yield* this.cullClipAndFillTriangleRes(
                  (this.toNumber(this.vars.P1X) * this.toNumber(scale)) /
                    this.toNumber(this.vars.P1Z),
                  (this.toNumber(this.vars.P1Y) * this.toNumber(scale)) /
                    this.toNumber(this.vars.P1Z),
                  (this.toNumber(this.vars.P2X) * this.toNumber(scale)) /
                    this.toNumber(this.vars.P2Z),
                  (this.toNumber(this.vars.P2Y) * this.toNumber(scale)) /
                    this.toNumber(this.vars.P2Z),
                  cx,
                  cy,
                  res
                );
              } else {
                if (
                  this.toNumber(this.vars.Temp4) === 0 &&
                  this.toNumber(this.vars.Temp5) === 0
                ) {
                  yield* this.zClipTriShadowCase1(
                    p2,
                    p3,
                    p1,
                    this.itemOf(this.stage.vars.renderSettings, 34)
                  );
                  yield* this.cullClipAndFillTriangleRes(
                    ax,
                    ay,
                    (this.toNumber(this.vars.P1X) * this.toNumber(scale)) /
                      this.toNumber(this.vars.P1Z),
                    (this.toNumber(this.vars.P1Y) * this.toNumber(scale)) /
                      this.toNumber(this.vars.P1Z),
                    (this.toNumber(this.vars.P2X) * this.toNumber(scale)) /
                      this.toNumber(this.vars.P2Z),
                    (this.toNumber(this.vars.P2Y) * this.toNumber(scale)) /
                      this.toNumber(this.vars.P2Z),
                    res
                  );
                } else {
                  yield* this.zClipTriShadowCase1(
                    p1,
                    p3,
                    p2,
                    this.itemOf(this.stage.vars.renderSettings, 34)
                  );
                  yield* this.cullClipAndFillTriangleRes(
                    (this.toNumber(this.vars.P1X) * this.toNumber(scale)) /
                      this.toNumber(this.vars.P1Z),
                    (this.toNumber(this.vars.P1Y) * this.toNumber(scale)) /
                      this.toNumber(this.vars.P1Z),
                    bx,
                    by,
                    (this.toNumber(this.vars.P2X) * this.toNumber(scale)) /
                      this.toNumber(this.vars.P2Z),
                    (this.toNumber(this.vars.P2Y) * this.toNumber(scale)) /
                      this.toNumber(this.vars.P2Z),
                    res
                  );
                }
              }
            }
          }
        }
      }
    } else {
      if (this.toNumber(this.vars.Temp6) === 2) {
        if (this.toNumber(this.vars.Temp3) === 0) {
          yield* this.zClipTriShadowCase2(p1, p2, p3, this.vars.ConstNearZ);
          yield* this.cullClipAndFillTriangleRes(
            bx,
            by,
            cx,
            cy,
            (this.toNumber(this.vars.P2X) * this.toNumber(scale)) /
              this.toNumber(this.vars.P2Z),
            (this.toNumber(this.vars.P2Y) * this.toNumber(scale)) /
              this.toNumber(this.vars.P2Z),
            res
          );
          yield* this.cullClipAndFillTriangleRes(
            bx,
            by,
            (this.toNumber(this.vars.P1X) * this.toNumber(scale)) /
              this.toNumber(this.vars.P1Z),
            (this.toNumber(this.vars.P1Y) * this.toNumber(scale)) /
              this.toNumber(this.vars.P1Z),
            (this.toNumber(this.vars.P2X) * this.toNumber(scale)) /
              this.toNumber(this.vars.P2Z),
            (this.toNumber(this.vars.P2Y) * this.toNumber(scale)) /
              this.toNumber(this.vars.P2Z),
            res
          );
        } else {
          if (this.toNumber(this.vars.Temp4) === 0) {
            yield* this.zClipTriShadowCase2(p2, p1, p3, this.vars.ConstNearZ);
            yield* this.cullClipAndFillTriangleRes(
              ax,
              ay,
              cx,
              cy,
              (this.toNumber(this.vars.P2X) * this.toNumber(scale)) /
                this.toNumber(this.vars.P2Z),
              (this.toNumber(this.vars.P2Y) * this.toNumber(scale)) /
                this.toNumber(this.vars.P2Z),
              res
            );
            yield* this.cullClipAndFillTriangleRes(
              ax,
              ay,
              (this.toNumber(this.vars.P1X) * this.toNumber(scale)) /
                this.toNumber(this.vars.P1Z),
              (this.toNumber(this.vars.P1Y) * this.toNumber(scale)) /
                this.toNumber(this.vars.P1Z),
              (this.toNumber(this.vars.P2X) * this.toNumber(scale)) /
                this.toNumber(this.vars.P2Z),
              (this.toNumber(this.vars.P2Y) * this.toNumber(scale)) /
                this.toNumber(this.vars.P2Z),
              res
            );
          } else {
            yield* this.zClipTriShadowCase2(p3, p1, p2, this.vars.ConstNearZ);
            yield* this.cullClipAndFillTriangleRes(
              ax,
              ay,
              bx,
              by,
              (this.toNumber(this.vars.P2X) * this.toNumber(scale)) /
                this.toNumber(this.vars.P2Z),
              (this.toNumber(this.vars.P2Y) * this.toNumber(scale)) /
                this.toNumber(this.vars.P2Z),
              res
            );
            yield* this.cullClipAndFillTriangleRes(
              ax,
              ay,
              (this.toNumber(this.vars.P1X) * this.toNumber(scale)) /
                this.toNumber(this.vars.P1Z),
              (this.toNumber(this.vars.P1Y) * this.toNumber(scale)) /
                this.toNumber(this.vars.P1Z),
              (this.toNumber(this.vars.P2X) * this.toNumber(scale)) /
                this.toNumber(this.vars.P2Z),
              (this.toNumber(this.vars.P2Y) * this.toNumber(scale)) /
                this.toNumber(this.vars.P2Z),
              res
            );
          }
        }
      } else {
        if (this.toNumber(this.vars.Temp6) === 1) {
          if (
            this.toNumber(this.vars.Temp3) === 0 &&
            this.toNumber(this.vars.Temp4) === 0
          ) {
            yield* this.zClipTriShadowCase1(p1, p2, p3, this.vars.ConstNearZ);
            yield* this.cullClipAndFillTriangleRes(
              (this.toNumber(this.vars.P1X) * this.toNumber(scale)) /
                this.toNumber(this.vars.P1Z),
              (this.toNumber(this.vars.P1Y) * this.toNumber(scale)) /
                this.toNumber(this.vars.P1Z),
              (this.toNumber(this.vars.P2X) * this.toNumber(scale)) /
                this.toNumber(this.vars.P2Z),
              (this.toNumber(this.vars.P2Y) * this.toNumber(scale)) /
                this.toNumber(this.vars.P2Z),
              cx,
              cy,
              res
            );
          } else {
            if (
              this.toNumber(this.vars.Temp4) === 0 &&
              this.toNumber(this.vars.Temp5) === 0
            ) {
              yield* this.zClipTriShadowCase1(p2, p3, p1, this.vars.ConstNearZ);
              yield* this.cullClipAndFillTriangleRes(
                ax,
                ay,
                (this.toNumber(this.vars.P1X) * this.toNumber(scale)) /
                  this.toNumber(this.vars.P1Z),
                (this.toNumber(this.vars.P1Y) * this.toNumber(scale)) /
                  this.toNumber(this.vars.P1Z),
                (this.toNumber(this.vars.P2X) * this.toNumber(scale)) /
                  this.toNumber(this.vars.P2Z),
                (this.toNumber(this.vars.P2Y) * this.toNumber(scale)) /
                  this.toNumber(this.vars.P2Z),
                res
              );
            } else {
              yield* this.zClipTriShadowCase1(p1, p3, p2, this.vars.ConstNearZ);
              yield* this.cullClipAndFillTriangleRes(
                (this.toNumber(this.vars.P1X) * this.toNumber(scale)) /
                  this.toNumber(this.vars.P1Z),
                (this.toNumber(this.vars.P1Y) * this.toNumber(scale)) /
                  this.toNumber(this.vars.P1Z),
                bx,
                by,
                (this.toNumber(this.vars.P2X) * this.toNumber(scale)) /
                  this.toNumber(this.vars.P2Z),
                (this.toNumber(this.vars.P2Y) * this.toNumber(scale)) /
                  this.toNumber(this.vars.P2Z),
                res
              );
            }
          }
        }
      }
    }
  }

  *zClipTriShadowCase2(p1, p2, p3, newZ) {
    yield* this.intZClipTriShadowCase2(
      this.itemOf(this.vars.ShadowsX, p1 - 1),
      this.itemOf(this.vars.ShadowsY, p1 - 1),
      this.itemOf(this.vars.ShadowsZ, p1 - 1),
      this.itemOf(this.vars.ShadowsX, p2 - 1),
      this.itemOf(this.vars.ShadowsY, p2 - 1),
      this.itemOf(this.vars.ShadowsZ, p2 - 1),
      this.itemOf(this.vars.ShadowsX, p3 - 1),
      this.itemOf(this.vars.ShadowsY, p3 - 1),
      this.itemOf(this.vars.ShadowsZ, p3 - 1),
      newZ
    );
  }

  *intZClipTriShadowCase2(a0, a1, a2, b0, b1, b2, c0, c1, c2, newZ) {
    this.vars.E00 = this.toNumber(b0) - this.toNumber(a0);
    this.vars.E01 = this.toNumber(b1) - this.toNumber(a1);
    this.vars.E02 = this.toNumber(b2) - this.toNumber(a2);
    this.vars.E10 = this.toNumber(c0) - this.toNumber(a0);
    this.vars.E11 = this.toNumber(c1) - this.toNumber(a1);
    this.vars.E12 = this.toNumber(c2) - this.toNumber(a2);
    this.vars.T =
      (this.toNumber(b2) - this.toNumber(newZ)) / this.toNumber(this.vars.E02);
    this.vars.P1X =
      this.toNumber(b0) -
      this.toNumber(this.vars.E00) * this.toNumber(this.vars.T);
    this.vars.P1Y =
      this.toNumber(b1) -
      this.toNumber(this.vars.E01) * this.toNumber(this.vars.T);
    this.vars.P1Z = newZ;
    this.vars.T =
      (this.toNumber(c2) - this.toNumber(newZ)) / this.toNumber(this.vars.E12);
    this.vars.P2X =
      this.toNumber(c0) -
      this.toNumber(this.vars.E10) * this.toNumber(this.vars.T);
    this.vars.P2Y =
      this.toNumber(c1) -
      this.toNumber(this.vars.E11) * this.toNumber(this.vars.T);
    this.vars.P2Z = newZ;
  }

  *zClipTriShadowCase1(p1, p2, p3, newZ) {
    yield* this.intZClipTriShadowCase1(
      this.itemOf(this.vars.ShadowsX, p1 - 1),
      this.itemOf(this.vars.ShadowsY, p1 - 1),
      this.itemOf(this.vars.ShadowsZ, p1 - 1),
      this.itemOf(this.vars.ShadowsX, p2 - 1),
      this.itemOf(this.vars.ShadowsY, p2 - 1),
      this.itemOf(this.vars.ShadowsZ, p2 - 1),
      this.itemOf(this.vars.ShadowsX, p3 - 1),
      this.itemOf(this.vars.ShadowsY, p3 - 1),
      this.itemOf(this.vars.ShadowsZ, p3 - 1),
      newZ
    );
  }

  *intZClipTriShadowCase1(a0, a1, a2, b0, b1, b2, c0, c1, c2, newZ) {
    this.vars.E00 = this.toNumber(c0) - this.toNumber(a0);
    this.vars.E01 = this.toNumber(c1) - this.toNumber(a1);
    this.vars.E02 = this.toNumber(c2) - this.toNumber(a2);
    this.vars.E10 = this.toNumber(c0) - this.toNumber(b0);
    this.vars.E11 = this.toNumber(c1) - this.toNumber(b1);
    this.vars.E12 = this.toNumber(c2) - this.toNumber(b2);
    this.vars.T =
      (this.toNumber(c2) - this.toNumber(newZ)) / this.toNumber(this.vars.E02);
    this.vars.P1X =
      this.toNumber(c0) -
      this.toNumber(this.vars.E00) * this.toNumber(this.vars.T);
    this.vars.P1Y =
      this.toNumber(c1) -
      this.toNumber(this.vars.E01) * this.toNumber(this.vars.T);
    this.vars.P1Z = newZ;
    this.vars.T =
      (this.toNumber(c2) - this.toNumber(newZ)) / this.toNumber(this.vars.E12);
    this.vars.P2X =
      this.toNumber(c0) -
      this.toNumber(this.vars.E10) * this.toNumber(this.vars.T);
    this.vars.P2Y =
      this.toNumber(c1) -
      this.toNumber(this.vars.E11) * this.toNumber(this.vars.T);
    this.vars.P2Z = newZ;
  }

  *cullClipAndFillTriangleRes(ax, ay, bx, by, cx, cy, res) {
    if (
      !(
        this.compare(ax, 240) > 0 &&
        this.compare(bx, 240) > 0 &&
        this.compare(cx, 240) > 0
      )
    ) {
      if (
        !(
          this.compare(ax, -240) < 0 &&
          this.compare(bx, -240) < 0 &&
          this.compare(cx, -240) < 0
        )
      ) {
        if (
          !(
            this.compare(ay, -180) < 0 &&
            this.compare(by, -180) < 0 &&
            this.compare(cy, -180) < 0
          )
        ) {
          yield* this.intClipTriangleRes(ax, ay, bx, by, cx, cy, res);
        }
      }
    }
  }

  *drawShadowLineSurface(p1, p2, width, scale) {
    yield* this.intDrawShadowLineSurface(
      p1,
      p2,
      width,
      this.itemOf(this.vars.ShadowsX, p1 - 1),
      this.itemOf(this.vars.ShadowsY, p1 - 1),
      this.itemOf(this.vars.ShadowsZ, p1 - 1),
      this.itemOf(this.vars.ShadowsX, p2 - 1),
      this.itemOf(this.vars.ShadowsY, p2 - 1),
      this.itemOf(this.vars.ShadowsZ, p2 - 1),
      scale
    );
  }

  *intDrawShadowLineSurface(p1, p2, width, a0, a1, a2, b0, b1, b2, scale) {
    this.vars.Temp3 =
      this.toNumber(this.compare(a2, this.vars.ConstNearZ) > 0) + 0;
    this.vars.Temp4 =
      this.toNumber(this.compare(b2, this.vars.ConstNearZ) > 0) + 0;
    if (this.toNumber(this.vars.Temp3) + this.toNumber(this.vars.Temp4) === 2) {
      if (
        this.toNumber(this.itemOf(this.stage.vars.renderSettings, 33)) === 0
      ) {
        yield* this.cullAndDrawLineFromToStartWidthEndWidth(
          (this.toNumber(a0) * this.toNumber(scale)) / this.toNumber(a2),
          (this.toNumber(a1) * this.toNumber(scale)) / this.toNumber(a2),
          (this.toNumber(b0) * this.toNumber(scale)) / this.toNumber(b2),
          (this.toNumber(b1) * this.toNumber(scale)) / this.toNumber(b2),
          Math.round(
            (this.toNumber(width) * this.toNumber(scale)) / this.toNumber(a2)
          ),
          Math.round(
            (this.toNumber(width) * this.toNumber(scale)) / this.toNumber(b2)
          )
        );
      } else {
        this.vars.Temp3 =
          this.toNumber(
            this.compare(a2, this.itemOf(this.stage.vars.renderSettings, 34)) <
              0
          ) + 0;
        this.vars.Temp4 =
          this.toNumber(
            this.compare(b2, this.itemOf(this.stage.vars.renderSettings, 34)) <
              0
          ) + 0;
        if (
          this.toNumber(this.vars.Temp3) + this.toNumber(this.vars.Temp4) ===
          2
        ) {
          yield* this.cullAndDrawLineFromToStartWidthEndWidth(
            (this.toNumber(a0) * this.toNumber(scale)) / this.toNumber(a2),
            (this.toNumber(a1) * this.toNumber(scale)) / this.toNumber(a2),
            (this.toNumber(b0) * this.toNumber(scale)) / this.toNumber(b2),
            (this.toNumber(b1) * this.toNumber(scale)) / this.toNumber(b2),
            Math.round(
              (this.toNumber(width) * this.toNumber(scale)) / this.toNumber(a2)
            ),
            Math.round(
              (this.toNumber(width) * this.toNumber(scale)) / this.toNumber(b2)
            )
          );
        } else {
          if (this.toNumber(this.vars.Temp3) === 1) {
            this.vars.T =
              (this.toNumber(b2) -
                this.toNumber(
                  this.itemOf(this.stage.vars.renderSettings, 34)
                )) /
              (this.toNumber(b2) - this.toNumber(a2));
            yield* this.cullAndDrawLineFromToStartWidthEndWidth(
              (this.toNumber(a0) * this.toNumber(scale)) / this.toNumber(a2),
              (this.toNumber(a1) * this.toNumber(scale)) / this.toNumber(a2),
              ((this.toNumber(b0) -
                (this.toNumber(b0) - this.toNumber(a0)) *
                  this.toNumber(this.vars.T)) *
                this.toNumber(scale)) /
                this.toNumber(this.itemOf(this.stage.vars.renderSettings, 34)),
              ((this.toNumber(b1) -
                (this.toNumber(b1) - this.toNumber(a1)) *
                  this.toNumber(this.vars.T)) *
                this.toNumber(scale)) /
                this.toNumber(this.itemOf(this.stage.vars.renderSettings, 34)),
              Math.round(
                (this.toNumber(width) * this.toNumber(scale)) /
                  this.toNumber(a2)
              ),
              Math.round(
                (this.toNumber(width) * this.toNumber(scale)) /
                  this.toNumber(this.itemOf(this.stage.vars.renderSettings, 34))
              )
            );
          } else {
            if (this.toNumber(this.vars.Temp4) === 1) {
              this.vars.T =
                (this.toNumber(a2) -
                  this.toNumber(
                    this.itemOf(this.stage.vars.renderSettings, 34)
                  )) /
                (this.toNumber(a2) - this.toNumber(b2));
              yield* this.cullAndDrawLineFromToStartWidthEndWidth(
                ((this.toNumber(a0) -
                  (this.toNumber(a0) - this.toNumber(b0)) *
                    this.toNumber(this.vars.T)) *
                  this.toNumber(scale)) /
                  this.toNumber(
                    this.itemOf(this.stage.vars.renderSettings, 34)
                  ),
                ((this.toNumber(a1) -
                  (this.toNumber(a1) - this.toNumber(b1)) *
                    this.toNumber(this.vars.T)) *
                  this.toNumber(scale)) /
                  this.toNumber(
                    this.itemOf(this.stage.vars.renderSettings, 34)
                  ),
                (this.toNumber(b0) * this.toNumber(scale)) / this.toNumber(b2),
                (this.toNumber(b1) * this.toNumber(scale)) / this.toNumber(b2),
                Math.round(
                  (this.toNumber(width) * this.toNumber(scale)) /
                    this.toNumber(
                      this.itemOf(this.stage.vars.renderSettings, 34)
                    )
                ),
                Math.round(
                  (this.toNumber(width) * this.toNumber(scale)) /
                    this.toNumber(b2)
                )
              );
            }
          }
        }
      }
    } else {
      if (this.toNumber(this.vars.Temp3) === 1) {
        this.vars.T =
          (this.toNumber(b2) - this.toNumber(this.vars.ConstNearZ)) /
          (this.toNumber(b2) - this.toNumber(a2));
        yield* this.cullAndDrawLineFromToStartWidthEndWidth(
          (this.toNumber(a0) * this.toNumber(scale)) / this.toNumber(a2),
          (this.toNumber(a1) * this.toNumber(scale)) / this.toNumber(a2),
          ((this.toNumber(b0) -
            (this.toNumber(b0) - this.toNumber(a0)) *
              this.toNumber(this.vars.T)) *
            this.toNumber(scale)) /
            this.toNumber(this.vars.ConstNearZ),
          ((this.toNumber(b1) -
            (this.toNumber(b1) - this.toNumber(a1)) *
              this.toNumber(this.vars.T)) *
            this.toNumber(scale)) /
            this.toNumber(this.vars.ConstNearZ),
          Math.round(
            (this.toNumber(width) * this.toNumber(scale)) / this.toNumber(a2)
          ),
          Math.round(
            (this.toNumber(width) * this.toNumber(scale)) /
              this.toNumber(this.vars.ConstNearZ)
          )
        );
      } else {
        if (this.toNumber(this.vars.Temp4) === 1) {
          this.vars.T =
            (this.toNumber(a2) - this.toNumber(this.vars.ConstNearZ)) /
            (this.toNumber(a2) - this.toNumber(b2));
          yield* this.cullAndDrawLineFromToStartWidthEndWidth(
            ((this.toNumber(a0) -
              (this.toNumber(a0) - this.toNumber(b0)) *
                this.toNumber(this.vars.T)) *
              this.toNumber(scale)) /
              this.toNumber(this.vars.ConstNearZ),
            ((this.toNumber(a1) -
              (this.toNumber(a1) - this.toNumber(b1)) *
                this.toNumber(this.vars.T)) *
              this.toNumber(scale)) /
              this.toNumber(this.vars.ConstNearZ),
            (this.toNumber(b0) * this.toNumber(scale)) / this.toNumber(b2),
            (this.toNumber(b1) * this.toNumber(scale)) / this.toNumber(b2),
            Math.round(
              (this.toNumber(width) * this.toNumber(scale)) /
                this.toNumber(this.vars.ConstNearZ)
            ),
            Math.round(
              (this.toNumber(width) * this.toNumber(scale)) / this.toNumber(b2)
            )
          );
        }
      }
    }
  }

  *cullAndDrawLineFromToStartWidthEndWidth(x1, y1, x2, y2, start, end) {
    if (
      (this.compare(x1, -240) > 0 || this.compare(x2, -240) > 0) &&
      (this.compare(x1, 240) < 0 || this.compare(x2, 240) < 0)
    ) {
      if (
        (this.compare(y1, -180) > 0 || this.compare(y2, -180) > 0) &&
        (this.compare(y1, 180) < 0 || this.compare(y2, 180) < 0)
      ) {
        yield* this.drawLineFromXYToXYStartWidthEndWidth(
          x1,
          y1,
          x2,
          y2,
          start,
          end
        );
      }
    }
  }

  *drawShadowSphereSurface(origin, diameter, scale) {
    yield* this.intDrawShadowSphereSurface(
      origin,
      diameter,
      this.itemOf(this.vars.ShadowsX, origin - 1),
      this.itemOf(this.vars.ShadowsY, origin - 1),
      this.itemOf(this.vars.ShadowsZ, origin - 1),
      scale
    );
  }

  *intDrawShadowSphereSurface(origin, diameter, a0, a1, a2, scale) {
    if (this.compare(a2, this.vars.ConstNearZ) > 0) {
      this.goto(
        (this.toNumber(a0) * this.toNumber(scale)) / this.toNumber(a2),
        (this.toNumber(a1) * this.toNumber(scale)) / this.toNumber(a2)
      );
      this.penSize =
        (Math.abs(
          this.toNumber(diameter) /
            Math.sin(
              this.degToRad(
                this.radToDeg(
                  Math.atan(
                    this.toNumber(
                      this.itemOf(this.stage.vars.lightSourcesY, 0)
                    ) /
                      this.toNumber(
                        this.itemOf(this.stage.vars.lightSourcesX, 0)
                      )
                  )
                )
              )
            )
        ) *
          this.toNumber(scale)) /
        this.toNumber(a2);
      this.penDown = true;
      this.penDown = false;
    }
  }

  *intClipTriangleRes(ax, ay, bx, by, cx, cy, res) {
    if (this.toNumber(this.itemOf(this.stage.vars.renderSettings, 32)) === 1) {
      if (this.compare(ax, -500) < 0) {
        if (this.compare(bx, -500) < 0) {
          yield* this.fillTriangleResolution(
            cx,
            cy,
            -240,
            this.toNumber(ay) +
              (this.toNumber(cy) - this.toNumber(ay)) *
                ((-240 - this.toNumber(ax)) /
                  (this.toNumber(cx) - this.toNumber(ax))),
            -240,
            this.toNumber(by) +
              (this.toNumber(cy) - this.toNumber(by)) *
                ((-240 - this.toNumber(bx)) /
                  (this.toNumber(cx) - this.toNumber(bx))),
            res
          );
        } else {
          if (this.compare(cx, -500) < 0) {
            yield* this.fillTriangleResolution(
              bx,
              by,
              -240,
              this.toNumber(ay) +
                (this.toNumber(by) - this.toNumber(ay)) *
                  ((-240 - this.toNumber(ax)) /
                    (this.toNumber(bx) - this.toNumber(ax))),
              -240,
              this.toNumber(cy) +
                (this.toNumber(by) - this.toNumber(cy)) *
                  ((-240 - this.toNumber(cx)) /
                    (this.toNumber(bx) - this.toNumber(cx))),
              res
            );
          } else {
            yield* this.fillTriangleResolution(ax, ay, bx, by, cx, cy, res);
          }
        }
      } else {
        if (this.compare(bx, -500) < 0) {
          if (this.compare(cx, -500) < 0) {
            yield* this.fillTriangleResolution(
              ax,
              ay,
              -240,
              this.toNumber(by) +
                (this.toNumber(ay) - this.toNumber(by)) *
                  ((-240 - this.toNumber(bx)) /
                    (this.toNumber(ax) - this.toNumber(bx))),
              -240,
              this.toNumber(cy) +
                (this.toNumber(ay) - this.toNumber(cy)) *
                  ((-240 - this.toNumber(cx)) /
                    (this.toNumber(ax) - this.toNumber(cx))),
              res
            );
          } else {
            yield* this.fillTriangleResolution(ax, ay, bx, by, cx, cy, res);
          }
        } else {
          if (this.compare(cx, -500) < 0) {
            yield* this.fillTriangleResolution(ax, ay, bx, by, cx, cy, res);
          } else {
            if (this.compare(ax, 500) > 0) {
              if (this.compare(bx, 500) > 0) {
                yield* this.fillTriangleResolution(
                  cx,
                  cy,
                  240,
                  this.toNumber(ay) +
                    (this.toNumber(cy) - this.toNumber(ay)) *
                      ((240 - this.toNumber(ax)) /
                        (this.toNumber(cx) - this.toNumber(ax))),
                  240,
                  this.toNumber(by) +
                    (this.toNumber(cy) - this.toNumber(by)) *
                      ((240 - this.toNumber(bx)) /
                        (this.toNumber(cx) - this.toNumber(bx))),
                  res
                );
              } else {
                if (this.compare(cx, 500) > 0) {
                  yield* this.fillTriangleResolution(
                    bx,
                    by,
                    240,
                    this.toNumber(ay) +
                      (this.toNumber(by) - this.toNumber(ay)) *
                        ((240 - this.toNumber(ax)) /
                          (this.toNumber(bx) - this.toNumber(ax))),
                    240,
                    this.toNumber(cy) +
                      (this.toNumber(by) - this.toNumber(cy)) *
                        ((240 - this.toNumber(cx)) /
                          (this.toNumber(bx) - this.toNumber(cx))),
                    res
                  );
                } else {
                  yield* this.fillTriangleResolution(
                    ax,
                    ay,
                    bx,
                    by,
                    cx,
                    cy,
                    res
                  );
                }
              }
            } else {
              if (this.compare(bx, 500) > 0) {
                if (this.compare(cx, 500) > 0) {
                  yield* this.fillTriangleResolution(
                    ax,
                    ay,
                    240,
                    this.toNumber(by) +
                      (this.toNumber(ay) - this.toNumber(by)) *
                        ((240 - this.toNumber(bx)) /
                          (this.toNumber(ax) - this.toNumber(bx))),
                    240,
                    this.toNumber(cy) +
                      (this.toNumber(ay) - this.toNumber(cy)) *
                        ((240 - this.toNumber(cx)) /
                          (this.toNumber(ax) - this.toNumber(cx))),
                    res
                  );
                } else {
                  yield* this.fillTriangleResolution(
                    ax,
                    ay,
                    bx,
                    by,
                    cx,
                    cy,
                    res
                  );
                }
              } else {
                if (this.compare(cx, 500) > 0) {
                  yield* this.fillTriangleResolution(
                    ax,
                    ay,
                    bx,
                    by,
                    cx,
                    cy,
                    res
                  );
                } else {
                  yield* this.fillTriangleResolution(
                    ax,
                    ay,
                    bx,
                    by,
                    cx,
                    cy,
                    res
                  );
                }
              }
            }
          }
        }
      }
    } else {
      yield* this.fillTriangleResolution(ax, ay, bx, by, cx, cy, res);
    }
  }

  *drawLineFromXYToXYStartWidthEndWidth(x1, y1, x2, y2, startSize, endSize) {
    if (this.compare(startSize, endSize) === 0) {
      this.goto(this.toNumber(x1), this.toNumber(y1));
      this.penSize = 1;
      this.penDown = true;
      this.penSize = this.toNumber(startSize);
      this.goto(this.toNumber(x2), this.toNumber(y2));
      this.penDown = false;
    } else {
      this.vars.Distance =
        Math.sqrt(
          (this.toNumber(x2) - this.toNumber(x1)) *
            (this.toNumber(x2) - this.toNumber(x1)) +
            (this.toNumber(y2) - this.toNumber(y1)) *
              (this.toNumber(y2) - this.toNumber(y1))
        ) * 2;
      if (this.compare(endSize, startSize) > 0) {
        yield* this.intDrawLine(
          x1,
          y1,
          x2,
          y2,
          startSize,
          endSize,
          (this.toNumber(y2) - this.toNumber(y1)) /
            this.toNumber(this.vars.Distance),
          (this.toNumber(x1) - this.toNumber(x2)) /
            this.toNumber(this.vars.Distance),
          this.toNumber(endSize) - this.toNumber(startSize),
          this.toNumber(x2) - this.toNumber(x1),
          this.toNumber(y2) - this.toNumber(y1)
        );
      } else {
        yield* this.intDrawLine(
          x2,
          y2,
          x1,
          y1,
          endSize,
          startSize,
          (this.toNumber(y1) - this.toNumber(y2)) /
            this.toNumber(this.vars.Distance),
          (this.toNumber(x2) - this.toNumber(x1)) /
            this.toNumber(this.vars.Distance),
          this.toNumber(startSize) - this.toNumber(endSize),
          this.toNumber(x1) - this.toNumber(x2),
          this.toNumber(y1) - this.toNumber(y2)
        );
      }
    }
  }

  *intDrawLine(
    x1,
    y1,
    x2,
    y2,
    startSize,
    endSize,
    xNormal,
    yNormal,
    sizeDiff,
    xDiff,
    yDiff
  ) {
    this.vars.DrawX = x1;
    this.vars.DrawY = y1;
    if (this.compare(startSize, 1) < 0) {
      this.vars.DrawSize = 1;
    } else {
      this.vars.DrawSize = startSize;
    }
    while (
      !(this.compare(this.toNumber(this.vars.DrawSize) * 2, endSize) > 0)
    ) {
      this.vars.DrawPerc =
        (2 * this.toNumber(this.vars.DrawSize) - this.toNumber(startSize)) /
        this.toNumber(sizeDiff);
      this.vars.DrawXNew =
        this.toNumber(x1) +
        this.toNumber(xDiff) * this.toNumber(this.vars.DrawPerc);
      this.vars.DrawYNew =
        this.toNumber(y1) +
        this.toNumber(yDiff) * this.toNumber(this.vars.DrawPerc);
      this.penSize = 1;
      this.goto(
        this.toNumber(this.vars.DrawXNew) -
          this.toNumber(this.vars.DrawSize) * this.toNumber(xNormal),
        this.toNumber(this.vars.DrawYNew) -
          this.toNumber(this.vars.DrawSize) * this.toNumber(yNormal)
      );
      this.penDown = true;
      this.penSize = this.toNumber(this.vars.DrawSize);
      this.goto(this.toNumber(this.vars.DrawX), this.toNumber(this.vars.DrawY));
      this.goto(
        this.toNumber(this.vars.DrawXNew) +
          this.toNumber(this.vars.DrawSize) * this.toNumber(xNormal),
        this.toNumber(this.vars.DrawYNew) +
          this.toNumber(this.vars.DrawSize) * this.toNumber(yNormal)
      );
      this.penDown = false;
      this.vars.DrawX = this.vars.DrawXNew;
      this.vars.DrawY = this.vars.DrawYNew;
      this.vars.DrawSize = this.toNumber(this.vars.DrawSize) * 2;
      yield;
    }
    this.goto(
      this.toNumber(x2) -
        (this.toNumber(endSize) - this.toNumber(this.vars.DrawSize)) *
          this.toNumber(xNormal),
      this.toNumber(y2) -
        (this.toNumber(endSize) - this.toNumber(this.vars.DrawSize)) *
          this.toNumber(yNormal)
    );
    this.penSize = 1;
    this.penDown = true;
    this.penSize = this.toNumber(this.vars.DrawSize);
    this.goto(this.toNumber(this.vars.DrawX), this.toNumber(this.vars.DrawY));
    this.goto(
      this.toNumber(x2) +
        (this.toNumber(endSize) - this.toNumber(this.vars.DrawSize)) *
          this.toNumber(xNormal),
      this.toNumber(y2) +
        (this.toNumber(endSize) - this.toNumber(this.vars.DrawSize)) *
          this.toNumber(yNormal)
    );
    this.penDown = false;
    this.goto(this.toNumber(x2), this.toNumber(y2));
    this.penSize = this.toNumber(endSize);
    this.penDown = true;
    this.penDown = false;
  }

  *whenIReceiveInitFinal() {
    this.vars.ConstNearZ = 5;
    this.costume = "dot";
    this.size = 2000000;
    this.costume = "draw";
    yield* this.createWorldViewTransformation();
    yield* this.updatePointsAndLoadSurfaces(
      this.itemOf(this.stage.vars.renderSettings, 0)
    );
    if (this.toNumber(this.itemOf(this.stage.vars.renderSettings, 35)) === 1) {
      this.stage.vars.updateNeeded = 1;
    }
    if (this.toNumber(this.itemOf(this.stage.vars.renderSettings, 14)) === 1) {
      yield* this.createStars(this.itemOf(this.stage.vars.renderSettings, 15));
      yield* this.updateStarPositions(
        this.itemOf(this.stage.vars.renderSettings, 0)
      );
    }
  }

  *whenIReceiveSystemRenderTick() {
    yield* this.update();
  }

  *whenbackdropswitchesto() {
    this.vars.PointDataTransformedX = [];
    this.vars.PointDataTransformedY = [];
    this.vars.PointDataTransformedZ = [];
    this.vars.FakeSurfacesP1 = [];
    this.vars.FakeSurfacesP2 = [];
    this.vars.FakeSurfacesP3 = [];
    this.vars.SurfaceSortId = [];
    this.vars.SurfaceSortDist = [];
    this.vars.ScreenPointsX = [];
    this.vars.ScreenPointsY = [];
    this.vars.StarsX = [];
    this.vars.StarsY = [];
    this.vars.StarsZ = [];
    this.vars.ScreenStarsX = [];
    this.vars.ScreenStarsY = [];
    this.vars.FakeSurfacesTexture = [];
    this.vars.ShadowsX = [];
    this.vars.ShadowsY = [];
    this.vars.ShadowsZ = [];
    this.vars.FakeSurfacesN0 = [];
    this.vars.FakeSurfacesN1 = [];
    this.vars.FakeSurfacesN2 = [];
    this.vars.FakeSurfacesLightSource = [];
    this.vars.FakeSurfacesP4 = [];
    this.vars.FakeSurfacesType = [];
    this.vars.FakeSurfacesDiameter = [];
  }

  *update() {
    if (this.toNumber(this.stage.vars.updateNeeded) === 1) {
      yield* this.createWorldViewTransformation();
      yield* this.updatePointsAndLoadSurfaces(
        this.itemOf(this.stage.vars.renderSettings, 0)
      );
      if (
        this.toNumber(this.itemOf(this.stage.vars.renderSettings, 14)) === 1 &&
        this.compare(this.vars.Night, 0.49) > 0
      ) {
        yield* this.updateStarPositions(
          this.itemOf(this.stage.vars.renderSettings, 0)
        );
      }
      this.clearPen();
      yield* this.drawBackground(
        this.itemOf(this.stage.vars.renderSettings, 0)
      );
      if (
        this.toNumber(this.itemOf(this.stage.vars.renderSettings, 9)) === 1 &&
        this.toNumber(this.itemOf(this.stage.vars.renderSettings, 13)) === 1
      ) {
        yield* this.drawShadows(
          this.itemOf(this.stage.vars.renderSettings, 0),
          this.itemOf(this.stage.vars.renderSettings, 10)
        );
      }
      yield* this.drawSurfaces();
    } else {
      if (
        this.toNumber(this.itemOf(this.stage.vars.renderSettings, 35)) === 0
      ) {
        this.clearPen();
        yield* this.drawBackground(
          this.itemOf(this.stage.vars.renderSettings, 0)
        );
        if (
          this.toNumber(this.itemOf(this.stage.vars.renderSettings, 9)) === 1 &&
          this.toNumber(this.itemOf(this.stage.vars.renderSettings, 13)) === 1
        ) {
          yield* this.drawShadows(
            this.itemOf(this.stage.vars.renderSettings, 0),
            this.itemOf(this.stage.vars.renderSettings, 10)
          );
        }
        yield* this.drawSurfaces();
      }
    }
  }

  *drawBackground(scale) {
    if (this.toNumber(this.itemOf(this.stage.vars.renderSettings, 12)) === 1) {
      this.vars.Night =
        0.5 - Math.sin(this.degToRad(this.toNumber(this.stage.vars.time))) / 2;
      this.vars.Temp1 = Math.floor(
        this.toNumber(this.itemOf(this.stage.vars.renderSettings, 19)) +
          this.toNumber(this.vars.Night) *
            this.toNumber(this.itemOf(this.stage.vars.renderSettings, 25))
      );
      this.vars.Temp2 = Math.floor(
        this.toNumber(this.itemOf(this.stage.vars.renderSettings, 20)) +
          this.toNumber(this.vars.Night) *
            this.toNumber(this.itemOf(this.stage.vars.renderSettings, 26))
      );
      this.vars.Temp3 = Math.floor(
        this.toNumber(this.itemOf(this.stage.vars.renderSettings, 21)) +
          this.toNumber(this.vars.Night) *
            this.toNumber(this.itemOf(this.stage.vars.renderSettings, 27))
      );
      this.penColor = Color.num(
        this.toNumber(this.vars.Temp1) * 65536 +
          this.toNumber(this.vars.Temp2) * 256 +
          this.toNumber(this.vars.Temp3)
      );
      this.penSize = 1;
      this.goto(-240, 90);
      this.penDown = true;
      this.penSize = 180;
      this.x = 240;
      this.penDown = false;
      if (
        this.toNumber(this.itemOf(this.stage.vars.renderSettings, 13)) === 1
      ) {
        this.vars.Temp1 =
          180 -
          this.toNumber(scale) *
            this.scratchTan(this.toNumber(this.stage.vars.cameraRotY));
        if (this.compare(this.vars.Temp1, 360) > 0) {
          this.vars.Temp1 = 360;
        }
        yield* this.drawGround(this.vars.Temp1, scale);
      } else {
        this.penSize = 1;
        this.goto(-240, -90);
        this.penDown = true;
        this.penSize = 180;
        this.x = 240;
        this.penDown = false;
        if (
          this.toNumber(this.itemOf(this.stage.vars.renderSettings, 14)) === 1
        ) {
          yield* this.drawStars();
          yield* this.drawSunAndMoon(scale);
        }
      }
    }
  }

  *drawGround(horizon, scale) {
    if (this.compare(horizon, 180) < 0) {
      this.penSize = 1;
      this.goto(-240, -90);
      this.penDown = true;
      this.penSize = 180;
      this.x = 240;
      this.penDown = false;
    }
    if (this.toNumber(this.itemOf(this.stage.vars.renderSettings, 14)) === 1) {
      yield* this.drawStars();
      yield* this.drawSunAndMoon(scale);
    }
    this.vars.Temp1 = 1 - this.toNumber(this.vars.Night) / 2;
    this.penColor = Color.num(
      Math.floor(
        this.toNumber(this.itemOf(this.stage.vars.renderSettings, 16)) *
          this.toNumber(this.vars.Temp1)
      ) *
        65536 +
        Math.floor(
          this.toNumber(this.itemOf(this.stage.vars.renderSettings, 17)) *
            this.toNumber(this.vars.Temp1)
        ) *
          256 +
        Math.floor(
          this.toNumber(this.itemOf(this.stage.vars.renderSettings, 18)) *
            this.toNumber(this.vars.Temp1)
        )
    );
    this.penSize = 1;
    if (this.compare(horizon, 180) > 0) {
      this.goto(-240, -90);
      this.penDown = true;
      this.penSize = 180;
      this.x = 240;
      this.penDown = false;
      this.penSize = 1;
      this.goto(-240, (this.toNumber(horizon) - 180) / 2);
      this.penDown = true;
      this.penSize = this.toNumber(horizon) - 179;
      this.x = 240;
      this.penDown = false;
    } else {
      this.goto(-240, -180 + this.toNumber(horizon) / 2);
      this.penDown = true;
      this.penSize = this.toNumber(horizon);
      this.x = 240;
      this.penDown = false;
    }
  }

  *drawSurfaces() {
    this.vars.Temp1 = this.vars.SurfaceSortId.length;
    for (let i = 0; i < this.toNumber(this.vars.Temp1); i++) {
      this.vars.Temp2 = this.itemOf(
        this.vars.SurfaceSortId,
        this.vars.Temp1 - 1
      );
      if (this.compare(this.vars.Temp2, 0) > 0) {
        this.vars.Temp3 = this.itemOf(
          this.stage.vars.surfacesType,
          this.vars.Temp2 - 1
        );
        if (this.toNumber(this.vars.Temp3) === 1) {
          yield* this.drawTriSurface(
            this.itemOf(this.stage.vars.surfacesP1, this.vars.Temp2 - 1),
            this.itemOf(this.stage.vars.surfacesP2, this.vars.Temp2 - 1),
            this.itemOf(this.stage.vars.surfacesP3, this.vars.Temp2 - 1),
            this.toNumber(
              this.itemOf(
                this.stage.vars.surfacesLightSource,
                this.vars.Temp2 - 1
              )
            ) + 1,
            this.itemOf(this.stage.vars.surfacesTexture, this.vars.Temp2 - 1),
            this.itemOf(this.stage.vars.surfacesN0, this.vars.Temp2 - 1),
            this.itemOf(this.stage.vars.surfacesN1, this.vars.Temp2 - 1),
            this.itemOf(this.stage.vars.surfacesN2, this.vars.Temp2 - 1)
          );
        } else {
          if (this.toNumber(this.vars.Temp3) === 3) {
            yield* this.drawLineSurface(
              this.itemOf(this.stage.vars.surfacesP1, this.vars.Temp2 - 1),
              this.itemOf(this.stage.vars.surfacesP2, this.vars.Temp2 - 1),
              this.itemOf(
                this.stage.vars.surfacesDiameter,
                this.vars.Temp2 - 1
              ),
              this.itemOf(this.stage.vars.surfacesTexture, this.vars.Temp2 - 1)
            );
          } else {
            if (this.toNumber(this.vars.Temp3) === 4) {
              yield* this.drawSphereSurface(
                this.itemOf(this.stage.vars.surfacesP1, this.vars.Temp2 - 1),
                this.itemOf(
                  this.stage.vars.surfacesDiameter,
                  this.vars.Temp2 - 1
                ),
                this.itemOf(
                  this.stage.vars.surfacesTexture,
                  this.vars.Temp2 - 1
                )
              );
            } else {
              null;
            }
          }
        }
      } else {
        this.vars.Temp2 = 0 - this.toNumber(this.vars.Temp2);
        this.vars.Temp3 = this.itemOf(
          this.vars.FakeSurfacesType,
          this.vars.Temp2 - 1
        );
        if (this.toNumber(this.vars.Temp3) === 1) {
          yield* this.drawTriSurface(
            this.itemOf(this.vars.FakeSurfacesP1, this.vars.Temp2 - 1),
            this.itemOf(this.vars.FakeSurfacesP2, this.vars.Temp2 - 1),
            this.itemOf(this.vars.FakeSurfacesP3, this.vars.Temp2 - 1),
            this.toNumber(
              this.itemOf(
                this.vars.FakeSurfacesLightSource,
                this.vars.Temp2 - 1
              )
            ) + 1,
            this.itemOf(this.vars.FakeSurfacesTexture, this.vars.Temp2 - 1),
            this.itemOf(this.vars.FakeSurfacesN0, this.vars.Temp2 - 1),
            this.itemOf(this.vars.FakeSurfacesN1, this.vars.Temp2 - 1),
            this.itemOf(this.vars.FakeSurfacesN2, this.vars.Temp2 - 1)
          );
        } else {
          if (this.toNumber(this.vars.Temp3) === 3) {
            yield* this.drawLineSurface(
              this.itemOf(this.vars.FakeSurfacesP1, this.vars.Temp2 - 1),
              this.itemOf(this.vars.FakeSurfacesP2, this.vars.Temp2 - 1),
              this.itemOf(this.vars.FakeSurfacesDiameter, this.vars.Temp2 - 1),
              this.itemOf(this.vars.FakeSurfacesTexture, this.vars.Temp2 - 1)
            );
          } else {
            null;
          }
        }
      }
      this.vars.Temp1--;
      yield;
    }
  }
}
