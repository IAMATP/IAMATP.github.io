/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Sounds extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("icon", "./Sounds/costumes/icon.svg", { x: 242, y: 175 }),
    ];

    this.sounds = [new Sound("Indo Rock", "./Sounds/sounds/Indo Rock.wav")];

    this.triggers = [
      new Trigger(
        Trigger.BROADCAST,
        { name: "System: Physics Tick" },
        this.whenIReceiveSystemPhysicsTick
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Init: Priority" },
        this.whenIReceiveInitPriority
      ),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(
        Trigger.BROADCAST,
        { name: "System: Render Tick" },
        this.whenIReceiveSystemRenderTick
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Init: Create Sounds" },
        this.whenIReceiveInitCreateSounds
      ),
    ];

    this.vars.IntCurrentSound = -1;
    this.vars.IntXDist = -60;
    this.vars.IntYDist = 70;
    this.vars.IntZDist = -670;
    this.vars.IntCurrentObject = 7;
    this.vars.IntCurrentSoundName = 0;
    this.vars.SoundsSound = [];
    this.vars.SoundsObject = [];
    this.vars.SoundsRadius = [];
    this.vars.SoundsMaxVolume = [];
  }

  *clearRepeatingSounds() {
    this.vars.SoundsSound = [];
    this.vars.SoundsObject = [];
    this.vars.SoundsRadius = [];
    this.vars.SoundsMaxVolume = [];
    this.stage.vars.soundsVolume = [];
    this.stage.vars.soundsHasClone = [];
  }

  *intUpdateSounds() {
    this.vars.IntCurrentSound = 1;
    for (let i = 0; i < this.stage.vars.soundsVolume.length; i++) {
      this.vars.IntCurrentObject = this.itemOf(
        this.vars.SoundsObject,
        this.vars.IntCurrentSound - 1
      );
      this.vars.IntXDist =
        this.toNumber(this.stage.vars.cameraX) -
        this.toNumber(
          this.itemOf(this.stage.vars.objectsX, this.vars.IntCurrentObject - 1)
        );
      this.vars.IntYDist =
        this.toNumber(this.stage.vars.cameraY) -
        this.toNumber(
          this.itemOf(this.stage.vars.objectsY, this.vars.IntCurrentObject - 1)
        );
      this.vars.IntZDist =
        this.toNumber(this.stage.vars.cameraZ) -
        this.toNumber(
          this.itemOf(this.stage.vars.objectsZ, this.vars.IntCurrentObject - 1)
        );
      this.stage.vars.soundsVolume.splice(
        this.vars.IntCurrentSound - 1,
        1,
        ((this.toNumber(
          this.itemOf(this.vars.SoundsRadius, this.vars.IntCurrentSound - 1)
        ) -
          Math.sqrt(
            this.toNumber(this.vars.IntXDist) *
              this.toNumber(this.vars.IntXDist) +
              this.toNumber(this.vars.IntYDist) *
                this.toNumber(this.vars.IntYDist) +
              this.toNumber(this.vars.IntZDist) *
                this.toNumber(this.vars.IntZDist)
          )) /
          this.toNumber(
            this.itemOf(this.vars.SoundsRadius, this.vars.IntCurrentSound - 1)
          )) *
          this.toNumber(
            this.itemOf(
              this.vars.SoundsMaxVolume,
              this.vars.IntCurrentSound - 1
            )
          )
      );
      if (
        this.compare(
          this.itemOf(
            this.stage.vars.soundsVolume,
            this.vars.IntCurrentSound - 1
          ),
          0
        ) > 0
      ) {
        if (
          this.toNumber(
            this.itemOf(
              this.stage.vars.soundsHasClone,
              this.vars.IntCurrentSound - 1
            )
          ) === 0
        ) {
          this.stage.vars.soundsHasClone.splice(
            this.vars.IntCurrentSound - 1,
            1,
            1
          );
          this.createClone();
        }
      } else {
        this.stage.vars.soundsHasClone.splice(
          this.vars.IntCurrentSound - 1,
          1,
          0
        );
      }
      this.vars.IntCurrentSound++;
      yield;
    }
    this.vars.IntCurrentSound = -1;
  }

  *whenIReceiveSystemPhysicsTick() {
    if (this.toNumber(this.vars.IntCurrentSound) === -1) {
      yield* this.intUpdateSounds();
    }
  }

  *whenIReceiveInitPriority() {
    this.vars.IntCurrentSound = -1;
  }

  *startAsClone() {
    this.vars.IntCurrentSoundName = this.itemOf(
      this.vars.SoundsSound,
      this.vars.IntCurrentSound - 1
    );
    this.vars.SoundsSound = [];
    this.vars.SoundsObject = [];
    this.vars.SoundsRadius = [];
    this.vars.SoundsMaxVolume = [];
    this.audioEffects.volume = this.toNumber(
      this.itemOf(this.stage.vars.soundsVolume, this.vars.IntCurrentSound - 1)
    );
    while (true) {
      yield* this.playSoundUntilDone(this.vars.IntCurrentSoundName);
      yield;
    }
  }

  *addRepeatingSoundToObjectWithRadiusMaxVolume(sound, object, radius, volume) {
    this.vars.SoundsSound.push(sound);
    this.vars.SoundsObject.push(object);
    this.vars.SoundsRadius.push(radius);
    this.vars.SoundsMaxVolume.push(volume);
    this.stage.vars.soundsVolume.push(0);
    this.stage.vars.soundsHasClone.push(0);
  }

  *whenIReceiveSystemRenderTick() {
    if (this.compare(this.vars.IntCurrentSound, -1) > 0) {
      if (
        this.toNumber(
          this.itemOf(
            this.stage.vars.soundsHasClone,
            this.vars.IntCurrentSound - 1
          )
        ) === 1
      ) {
        this.audioEffects.volume = this.toNumber(
          this.itemOf(
            this.stage.vars.soundsVolume,
            this.vars.IntCurrentSound - 1
          )
        );
      } else {
        this.deleteThisClone();
      }
    }
  }

  *whenIReceiveInitCreateSounds() {
    yield* this.clearRepeatingSounds();
    yield* this.addRepeatingSoundToObjectWithRadiusMaxVolume(
      "Indo Rock",
      7,
      200,
      100
    );
  }

  *whenbackdropswitchesto() {
    yield* this.clearRepeatingSounds();
  }

  *deleteLastSound() {
    this.vars.SoundsSound.splice(this.vars.SoundsSound.length - 1, 1);
    this.vars.SoundsObject.splice(this.vars.SoundsObject.length - 1, 1);
    this.vars.SoundsRadius.splice(this.vars.SoundsRadius.length - 1, 1);
    this.vars.SoundsMaxVolume.splice(this.vars.SoundsMaxVolume.length - 1, 1);
    this.stage.vars.soundsVolume.splice(
      this.stage.vars.soundsVolume.length - 1,
      1
    );
    this.stage.vars.soundsHasClone.splice(
      this.stage.vars.soundsHasClone.length - 1,
      1
    );
  }
}
