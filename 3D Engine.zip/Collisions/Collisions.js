/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Collisions extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("icon", "./Collisions/costumes/icon.svg", { x: 242, y: 175 }),
    ];

    this.sounds = [];

    this.triggers = [
      new Trigger(
        Trigger.BROADCAST,
        { name: "Init: Create Collisions" },
        this.whenIReceiveInitCreateCollisions
      ),
    ];

    this.vars.CurrentSurface = 119;
    this.vars.CurrentSurfaceType = 4;
    this.vars.CurrentPoint = 0;
    this.vars.XMin = -50;
    this.vars.XMax = -50;
    this.vars.YMin = 0;
    this.vars.YMax = 100;
    this.vars.ZMin = -50;
    this.vars.ZMax = 50;
    this.vars.NumPoints = 3;
    this.vars.PointX = 35.355339060000006;
    this.vars.PointY = -35.355339060000006;
    this.vars.PointZ = 0;
    this.vars.Object = 18;
    this.vars.Min = -50;
    this.vars.Max = 50;
    this.vars.Distance = 50.00000000095124;
    this.vars.Matrix = [
      0.7071067812, -0.7071067812, 0, 160, 0.7071067812, 0.7071067812, 0, 100,
      0, 0, 1, 350,
    ];
  }

  *whenIReceiveInitCreateCollisions() {
    yield* this.clearCollisions();
    yield* this.addCollisionBoxX1Y1Z1X2Y2Z2Padding(
      -1000000,
      -30,
      -1000000,
      1000000,
      0,
      1000000,
      0
    );
    yield* this.addCollisionBoxXYZWidthHeightDepthPadding(
      -260,
      0,
      0,
      120,
      620,
      120,
      15
    );
    yield* this.addCollisionBoxXYZWidthHeightDepthPadding(
      240,
      0,
      0,
      90,
      170,
      0,
      15
    );
    yield* this.addCollisionBoxXYZWidthHeightDepthPadding(
      -140,
      0,
      0,
      380,
      200,
      0,
      15
    );
    yield* this.addCollisionBoxXYZWidthHeightDepthPadding(
      330,
      0,
      0,
      30,
      200,
      0,
      15
    );
    yield* this.addCollisionBoxXYZWidthHeightDepthPadding(
      360,
      0,
      0,
      0,
      200,
      300,
      15
    );
    yield* this.addCollisionBoxXYZWidthHeightDepthPadding(
      -140,
      0,
      0,
      0,
      200,
      300,
      15
    );
    yield* this.addCollisionBoxXYZWidthHeightDepthPadding(
      -140,
      0,
      300,
      500,
      200,
      0,
      15
    );
    yield* this.addCollisionBoxXYZWidthHeightDepthPadding(
      -140,
      200,
      0,
      500,
      0,
      300,
      15
    );
    yield* this.addCollisionBoxXYZWidthHeightDepthPadding(
      30,
      40,
      100,
      140,
      10,
      100,
      0
    );
    yield* this.addCollisionBoxXYZWidthHeightDepthPadding(
      25,
      0,
      95,
      10,
      50,
      10,
      0
    );
    yield* this.addCollisionBoxXYZWidthHeightDepthPadding(
      165,
      0,
      95,
      10,
      50,
      10,
      0
    );
    yield* this.addCollisionBoxXYZWidthHeightDepthPadding(
      25,
      0,
      195,
      10,
      50,
      10,
      0
    );
    yield* this.addCollisionBoxXYZWidthHeightDepthPadding(
      165,
      0,
      195,
      10,
      50,
      10,
      0
    );
    yield* this.addRotatedCollisionBoxCentreXYZRotXRotYRotZWidthHeightDepthPadding(
      160,
      100,
      350,
      0,
      0,
      45,
      283,
      20,
      100,
      15
    );
    yield* this.addCollisionBoxXYZWidthHeightDepthPadding(
      260,
      200,
      300,
      100,
      0,
      100,
      15
    );
    this.vars.Object = 8;
    for (let i = 0; i < this.stage.vars.objectsX.length - 7; i++) {
      yield* this.estimateCollisionsForObjectPadding(this.vars.Object, 15);
      this.vars.Object++;
      yield;
    }
  }

  *addRotatedCollisionBoxCentreXYZRotXRotYRotZWidthHeightDepthPadding(
    x,
    y,
    z,
    rotX,
    rotY,
    rotZ,
    width,
    height,
    depth,
    padding
  ) {
    yield* this.intCreateObjectWorldTransformation(
      x,
      y,
      z,
      Math.sin(this.degToRad(this.toNumber(rotX))),
      Math.cos(this.degToRad(this.toNumber(rotX))),
      Math.sin(this.degToRad(this.toNumber(rotY))),
      Math.cos(this.degToRad(this.toNumber(rotY))),
      Math.sin(this.degToRad(this.toNumber(rotZ))),
      Math.cos(this.degToRad(this.toNumber(rotZ)))
    );
    this.vars.CurrentPoint = this.stage.vars.collisionBoxesRXData.length;
    yield* this.intAddRotatedCollisionBox(
      this.toNumber(width) / 2 + this.toNumber(padding),
      this.toNumber(height) / 2 + this.toNumber(padding),
      this.toNumber(depth) / 2 + this.toNumber(padding)
    );
    yield* this.intGetVector(
      this.itemOf(
        this.stage.vars.collisionBoxesRXData,
        this.toNumber(this.vars.CurrentPoint)
      ),
      this.itemOf(
        this.stage.vars.collisionBoxesRYData,
        this.toNumber(this.vars.CurrentPoint)
      ),
      this.itemOf(
        this.stage.vars.collisionBoxesRZData,
        this.toNumber(this.vars.CurrentPoint)
      ),
      this.itemOf(
        this.stage.vars.collisionBoxesRXData,
        this.toNumber(this.vars.CurrentPoint) + 1
      ),
      this.itemOf(
        this.stage.vars.collisionBoxesRYData,
        this.toNumber(this.vars.CurrentPoint) + 1
      ),
      this.itemOf(
        this.stage.vars.collisionBoxesRZData,
        this.toNumber(this.vars.CurrentPoint) + 1
      )
    );
    yield* this.intGetVector(
      this.itemOf(
        this.stage.vars.collisionBoxesRXData,
        this.toNumber(this.vars.CurrentPoint) + 1
      ),
      this.itemOf(
        this.stage.vars.collisionBoxesRYData,
        this.toNumber(this.vars.CurrentPoint) + 1
      ),
      this.itemOf(
        this.stage.vars.collisionBoxesRZData,
        this.toNumber(this.vars.CurrentPoint) + 1
      ),
      this.itemOf(
        this.stage.vars.collisionBoxesRXData,
        this.toNumber(this.vars.CurrentPoint) + 2
      ),
      this.itemOf(
        this.stage.vars.collisionBoxesRYData,
        this.toNumber(this.vars.CurrentPoint) + 2
      ),
      this.itemOf(
        this.stage.vars.collisionBoxesRZData,
        this.toNumber(this.vars.CurrentPoint) + 2
      )
    );
    yield* this.intGetVector(
      this.itemOf(
        this.stage.vars.collisionBoxesRXData,
        this.toNumber(this.vars.CurrentPoint) + 3
      ),
      this.itemOf(
        this.stage.vars.collisionBoxesRYData,
        this.toNumber(this.vars.CurrentPoint) + 3
      ),
      this.itemOf(
        this.stage.vars.collisionBoxesRZData,
        this.toNumber(this.vars.CurrentPoint) + 3
      ),
      this.itemOf(
        this.stage.vars.collisionBoxesRXData,
        this.toNumber(this.vars.CurrentPoint) + 4
      ),
      this.itemOf(
        this.stage.vars.collisionBoxesRYData,
        this.toNumber(this.vars.CurrentPoint) + 4
      ),
      this.itemOf(
        this.stage.vars.collisionBoxesRZData,
        this.toNumber(this.vars.CurrentPoint) + 4
      )
    );
  }

  *intAddRotatedCollisionBox(width2, height2, depth2) {
    yield* this.intTransformVertex(
      0 - this.toNumber(width2),
      height2,
      0 - this.toNumber(depth2)
    );
    yield* this.intTransformVertex(width2, height2, 0 - this.toNumber(depth2));
    yield* this.intTransformVertex(width2, height2, depth2);
    yield* this.intTransformVertex(0 - this.toNumber(width2), height2, depth2);
    yield* this.intTransformVertex(
      0 - this.toNumber(width2),
      0 - this.toNumber(height2),
      depth2
    );
    yield* this.intTransformVertex(
      0 - this.toNumber(width2),
      0 - this.toNumber(height2),
      0 - this.toNumber(depth2)
    );
    yield* this.intTransformVertex(
      width2,
      0 - this.toNumber(height2),
      0 - this.toNumber(depth2)
    );
    yield* this.intTransformVertex(width2, 0 - this.toNumber(height2), depth2);
  }

  *intCreateObjectWorldTransformation(
    x,
    y,
    z,
    sinRotX,
    cosRotX,
    sinRotY,
    cosRotY,
    sinRotZ,
    cosRotZ
  ) {
    this.vars.Matrix = [];
    this.vars.Matrix.push(
      this.toNumber(cosRotX) * this.toNumber(cosRotZ) -
        this.toNumber(sinRotX) * this.toNumber(sinRotY) * this.toNumber(sinRotZ)
    );
    this.vars.Matrix.push(0 - this.toNumber(cosRotY) * this.toNumber(sinRotZ));
    this.vars.Matrix.push(
      this.toNumber(sinRotX) * this.toNumber(cosRotZ) +
        this.toNumber(cosRotX) *
          (this.toNumber(sinRotY) * this.toNumber(sinRotZ))
    );
    this.vars.Matrix.push(x);
    this.vars.Matrix.push(
      this.toNumber(cosRotX) * this.toNumber(sinRotZ) +
        this.toNumber(sinRotX) * this.toNumber(sinRotY) * this.toNumber(cosRotZ)
    );
    this.vars.Matrix.push(this.toNumber(cosRotY) * this.toNumber(cosRotZ));
    this.vars.Matrix.push(
      this.toNumber(sinRotX) * this.toNumber(sinRotZ) -
        this.toNumber(cosRotX) * this.toNumber(sinRotY) * this.toNumber(cosRotZ)
    );
    this.vars.Matrix.push(y);
    this.vars.Matrix.push(0 - this.toNumber(sinRotX) * this.toNumber(cosRotY));
    this.vars.Matrix.push(sinRotY);
    this.vars.Matrix.push(this.toNumber(cosRotX) * this.toNumber(cosRotY));
    this.vars.Matrix.push(z);
  }

  *intTransformVertex(x, y, z) {
    this.stage.vars.collisionBoxesRXData.push(
      this.toNumber(this.itemOf(this.vars.Matrix, 0)) * this.toNumber(x) +
        this.toNumber(this.itemOf(this.vars.Matrix, 1)) * this.toNumber(y) +
        (this.toNumber(this.itemOf(this.vars.Matrix, 2)) * this.toNumber(z) +
          this.toNumber(this.itemOf(this.vars.Matrix, 3)))
    );
    this.stage.vars.collisionBoxesRYData.push(
      this.toNumber(this.itemOf(this.vars.Matrix, 4)) * this.toNumber(x) +
        this.toNumber(this.itemOf(this.vars.Matrix, 5)) * this.toNumber(y) +
        (this.toNumber(this.itemOf(this.vars.Matrix, 6)) * this.toNumber(z) +
          this.toNumber(this.itemOf(this.vars.Matrix, 7)))
    );
    this.stage.vars.collisionBoxesRZData.push(
      this.toNumber(this.itemOf(this.vars.Matrix, 8)) * this.toNumber(x) +
        this.toNumber(this.itemOf(this.vars.Matrix, 9)) * this.toNumber(y) +
        (this.toNumber(this.itemOf(this.vars.Matrix, 10)) * this.toNumber(z) +
          this.toNumber(this.itemOf(this.vars.Matrix, 11)))
    );
  }

  *intGetVector(x0, y0, z0, x1, y1, z1) {
    this.vars.PointX = this.toNumber(x1) - this.toNumber(x0);
    this.vars.PointY = this.toNumber(y1) - this.toNumber(y0);
    this.vars.PointZ = this.toNumber(z1) - this.toNumber(z0);
    this.vars.Distance = Math.sqrt(
      this.toNumber(this.vars.PointX) * this.toNumber(this.vars.PointX) +
        (this.toNumber(this.vars.PointY) * this.toNumber(this.vars.PointY) +
          this.toNumber(this.vars.PointZ) * this.toNumber(this.vars.PointZ))
    );
    this.stage.vars.collisionBoxesRN0.push(
      this.toNumber(this.vars.PointX) / this.toNumber(this.vars.Distance)
    );
    this.stage.vars.collisionBoxesRN1.push(
      this.toNumber(this.vars.PointY) / this.toNumber(this.vars.Distance)
    );
    this.stage.vars.collisionBoxesRN2.push(
      this.toNumber(this.vars.PointZ) / this.toNumber(this.vars.Distance)
    );
  }

  *clearCollisions() {
    this.stage.vars.collisionBoxesX1 = [];
    this.stage.vars.collisionBoxesY1 = [];
    this.stage.vars.collisionBoxesZ1 = [];
    this.stage.vars.collisionBoxesX2 = [];
    this.stage.vars.collisionBoxesY2 = [];
    this.stage.vars.collisionBoxesZ2 = [];
    this.stage.vars.collisionBoxesRXData = [];
    this.stage.vars.collisionBoxesRYData = [];
    this.stage.vars.collisionBoxesRZData = [];
    this.stage.vars.collisionBoxesRN0 = [];
    this.stage.vars.collisionBoxesRN1 = [];
    this.stage.vars.collisionBoxesRN2 = [];
    this.stage.vars.collisionSpheresX = [];
    this.stage.vars.collisionSpheresY = [];
    this.stage.vars.collisionSpheresZ = [];
    this.stage.vars.collisionSpheresRadius = [];
  }

  *addCollisionSphereXYZRadiusPadding(x, y, z, radius, padding) {
    this.stage.vars.collisionSpheresX.push(x);
    this.stage.vars.collisionSpheresY.push(y);
    this.stage.vars.collisionSpheresZ.push(z);
    this.stage.vars.collisionSpheresRadius.push(
      this.toNumber(radius) + this.toNumber(padding)
    );
  }

  *addCollisionBoxXYZWidthHeightDepthPadding(
    x,
    y,
    z,
    width,
    height,
    depth,
    padding
  ) {
    if (this.compare(width, 0) < 0) {
      yield* this.addCollisionBoxXYZWidthHeightDepthPadding(
        this.toNumber(x) + this.toNumber(width),
        y,
        z,
        Math.abs(this.toNumber(width)),
        height,
        depth,
        padding
      );
    } else {
      if (this.compare(height, 0) < 0) {
        yield* this.addCollisionBoxXYZWidthHeightDepthPadding(
          x,
          this.toNumber(y) + this.toNumber(height),
          z,
          width,
          Math.abs(this.toNumber(height)),
          depth,
          padding
        );
      } else {
        if (this.compare(depth, 0) < 0) {
          yield* this.addCollisionBoxXYZWidthHeightDepthPadding(
            x,
            y,
            this.toNumber(z) + this.toNumber(depth),
            width,
            height,
            Math.abs(this.toNumber(depth)),
            padding
          );
        } else {
          this.stage.vars.collisionBoxesX1.push(
            this.toNumber(x) - this.toNumber(padding)
          );
          this.stage.vars.collisionBoxesY1.push(
            this.toNumber(y) - this.toNumber(padding)
          );
          this.stage.vars.collisionBoxesZ1.push(
            this.toNumber(z) - this.toNumber(padding)
          );
          this.stage.vars.collisionBoxesX2.push(
            this.toNumber(x) + this.toNumber(width) + this.toNumber(padding)
          );
          this.stage.vars.collisionBoxesY2.push(
            this.toNumber(y) + this.toNumber(height) + this.toNumber(padding)
          );
          this.stage.vars.collisionBoxesZ2.push(
            this.toNumber(z) + this.toNumber(depth) + this.toNumber(padding)
          );
        }
      }
    }
  }

  *addCollisionBoxX1Y1Z1X2Y2Z2Padding(x1, y1, z1, x2, y2, z2, padding) {
    this.stage.vars.collisionBoxesX1.push(
      this.toNumber(x1) - this.toNumber(padding)
    );
    this.stage.vars.collisionBoxesY1.push(
      this.toNumber(y1) - this.toNumber(padding)
    );
    this.stage.vars.collisionBoxesZ1.push(
      this.toNumber(z1) - this.toNumber(padding)
    );
    this.stage.vars.collisionBoxesX2.push(
      this.toNumber(x2) + this.toNumber(padding)
    );
    this.stage.vars.collisionBoxesY2.push(
      this.toNumber(y2) + this.toNumber(padding)
    );
    this.stage.vars.collisionBoxesZ2.push(
      this.toNumber(z2) + this.toNumber(padding)
    );
  }

  *addCollisionBoxSafeX1Y1Z1X2Y2Z2Padding(x1, y1, z1, x2, y2, z2, padding) {
    if (this.compare(x1, x2) < 0) {
      if (this.compare(y1, y2) < 0) {
        if (this.compare(z1, z2) < 0) {
          yield* this.addCollisionBoxX1Y1Z1X2Y2Z2Padding(
            x1,
            y1,
            z1,
            x2,
            y2,
            z2,
            padding
          );
        } else {
          yield* this.addCollisionBoxX1Y1Z1X2Y2Z2Padding(
            x1,
            y1,
            z2,
            x2,
            y2,
            z1,
            padding
          );
        }
      } else {
        if (this.compare(z1, z2) < 0) {
          yield* this.addCollisionBoxX1Y1Z1X2Y2Z2Padding(
            x1,
            y2,
            z1,
            x2,
            y1,
            z2,
            padding
          );
        } else {
          yield* this.addCollisionBoxX1Y1Z1X2Y2Z2Padding(
            x1,
            y2,
            z2,
            x2,
            y1,
            z1,
            padding
          );
        }
      }
    } else {
      if (this.compare(y1, y2) < 0) {
        if (this.compare(z1, z2) < 0) {
          yield* this.addCollisionBoxX1Y1Z1X2Y2Z2Padding(
            x2,
            y1,
            z1,
            x1,
            y2,
            z2,
            padding
          );
        } else {
          yield* this.addCollisionBoxX1Y1Z1X2Y2Z2Padding(
            x2,
            y1,
            z2,
            x1,
            y2,
            z1,
            padding
          );
        }
      } else {
        if (this.compare(z1, z2) < 0) {
          yield* this.addCollisionBoxX1Y1Z1X2Y2Z2Padding(
            x2,
            y2,
            z1,
            x1,
            y1,
            z2,
            padding
          );
        } else {
          yield* this.addCollisionBoxX1Y1Z1X2Y2Z2Padding(
            x2,
            y2,
            z2,
            x1,
            y1,
            z1,
            padding
          );
        }
      }
    }
  }

  *estimateCollisionsForObjectPadding(object, padding) {
    this.vars.CurrentSurface = this.itemOf(
      this.stage.vars.objectsSurfacesIndex,
      object - 1
    );
    for (
      let i = 0;
      i <
      this.toNumber(this.itemOf(this.stage.vars.objectsSurfaces, object - 1));
      i++
    ) {
      this.vars.CurrentSurfaceType = this.itemOf(
        this.stage.vars.surfacesType,
        this.vars.CurrentSurface - 1
      );
      if (this.toNumber(this.vars.CurrentSurfaceType) === 1) {
        yield* this.intEstimateTriangleCollision(
          this.itemOf(this.stage.vars.surfacesP1, this.vars.CurrentSurface - 1),
          this.itemOf(this.stage.vars.surfacesP2, this.vars.CurrentSurface - 1),
          this.itemOf(this.stage.vars.surfacesP3, this.vars.CurrentSurface - 1),
          padding
        );
      } else {
        if (this.toNumber(this.vars.CurrentSurfaceType) === 3) {
          yield* this.intEstimateLineCollision(
            this.itemOf(
              this.stage.vars.surfacesP1,
              this.vars.CurrentSurface - 1
            ),
            this.itemOf(
              this.stage.vars.surfacesP2,
              this.vars.CurrentSurface - 1
            ),
            this.toNumber(
              this.itemOf(
                this.stage.vars.surfacesDiameter,
                this.vars.CurrentSurface - 1
              )
            ) / 2,
            padding
          );
        } else {
          if (this.toNumber(this.vars.CurrentSurfaceType) === 4) {
            yield* this.intEstimateSphereCollision(
              this.itemOf(
                this.stage.vars.surfacesP1,
                this.vars.CurrentSurface - 1
              ),
              this.toNumber(
                this.itemOf(
                  this.stage.vars.surfacesDiameter,
                  this.vars.CurrentSurface - 1
                )
              ) / 2,
              padding
            );
          } else {
            null;
          }
        }
      }
      this.vars.CurrentSurface++;
      yield;
    }
  }

  *intEstimateTriangleCollision(p1, p2, p3, padding) {
    yield* this.int2EstimateTriangleCollision(
      this.itemOf(this.stage.vars.worldDataX, p1 - 1),
      this.itemOf(this.stage.vars.worldDataY, p1 - 1),
      this.itemOf(this.stage.vars.worldDataZ, p1 - 1),
      this.itemOf(this.stage.vars.worldDataX, p2 - 1),
      this.itemOf(this.stage.vars.worldDataY, p2 - 1),
      this.itemOf(this.stage.vars.worldDataZ, p2 - 1),
      this.itemOf(this.stage.vars.worldDataX, p3 - 1),
      this.itemOf(this.stage.vars.worldDataY, p3 - 1),
      this.itemOf(this.stage.vars.worldDataZ, p3 - 1),
      padding
    );
  }

  *int2EstimateTriangleCollision(x1, y1, z1, x2, y2, z2, x3, y3, z3, padding) {
    yield* this.intGetMinAndMax(x1, x2, x3);
    this.vars.XMin = this.vars.Min;
    this.vars.XMax = this.vars.Max;
    yield* this.intGetMinAndMax(y1, y2, y3);
    this.vars.YMin = this.vars.Min;
    this.vars.YMax = this.vars.Max;
    yield* this.intGetMinAndMax(z1, z2, z3);
    this.vars.ZMin = this.vars.Min;
    this.vars.ZMax = this.vars.Max;
    yield* this.addCollisionBoxX1Y1Z1X2Y2Z2Padding(
      this.vars.XMin,
      this.vars.YMin,
      this.vars.ZMin,
      this.vars.XMax,
      this.vars.YMax,
      this.vars.ZMax,
      padding
    );
  }

  *intGetMinAndMax(a, b, c) {
    if (this.compare(a, b) < 0) {
      if (this.compare(a, c) < 0) {
        this.vars.Min = a;
        if (this.compare(b, c) > 0) {
          this.vars.Max = b;
        } else {
          this.vars.Max = c;
        }
      } else {
        this.vars.Min = c;
        if (this.compare(b, a) > 0) {
          this.vars.Max = b;
        } else {
          this.vars.Max = a;
        }
      }
    } else {
      if (this.compare(b, c) < 0) {
        this.vars.Min = b;
        if (this.compare(a, c) > 0) {
          this.vars.Max = a;
        } else {
          this.vars.Max = c;
        }
      } else {
        this.vars.Min = c;
        if (this.compare(b, a) > 0) {
          this.vars.Max = b;
        } else {
          this.vars.Max = a;
        }
      }
    }
  }

  *intEstimateLineCollision(p1, p2, width, padding) {
    if (this.compare(width, 0) > 0) {
      yield* this.int2EstimateLineCollision(
        this.itemOf(this.stage.vars.worldDataX, p1 - 1),
        this.itemOf(this.stage.vars.worldDataY, p1 - 1),
        this.itemOf(this.stage.vars.worldDataZ, p1 - 1),
        this.itemOf(this.stage.vars.worldDataX, p2 - 1),
        this.itemOf(this.stage.vars.worldDataY, p2 - 1),
        this.itemOf(this.stage.vars.worldDataZ, p2 - 1),
        width,
        padding
      );
    }
  }

  *int2EstimateLineCollision(x1, y1, z1, x2, y2, z2, width, padding) {
    if (this.compare(x1, x2) < 0) {
      if (this.compare(y1, y2) < 0) {
        if (this.compare(z1, z2) < 0) {
          yield* this.int3EstimateLineCollision(
            x1,
            y1,
            z1,
            x2,
            y2,
            z2,
            width,
            padding
          );
        } else {
          yield* this.int3EstimateLineCollision(
            x1,
            y1,
            z2,
            x2,
            y2,
            z1,
            width,
            padding
          );
        }
      } else {
        if (this.compare(z1, z2) < 0) {
          yield* this.int3EstimateLineCollision(
            x1,
            y2,
            z1,
            x2,
            y1,
            z2,
            width,
            padding
          );
        } else {
          yield* this.int3EstimateLineCollision(
            x1,
            y2,
            z2,
            x2,
            y1,
            z1,
            width,
            padding
          );
        }
      }
    } else {
      if (this.compare(y1, y2) < 0) {
        if (this.compare(z1, z2) < 0) {
          yield* this.int3EstimateLineCollision(
            x2,
            y1,
            z1,
            x1,
            y2,
            z2,
            width,
            padding
          );
        } else {
          yield* this.int3EstimateLineCollision(
            x2,
            y1,
            z2,
            x1,
            y2,
            z1,
            width,
            padding
          );
        }
      } else {
        if (this.compare(z1, z2) < 0) {
          yield* this.int3EstimateLineCollision(
            x2,
            y2,
            z1,
            x1,
            y1,
            z2,
            width,
            padding
          );
        } else {
          yield* this.int3EstimateLineCollision(
            x2,
            y2,
            z2,
            x1,
            y1,
            z1,
            width,
            padding
          );
        }
      }
    }
  }

  *int3EstimateLineCollision(x1, y1, z1, x2, y2, z2, width, padding) {
    yield* this.addCollisionBoxX1Y1Z1X2Y2Z2Padding(
      this.toNumber(x1) - this.toNumber(width),
      this.toNumber(y1) - this.toNumber(width),
      this.toNumber(z1) - this.toNumber(width),
      this.toNumber(x2) + this.toNumber(width),
      this.toNumber(y2) + this.toNumber(width),
      this.toNumber(z2) + this.toNumber(width),
      padding
    );
  }

  *intEstimateSphereCollision(origin, radius, padding) {
    yield* this.addCollisionSphereXYZRadiusPadding(
      this.itemOf(this.stage.vars.worldDataX, origin - 1),
      this.itemOf(this.stage.vars.worldDataY, origin - 1),
      this.itemOf(this.stage.vars.worldDataZ, origin - 1),
      radius,
      padding
    );
  }

  *estimateSingleCollisionBoxForObjectPadding(object, padding) {
    this.vars.NumPoints =
      this.toNumber(
        this.itemOf(this.stage.vars.objectsPointsIndex, this.toNumber(object))
      ) -
      this.toNumber(
        this.itemOf(this.stage.vars.objectsPointsIndex, object - 1)
      );
    if (this.compare(this.vars.NumPoints, 0) > 0) {
      this.vars.CurrentPoint =
        this.toNumber(
          this.itemOf(this.stage.vars.objectsPointsIndex, object - 1)
        ) + 1;
      this.vars.XMin = this.itemOf(
        this.stage.vars.worldDataX,
        this.vars.CurrentPoint - 1
      );
      this.vars.XMax = this.itemOf(
        this.stage.vars.worldDataX,
        this.vars.CurrentPoint - 1
      );
      this.vars.YMin = this.itemOf(
        this.stage.vars.worldDataY,
        this.vars.CurrentPoint - 1
      );
      this.vars.YMax = this.itemOf(
        this.stage.vars.worldDataY,
        this.vars.CurrentPoint - 1
      );
      this.vars.ZMin = this.itemOf(
        this.stage.vars.worldDataZ,
        this.vars.CurrentPoint - 1
      );
      this.vars.ZMax = this.itemOf(
        this.stage.vars.worldDataZ,
        this.vars.CurrentPoint - 1
      );
      for (let i = 0; i < this.toNumber(this.vars.NumPoints) - 1; i++) {
        this.vars.PointX = this.itemOf(
          this.stage.vars.worldDataX,
          this.vars.CurrentPoint - 1
        );
        this.vars.PointY = this.itemOf(
          this.stage.vars.worldDataY,
          this.vars.CurrentPoint - 1
        );
        this.vars.PointZ = this.itemOf(
          this.stage.vars.worldDataZ,
          this.vars.CurrentPoint - 1
        );
        if (this.compare(this.vars.PointX, this.vars.XMin) < 0) {
          this.vars.XMin = this.vars.PointX;
        }
        if (this.compare(this.vars.PointX, this.vars.XMax) > 0) {
          this.vars.XMax = this.vars.PointX;
        }
        if (this.compare(this.vars.PointY, this.vars.YMin) < 0) {
          this.vars.YMin = this.vars.PointY;
        }
        if (this.compare(this.vars.PointY, this.vars.YMax) > 0) {
          this.vars.YMax = this.vars.PointY;
        }
        if (this.compare(this.vars.PointZ, this.vars.ZMin) < 0) {
          this.vars.ZMin = this.vars.PointZ;
        }
        if (this.compare(this.vars.PointZ, this.vars.ZMax) > 0) {
          this.vars.ZMax = this.vars.PointZ;
        }
        this.vars.CurrentPoint++;
        yield;
      }
      yield* this.addCollisionBoxX1Y1Z1X2Y2Z2Padding(
        this.vars.XMin,
        this.vars.YMin,
        this.vars.ZMin,
        this.vars.XMax,
        this.vars.YMax,
        this.vars.ZMax,
        padding
      );
    }
  }

  *whenbackdropswitchesto() {
    yield* this.clearCollisions();
  }
}
