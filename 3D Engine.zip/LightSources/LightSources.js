/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class LightSources extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("icon", "./LightSources/costumes/icon.svg", {
        x: 242,
        y: 175,
      }),
    ];

    this.sounds = [];

    this.triggers = [
      new Trigger(
        Trigger.BROADCAST,
        { name: "Init: Create Light Sources" },
        this.whenIReceiveInitCreateLightSources
      ),
    ];

    this.vars.Distance = 1;
  }

  *clearLightSources() {
    this.stage.vars.lightSourcesX = [];
    this.stage.vars.lightSourcesY = [];
    this.stage.vars.lightSourcesZ = [];
    this.stage.vars.lightSourcesContrib = [];
    this.stage.vars.lightSourcesX.push(0);
    this.stage.vars.lightSourcesY.push(0);
    this.stage.vars.lightSourcesZ.push(0);
    this.stage.vars.lightSourcesContrib.push(0);
  }

  *whenIReceiveInitCreateLightSources() {
    yield* this.clearLightSources();
    yield* this.addLightSourceDirectionXYZContribution(0, 0, 1, 1 / 12);
  }

  *addLightSourceDirectionXYZContribution(x, y, z, contrib) {
    this.vars.Distance = Math.sqrt(
      this.toNumber(x) * this.toNumber(x) +
        (this.toNumber(y) * this.toNumber(y) +
          this.toNumber(z) * this.toNumber(z))
    );
    this.stage.vars.lightSourcesX.push(
      this.toNumber(x) / this.toNumber(this.vars.Distance)
    );
    this.stage.vars.lightSourcesY.push(
      this.toNumber(y) / this.toNumber(this.vars.Distance)
    );
    this.stage.vars.lightSourcesZ.push(
      this.toNumber(z) / this.toNumber(this.vars.Distance)
    );
    this.stage.vars.lightSourcesContrib.push(contrib);
  }

  *whenbackdropswitchesto() {
    yield* this.clearLightSources();
  }
}
