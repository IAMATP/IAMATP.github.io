/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Camera extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("icon", "./Camera/costumes/icon.svg", { x: 184, y: 133 }),
    ];

    this.sounds = [
      new Sound("Grass Step 1", "./Camera/sounds/Grass Step 1.wav"),
      new Sound("Grass Step 2", "./Camera/sounds/Grass Step 2.wav"),
      new Sound("Grass Step 3", "./Camera/sounds/Grass Step 3.wav"),
      new Sound("Grass Step 4", "./Camera/sounds/Grass Step 4.wav"),
      new Sound("Metal Step 1", "./Camera/sounds/Metal Step 1.wav"),
      new Sound("Metal Step 2", "./Camera/sounds/Metal Step 2.wav"),
      new Sound("Metal Step 3", "./Camera/sounds/Metal Step 3.wav"),
      new Sound("Metal Step 4", "./Camera/sounds/Metal Step 4.wav"),
      new Sound("Concrete Step 1", "./Camera/sounds/Concrete Step 1.wav"),
      new Sound("Concrete Step 2", "./Camera/sounds/Concrete Step 2.wav"),
      new Sound("Concrete Step 3", "./Camera/sounds/Concrete Step 3.wav"),
      new Sound("Concrete Step 4", "./Camera/sounds/Concrete Step 4.wav"),
      new Sound("Carpet Step 1", "./Camera/sounds/Carpet Step 1.wav"),
      new Sound("Carpet Step 2", "./Camera/sounds/Carpet Step 2.wav"),
      new Sound("Carpet Step 3", "./Camera/sounds/Carpet Step 3.wav"),
      new Sound("Carpet Step 4", "./Camera/sounds/Carpet Step 4.wav"),
    ];

    this.triggers = [
      new Trigger(
        Trigger.BROADCAST,
        { name: "Init: Setup Camera" },
        this.whenIReceiveInitSetupCamera
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "System: Physics Tick" },
        this.whenIReceiveSystemPhysicsTick
      ),
    ];

    this.vars.ForwardsVel = 0;
    this.vars.SidewaysVel = 0;
    this.vars.VerticalVel = 0;
    this.vars.WalkFrame = 4386;
    this.vars.Jumping = 0;
    this.vars.CurrentBox = 2;
    this.vars.Return = 1;
    this.vars.CurrentCollision = true;
    this.vars.CharY = 0;
    this.vars.PlayerHeight = 120;
    this.vars.CrouchPressed = 0;
    this.vars.OldCameraRotX = 0;
    this.vars.OldCameraRotY = 0;
    this.vars.MouseDownX = 195;
    this.vars.MouseDownY = 180;
    this.vars.OldMouseDown = 0;
    this.vars.Acceleration = 100;
    this.vars.Temp1 = 9;
    this.vars.Temp2 = 288.3398807878;
    this.vars.Action = -1;
    this.vars.ActionStart = 17.491;
    this.vars.ConstPlayerFullHeight = 120;
    this.vars.ConstPlayerCrouchHeight = 30;
    this.vars.ConstPlayerFullAcceleration = 100;
    this.vars.ConstPlayerCrouchAcceleration = 20;
    this.vars.OldCharY = 5;
    this.vars.Min1 = 31.660119212199987;
    this.vars.Max1 = 288.3398807878;
    this.vars.Min2 = 27.347763105524983;
    this.vars.Max2 = 340.34776311147976;
    this.vars.NewX = 343.65143724298537;
    this.vars.NewZ = -308.9713782027164;
    this.vars.Increment = 14;
    this.vars.CurrentSurface = 119;
    this.vars.DistanceToFloor = 1000;
    this.vars.E10 = 5.916655663799986;
    this.vars.E11 = 0;
    this.vars.E12 = 12.688309017999984;
    this.vars.E20 = 33.10588927379999;
    this.vars.E21 = 0;
    this.vars.E22 = 0.009761166999965099;
    this.vars.Pvec0 = -0.009761166999965099;
    this.vars.Pvec1 = 0;
    this.vars.Pvec2 = 33.10588927379999;
    this.vars.Determiner = 419.99999995764966;
    this.vars.ConstEpsilon = 0;
    this.vars.InvertedDeterminer = 0.002380952381192462;
    this.vars.Tvec0 = 260.77690686097736;
    this.vars.Tvec1 = -60;
    this.vars.Tvec2 = -458.1625009470402;
    this.vars.U = -36.120053605303085;
    this.vars.Intersects = 0;
    this.vars.T = 15;
    this.vars.Qvec0 = 60000;
    this.vars.Qvec1 = -158816.50209804688;
    this.vars.Qvec2 = 100000;
    this.vars.FloorSurface = -1;
    this.vars.V = 1.0587766806536458;
    this.vars.OnGround = 1;
    this.vars.ConstPlayerJumpStartSpeed = 14;
    this.vars.ConstGravityStrength = 2;
    this.vars.ConstMouseSensitivity = 2;
    this.vars.ConstTerminalFallVelocity = -120;
    this.vars.ConstArrowsRotateSpeed = 90;
    this.vars.DistSquared = 10876698.661915202;
    this.vars.CurrentSphere = 11;
    this.vars.ConstGroundFirstStepSound = 1;
    this.vars.ConstGroundLastStepSound = 4;
  }

  *whenIReceiveInitSetupCamera() {
    yield* this.setCameraPosToXYZ(40, 120, -520);
    yield* this.setCameraDirectionToRotXRotY(0, 0);
    this.vars.ConstPlayerFullHeight = 120;
    this.vars.ConstPlayerCrouchHeight = 30;
    this.vars.ConstPlayerFullAcceleration = 100;
    this.vars.ConstPlayerCrouchAcceleration = 20;
    this.vars.ConstPlayerJumpStartSpeed = 14;
    this.vars.ConstGroundFirstStepSound = 1;
    this.vars.ConstGroundLastStepSound = 4;
    this.vars.ConstGravityStrength = 2;
    this.vars.ConstTerminalFallVelocity = -120;
    this.vars.ConstMouseSensitivity = 2;
    this.vars.ConstArrowsRotateSpeed = 90;
    yield* this.completeInit();
  }

  *setCameraPosToXYZ(x, y, z) {
    this.stage.vars.cameraX = x;
    this.stage.vars.cameraY = y;
    this.stage.vars.cameraZ = z;
  }

  *safeTestForCollisionIn(ax, bx, ay, by, az, bz) {
    if (this.compare(ax, bx) < 0) {
      if (this.compare(ay, by) < 0) {
        if (this.compare(az, bz) < 0) {
          yield* this.testForCollisionIn(ax, bx, ay, by, az, bz);
        } else {
          yield* this.testForCollisionIn(ax, bx, ay, by, bz, az);
        }
      } else {
        if (this.compare(az, bz) < 0) {
          yield* this.testForCollisionIn(ax, bx, by, ay, az, bz);
        } else {
          yield* this.testForCollisionIn(ax, bx, by, ay, bz, az);
        }
      }
    } else {
      if (this.compare(ay, by) < 0) {
        if (this.compare(az, bz) < 0) {
          yield* this.testForCollisionIn(bx, ax, ay, by, az, bz);
        } else {
          yield* this.testForCollisionIn(bx, ax, ay, by, bz, az);
        }
      } else {
        if (this.compare(az, bz) < 0) {
          yield* this.testForCollisionIn(bx, ax, by, ay, az, bz);
        } else {
          yield* this.testForCollisionIn(bx, ax, by, ay, bz, az);
        }
      }
    }
  }

  *setCameraDirectionToRotXRotY(rotX, rotY) {
    this.stage.vars.cameraRotX = rotX;
    this.stage.vars.cameraRotY = rotY;
  }

  *testForCollisionAtXYZ(x, y, z) {
    this.vars.Return = 0;
    this.vars.CurrentBox = 1;
    while (
      !(
        this.compare(
          this.vars.CurrentBox,
          this.stage.vars.collisionBoxesX1.length
        ) > 0 || this.toNumber(this.vars.Return) === 1
      )
    ) {
      yield* this.intCuboidContainsPoint(
        x,
        y,
        z,
        this.itemOf(this.stage.vars.collisionBoxesX1, this.vars.CurrentBox - 1),
        this.itemOf(this.stage.vars.collisionBoxesY1, this.vars.CurrentBox - 1),
        this.itemOf(this.stage.vars.collisionBoxesZ1, this.vars.CurrentBox - 1),
        this.itemOf(this.stage.vars.collisionBoxesX2, this.vars.CurrentBox - 1),
        this.itemOf(this.stage.vars.collisionBoxesY2, this.vars.CurrentBox - 1),
        this.itemOf(this.stage.vars.collisionBoxesZ2, this.vars.CurrentBox - 1)
      );
      if (this.compare(this.vars.CurrentCollision, 0 === "") === 0) {
        this.vars.Return = 1;
      }
      this.vars.CurrentBox++;
      yield;
    }
  }

  *getSurfaceBelow(maxDistance) {
    this.vars.DistanceToFloor = maxDistance;
    this.vars.FloorSurface = -1;
    this.vars.CurrentSurface = 1;
    for (let i = 0; i < this.stage.vars.surfacesP1.length; i++) {
      if (
        this.toNumber(
          this.itemOf(
            this.stage.vars.surfacesType,
            this.vars.CurrentSurface - 1
          )
        ) === 1
      ) {
        yield* this.intersectTriangle(
          this.stage.vars.cameraX,
          this.vars.CharY,
          this.stage.vars.cameraZ,
          0,
          -1,
          0,
          this.itemOf(
            this.stage.vars.worldDataX,
            this.itemOf(
              this.stage.vars.surfacesP1,
              this.vars.CurrentSurface - 1
            ) - 1
          ),
          this.itemOf(
            this.stage.vars.worldDataY,
            this.itemOf(
              this.stage.vars.surfacesP1,
              this.vars.CurrentSurface - 1
            ) - 1
          ),
          this.itemOf(
            this.stage.vars.worldDataZ,
            this.itemOf(
              this.stage.vars.surfacesP1,
              this.vars.CurrentSurface - 1
            ) - 1
          ),
          this.itemOf(
            this.stage.vars.worldDataX,
            this.itemOf(
              this.stage.vars.surfacesP2,
              this.vars.CurrentSurface - 1
            ) - 1
          ),
          this.itemOf(
            this.stage.vars.worldDataY,
            this.itemOf(
              this.stage.vars.surfacesP2,
              this.vars.CurrentSurface - 1
            ) - 1
          ),
          this.itemOf(
            this.stage.vars.worldDataZ,
            this.itemOf(
              this.stage.vars.surfacesP2,
              this.vars.CurrentSurface - 1
            ) - 1
          ),
          this.itemOf(
            this.stage.vars.worldDataX,
            this.itemOf(
              this.stage.vars.surfacesP3,
              this.vars.CurrentSurface - 1
            ) - 1
          ),
          this.itemOf(
            this.stage.vars.worldDataY,
            this.itemOf(
              this.stage.vars.surfacesP3,
              this.vars.CurrentSurface - 1
            ) - 1
          ),
          this.itemOf(
            this.stage.vars.worldDataZ,
            this.itemOf(
              this.stage.vars.surfacesP3,
              this.vars.CurrentSurface - 1
            ) - 1
          )
        );
        if (this.toNumber(this.vars.Intersects) === 1) {
          if (
            !(this.compare(this.vars.T, 0) < 0) &&
            this.compare(this.vars.T, this.vars.DistanceToFloor) < 0
          ) {
            this.vars.DistanceToFloor = this.vars.T;
            this.vars.FloorSurface = this.vars.CurrentSurface;
          }
        }
      }
      this.vars.CurrentSurface++;
      yield;
    }
  }

  *testForCollisionIn(ax, bx, ay, by, az, bz) {
    this.vars.Return = 0;
    this.vars.CurrentBox = 1;
    while (
      !(
        this.compare(
          this.vars.CurrentBox,
          this.stage.vars.collisionBoxesX1.length
        ) > 0 || this.toNumber(this.vars.Return) === 1
      )
    ) {
      yield* this.intCuboidsIntersect(
        ax,
        bx,
        ay,
        by,
        az,
        bz,
        this.itemOf(this.stage.vars.collisionBoxesX1, this.vars.CurrentBox - 1),
        this.itemOf(this.stage.vars.collisionBoxesX2, this.vars.CurrentBox - 1),
        this.itemOf(this.stage.vars.collisionBoxesY1, this.vars.CurrentBox - 1),
        this.itemOf(this.stage.vars.collisionBoxesY2, this.vars.CurrentBox - 1),
        this.itemOf(this.stage.vars.collisionBoxesZ1, this.vars.CurrentBox - 1),
        this.itemOf(this.stage.vars.collisionBoxesZ2, this.vars.CurrentBox - 1)
      );
      if (this.compare(this.vars.CurrentCollision, 0 === "") === 0) {
        this.vars.Return = 1;
      }
      this.vars.CurrentBox++;
      yield;
    }
    if (this.toNumber(this.vars.Return) === 0) {
      this.vars.CurrentBox = 1;
      while (
        !(
          this.compare(
            this.vars.CurrentBox,
            this.stage.vars.collisionBoxesRXData.length / 6
          ) > 0 || this.toNumber(this.vars.Return) === 1
        )
      ) {
        yield* this.intInsersectsCuboidConvexHull(
          ax,
          bx,
          ay,
          by,
          az,
          bz,
          this.vars.CurrentBox
        );
        if (this.toNumber(this.vars.CurrentCollision) === 1) {
          this.vars.Return = 1;
        }
        this.vars.CurrentBox++;
        yield;
      }
      if (this.toNumber(this.vars.Return) === 1) {
        this.vars.CurrentBox = 0 - this.toNumber(this.vars.CurrentBox);
      } else {
        this.vars.CurrentBox = 0;
        this.vars.CurrentSphere = 1;
        while (
          !(
            this.compare(
              this.vars.CurrentSphere,
              this.stage.vars.collisionSpheresX.length
            ) > 0 || this.toNumber(this.vars.Return) === 1
          )
        ) {
          yield* this.intIntersectsCuboidSphere(
            ax,
            bx,
            ay,
            by,
            az,
            bz,
            this.itemOf(
              this.stage.vars.collisionSpheresX,
              this.vars.CurrentSphere - 1
            ),
            this.itemOf(
              this.stage.vars.collisionSpheresY,
              this.vars.CurrentSphere - 1
            ),
            this.itemOf(
              this.stage.vars.collisionSpheresZ,
              this.vars.CurrentSphere - 1
            ),
            this.itemOf(
              this.stage.vars.collisionSpheresRadius,
              this.vars.CurrentSphere - 1
            )
          );
          if (this.toNumber(this.vars.CurrentCollision) === 1) {
            this.vars.Return = 1;
          }
          this.vars.CurrentSphere++;
          yield;
        }
      }
    }
  }

  *intCuboidContainsPoint(x, y, z, x1, y1, z1, x2, y2, z2) {
    this.vars.CurrentCollision =
      this.compare(x, x1) > 0 &&
      this.compare(x, x2) < 0 &&
      this.compare(y, y1) > 0 &&
      this.compare(y, y2) < 0 &&
      this.compare(z, z1) > 0 &&
      this.compare(z, z2) < 0;
  }

  *intCuboidsIntersect(ax, bx, ay, by, az, bz, cx, dx, cy, dy, cz, dz) {
    this.vars.CurrentCollision = !(
      this.compare(ax, dx) > 0 ||
      this.compare(bx, cx) < 0 ||
      this.compare(ay, dy) > 0 ||
      this.compare(by, cy) < 0 ||
      this.compare(az, dz) > 0 ||
      this.compare(bz, cz) < 0
    );
  }

  *intInsersectsCuboidConvexHull(x1, x2, y1, y2, z1, z2, hull) {
    yield* this.int2IntersectsCuboidConvexHull(
      x1,
      x2,
      y1,
      y2,
      z1,
      z2,
      (this.toNumber(hull) - 1) * 8,
      (this.toNumber(hull) - 1) * 3
    );
  }

  *int2IntersectsCuboidConvexHull(x1, x2, y1, y2, z1, z2, pIndex, nIndex) {
    this.vars.Min1 = this.itemOf(
      this.stage.vars.collisionBoxesRXData,
      this.toNumber(pIndex)
    );
    this.vars.Max1 = this.vars.Min1;
    this.vars.Temp1 = 2;
    for (let i = 0; i < 7; i++) {
      this.vars.Temp2 = this.itemOf(
        this.stage.vars.collisionBoxesRXData,
        this.toNumber(pIndex) + this.toNumber(this.vars.Temp1) - 1
      );
      if (this.compare(this.vars.Temp2, this.vars.Min1) < 0) {
        this.vars.Min1 = this.vars.Temp2;
      } else {
        if (this.compare(this.vars.Temp2, this.vars.Max1) > 0) {
          this.vars.Max1 = this.vars.Temp2;
        }
      }
      this.vars.Temp1++;
      yield;
    }
    if (
      this.compare(x1, this.vars.Max1) > 0 ||
      this.compare(x2, this.vars.Min1) < 0
    ) {
      this.vars.CurrentCollision = 0;
    } else {
      this.vars.Min1 = this.itemOf(
        this.stage.vars.collisionBoxesRYData,
        this.toNumber(pIndex)
      );
      this.vars.Max1 = this.vars.Min1;
      this.vars.Temp1 = 2;
      for (let i = 0; i < 7; i++) {
        this.vars.Temp2 = this.itemOf(
          this.stage.vars.collisionBoxesRYData,
          this.toNumber(pIndex) + this.toNumber(this.vars.Temp1) - 1
        );
        if (this.compare(this.vars.Temp2, this.vars.Min1) < 0) {
          this.vars.Min1 = this.vars.Temp2;
        } else {
          if (this.compare(this.vars.Temp2, this.vars.Max1) > 0) {
            this.vars.Max1 = this.vars.Temp2;
          }
        }
        this.vars.Temp1++;
        yield;
      }
      if (
        this.compare(y1, this.vars.Max1) > 0 ||
        this.compare(y2, this.vars.Min1) < 0
      ) {
        this.vars.CurrentCollision = 0;
      } else {
        this.vars.Min1 = this.itemOf(
          this.stage.vars.collisionBoxesRZData,
          this.toNumber(pIndex)
        );
        this.vars.Max1 = this.vars.Min1;
        this.vars.Temp1 = 2;
        for (let i = 0; i < 7; i++) {
          this.vars.Temp2 = this.itemOf(
            this.stage.vars.collisionBoxesRZData,
            this.toNumber(pIndex) + this.toNumber(this.vars.Temp1) - 1
          );
          if (this.compare(this.vars.Temp2, this.vars.Min1) < 0) {
            this.vars.Min1 = this.vars.Temp2;
          } else {
            if (this.compare(this.vars.Temp2, this.vars.Max1) > 0) {
              this.vars.Max1 = this.vars.Temp2;
            }
          }
          this.vars.Temp1++;
          yield;
        }
        if (
          this.compare(z1, this.vars.Max1) > 0 ||
          this.compare(z2, this.vars.Min1) < 0
        ) {
          this.vars.CurrentCollision = 0;
        } else {
          yield* this.intDoLineTest(
            x1,
            x2,
            y1,
            y2,
            z1,
            z2,
            this.itemOf(
              this.stage.vars.collisionBoxesRN0,
              this.toNumber(nIndex)
            ),
            this.itemOf(
              this.stage.vars.collisionBoxesRN1,
              this.toNumber(nIndex)
            ),
            this.itemOf(
              this.stage.vars.collisionBoxesRN2,
              this.toNumber(nIndex)
            ),
            this.toNumber(pIndex) + 1,
            this.toNumber(pIndex) + 2
          );
          if (
            this.compare(this.vars.Min2, this.vars.Max1) > 0 ||
            this.compare(this.vars.Max2, this.vars.Min1) < 0
          ) {
            this.vars.CurrentCollision = 0;
          } else {
            yield* this.intDoLineTest(
              x1,
              x2,
              y1,
              y2,
              z1,
              z2,
              this.itemOf(
                this.stage.vars.collisionBoxesRN0,
                this.toNumber(nIndex) + 1
              ),
              this.itemOf(
                this.stage.vars.collisionBoxesRN1,
                this.toNumber(nIndex) + 1
              ),
              this.itemOf(
                this.stage.vars.collisionBoxesRN2,
                this.toNumber(nIndex) + 1
              ),
              this.toNumber(pIndex) + 1,
              this.toNumber(pIndex) + 3
            );
            if (
              this.compare(this.vars.Min2, this.vars.Max1) > 0 ||
              this.compare(this.vars.Max2, this.vars.Min1) < 0
            ) {
              this.vars.CurrentCollision = 0;
            } else {
              yield* this.intDoLineTest(
                x1,
                x2,
                y1,
                y2,
                z1,
                z2,
                this.itemOf(
                  this.stage.vars.collisionBoxesRN0,
                  this.toNumber(nIndex) + 2
                ),
                this.itemOf(
                  this.stage.vars.collisionBoxesRN1,
                  this.toNumber(nIndex) + 2
                ),
                this.itemOf(
                  this.stage.vars.collisionBoxesRN2,
                  this.toNumber(nIndex) + 2
                ),
                this.toNumber(pIndex) + 1,
                this.toNumber(pIndex) + 5
              );
              if (
                this.compare(this.vars.Min2, this.vars.Max1) > 0 ||
                this.compare(this.vars.Max2, this.vars.Min1) < 0
              ) {
                this.vars.CurrentCollision = 0;
              } else {
                this.vars.CurrentCollision = 1;
              }
            }
          }
        }
      }
    }
  }

  *intDoLineTest(x1, x2, y1, y2, z1, z2, n0, n1, n2, p1, p2) {
    this.vars.Min1 =
      this.toNumber(x1) * this.toNumber(n0) +
      (this.toNumber(y1) * this.toNumber(n1) +
        this.toNumber(z1) * this.toNumber(n2));
    this.vars.Max1 = this.vars.Min1;
    yield* this.intAdjustMinAndMax(
      this.toNumber(x1) * this.toNumber(n0) +
        (this.toNumber(y1) * this.toNumber(n1) +
          this.toNumber(z2) * this.toNumber(n2))
    );
    yield* this.intAdjustMinAndMax(
      this.toNumber(x1) * this.toNumber(n0) +
        (this.toNumber(y2) * this.toNumber(n1) +
          this.toNumber(z1) * this.toNumber(n2))
    );
    yield* this.intAdjustMinAndMax(
      this.toNumber(x1) * this.toNumber(n0) +
        (this.toNumber(y2) * this.toNumber(n1) +
          this.toNumber(z2) * this.toNumber(n2))
    );
    yield* this.intAdjustMinAndMax(
      this.toNumber(x2) * this.toNumber(n0) +
        (this.toNumber(y1) * this.toNumber(n1) +
          this.toNumber(z1) * this.toNumber(n2))
    );
    yield* this.intAdjustMinAndMax(
      this.toNumber(x2) * this.toNumber(n0) +
        (this.toNumber(y1) * this.toNumber(n1) +
          this.toNumber(z2) * this.toNumber(n2))
    );
    yield* this.intAdjustMinAndMax(
      this.toNumber(x2) * this.toNumber(n0) +
        (this.toNumber(y2) * this.toNumber(n1) +
          this.toNumber(z1) * this.toNumber(n2))
    );
    yield* this.intAdjustMinAndMax(
      this.toNumber(x2) * this.toNumber(n0) +
        (this.toNumber(y2) * this.toNumber(n1) +
          this.toNumber(z2) * this.toNumber(n2))
    );
    this.vars.Temp1 =
      this.toNumber(this.itemOf(this.stage.vars.collisionBoxesRXData, p1 - 1)) *
        this.toNumber(n0) +
      (this.toNumber(
        this.itemOf(this.stage.vars.collisionBoxesRYData, p1 - 1)
      ) *
        this.toNumber(n1) +
        this.toNumber(
          this.itemOf(this.stage.vars.collisionBoxesRZData, p1 - 1)
        ) *
          this.toNumber(n2));
    this.vars.Temp2 =
      this.toNumber(this.itemOf(this.stage.vars.collisionBoxesRXData, p2 - 1)) *
        this.toNumber(n0) +
      (this.toNumber(
        this.itemOf(this.stage.vars.collisionBoxesRYData, p2 - 1)
      ) *
        this.toNumber(n1) +
        this.toNumber(
          this.itemOf(this.stage.vars.collisionBoxesRZData, p2 - 1)
        ) *
          this.toNumber(n2));
    if (this.compare(this.vars.Temp1, this.vars.Temp2) > 0) {
      this.vars.Min2 = this.vars.Temp2;
      this.vars.Max2 = this.vars.Temp1;
    } else {
      this.vars.Min2 = this.vars.Temp1;
      this.vars.Max2 = this.vars.Temp2;
    }
  }

  *intAdjustMinAndMax(value) {
    if (this.compare(value, this.vars.Min1) < 0) {
      this.vars.Min1 = value;
    } else {
      if (this.compare(value, this.vars.Max1) > 0) {
        this.vars.Max1 = value;
      }
    }
  }

  *intIntersectsCuboidSphere(x1, x2, y1, y2, z1, z2, sx, sy, sz, radius) {
    this.vars.DistSquared = 0;
    if (this.compare(sx, x1) < 0) {
      this.vars.DistSquared +=
        (this.toNumber(sx) - this.toNumber(x1)) *
        (this.toNumber(sx) - this.toNumber(x1));
    } else {
      if (this.compare(sx, x2) > 0) {
        this.vars.DistSquared +=
          (this.toNumber(sx) - this.toNumber(x2)) *
          (this.toNumber(sx) - this.toNumber(x2));
      }
    }
    if (this.compare(sy, y1) < 0) {
      this.vars.DistSquared +=
        (this.toNumber(sy) - this.toNumber(y1)) *
        (this.toNumber(sy) - this.toNumber(y1));
    } else {
      if (this.compare(sy, y2) > 0) {
        this.vars.DistSquared +=
          (this.toNumber(sy) - this.toNumber(y2)) *
          (this.toNumber(sy) - this.toNumber(y2));
      }
    }
    if (this.compare(sz, z1) < 0) {
      this.vars.DistSquared +=
        (this.toNumber(sz) - this.toNumber(z1)) *
        (this.toNumber(sz) - this.toNumber(z1));
    } else {
      if (this.compare(sz, z2) > 0) {
        this.vars.DistSquared +=
          (this.toNumber(sz) - this.toNumber(z2)) *
          (this.toNumber(sz) - this.toNumber(z2));
      }
    }
    this.vars.CurrentCollision = !(
      this.compare(
        this.vars.DistSquared,
        this.toNumber(radius) * this.toNumber(radius)
      ) > 0
    );
  }

  *completeInit() {
    this.vars.ForwardsVel = 0;
    this.vars.SidewaysVel = 0;
    this.vars.VerticalVel = 0;
    this.vars.CharY =
      this.toNumber(this.stage.vars.cameraY) -
      this.toNumber(this.vars.ConstPlayerFullHeight);
    this.vars.Action = -1;
    this.vars.CrouchPressed = 0;
    this.vars.OldMouseDown = 0;
    this.vars.Acceleration = this.vars.ConstPlayerFullAcceleration;
    this.vars.PlayerHeight = this.vars.ConstPlayerFullHeight;
    this.vars.OnGround = 1;
  }

  *whenIReceiveSystemPhysicsTick() {
    yield* this.getInput();
  }

  *getInput() {
    this.vars.ForwardsVel = this.toNumber(this.vars.ForwardsVel) * 0.7;
    this.vars.SidewaysVel = this.toNumber(this.vars.SidewaysVel) * 0.7;
    if (this.keyPressed("c")) {
      if (this.toNumber(this.vars.CrouchPressed) === 0) {
        this.vars.CrouchPressed = 1;
        this.vars.Acceleration = this.vars.ConstPlayerCrouchAcceleration;
        this.vars.ActionStart = this.timer;
        this.vars.Action = 1;
      }
    } else {
      if (this.toNumber(this.vars.CrouchPressed) === 1) {
        yield* this.testForCollisionIn(
          this.stage.vars.cameraX,
          this.stage.vars.cameraX,
          this.toNumber(this.vars.CharY) + 1,
          this.toNumber(this.vars.CharY) +
            this.toNumber(this.vars.ConstPlayerFullHeight),
          this.stage.vars.cameraZ,
          this.stage.vars.cameraZ
        );
        if (this.toNumber(this.vars.Return) === 0) {
          this.vars.CrouchPressed = 0;
          this.vars.Acceleration = this.vars.ConstPlayerFullAcceleration;
          this.vars.ActionStart = this.timer;
          this.vars.Action = 2;
        }
      }
    }
    if (
      this.keyPressed("space") &&
      this.toNumber(this.vars.Jumping) === 0 &&
      this.toNumber(this.vars.CrouchPressed) === 0
    ) {
      this.vars.VerticalVel = this.vars.ConstPlayerJumpStartSpeed;
      this.vars.Jumping = 1;
    }
    if (this.keyPressed("w")) {
      this.vars.ForwardsVel +=
        this.toNumber(this.vars.Acceleration) *
        this.toNumber(this.stage.vars.deltaTime);
    }
    if (this.keyPressed("s")) {
      this.vars.ForwardsVel +=
        (0 - this.toNumber(this.vars.Acceleration)) *
        this.toNumber(this.stage.vars.deltaTime);
    }
    if (this.keyPressed("d")) {
      this.vars.SidewaysVel +=
        this.toNumber(this.vars.Acceleration) *
        this.toNumber(this.stage.vars.deltaTime);
    }
    if (this.keyPressed("a")) {
      this.vars.SidewaysVel +=
        (0 - this.toNumber(this.vars.Acceleration)) *
        this.toNumber(this.stage.vars.deltaTime);
    }
    if (this.toNumber(this.stage.vars.defaultControls) === 1) {
      if (this.keyPressed("up arrow")) {
        if (this.compare(this.stage.vars.cameraRotY, 70) < 0) {
          this.stage.vars.cameraRotY +=
            this.toNumber(this.vars.ConstArrowsRotateSpeed) *
            this.toNumber(this.stage.vars.deltaTime);
          this.stage.vars.updateNeeded = 1;
        }
      }
      if (this.keyPressed("down arrow")) {
        if (this.compare(this.stage.vars.cameraRotY, -70) > 0) {
          this.stage.vars.cameraRotY +=
            0 -
            this.toNumber(this.vars.ConstArrowsRotateSpeed) *
              this.toNumber(this.stage.vars.deltaTime);
          this.stage.vars.updateNeeded = 1;
        }
      }
      if (this.keyPressed("right arrow")) {
        this.stage.vars.cameraRotX +=
          0 -
          this.toNumber(this.vars.ConstArrowsRotateSpeed) *
            this.toNumber(this.stage.vars.deltaTime);
        this.stage.vars.updateNeeded = 1;
      }
      if (this.keyPressed("left arrow")) {
        this.stage.vars.cameraRotX +=
          this.toNumber(this.vars.ConstArrowsRotateSpeed) *
          this.toNumber(this.stage.vars.deltaTime);
        this.stage.vars.updateNeeded = 1;
      }
    } else {
      if (this.mouse.down) {
        if (this.toNumber(this.vars.OldMouseDown) === 0) {
          this.vars.OldMouseDown = 1;
          this.vars.MouseDownX = this.mouse.x;
          this.vars.MouseDownY = this.mouse.y;
          this.vars.OldCameraRotX = this.stage.vars.cameraRotX;
          this.vars.OldCameraRotY = this.stage.vars.cameraRotY;
        } else {
          if (
            !(
              this.compare(this.mouse.x, this.vars.MouseDownX) === 0 &&
              this.compare(this.mouse.y, this.vars.MouseDownY) === 0
            )
          ) {
            this.stage.vars.cameraRotX =
              this.toNumber(this.vars.OldCameraRotX) -
              (this.mouse.x - this.toNumber(this.vars.MouseDownX)) /
                this.toNumber(this.vars.ConstMouseSensitivity);
            this.vars.Temp1 =
              this.toNumber(this.vars.OldCameraRotY) +
              (this.mouse.y - this.toNumber(this.vars.MouseDownY)) /
                this.toNumber(this.vars.ConstMouseSensitivity);
            if (this.compare(this.vars.Temp1, 70) < 0) {
              if (this.compare(this.vars.Temp1, -70) > 0) {
                this.stage.vars.cameraRotY = this.vars.Temp1;
              } else {
                this.stage.vars.cameraRotY = -70;
              }
            } else {
              this.stage.vars.cameraRotY = 70;
            }
            this.stage.vars.updateNeeded = 1;
            this.vars.MouseDownX = this.mouse.x;
            this.vars.MouseDownY = this.mouse.y;
            this.vars.OldCameraRotX = this.stage.vars.cameraRotX;
            this.vars.OldCameraRotY = this.stage.vars.cameraRotY;
          }
        }
      } else {
        this.vars.OldMouseDown = 0;
      }
    }
    if (this.compare(Math.abs(this.toNumber(this.vars.ForwardsVel)), 0.1) > 0) {
      this.vars.NewX =
        this.toNumber(this.stage.vars.cameraX) -
        this.toNumber(this.vars.ForwardsVel) *
          (Math.sin(this.degToRad(this.toNumber(this.stage.vars.cameraRotX))) *
            (20 * this.toNumber(this.stage.vars.deltaTime)));
      this.vars.NewZ =
        this.toNumber(this.stage.vars.cameraZ) +
        this.toNumber(this.vars.ForwardsVel) *
          (Math.cos(this.degToRad(this.toNumber(this.stage.vars.cameraRotX))) *
            (20 * this.toNumber(this.stage.vars.deltaTime)));
      yield* this.safeTestForCollisionIn(
        this.stage.vars.cameraX,
        this.vars.NewX,
        this.toNumber(this.vars.CharY) + 1,
        this.toNumber(this.vars.CharY) + this.toNumber(this.vars.PlayerHeight),
        this.stage.vars.cameraZ,
        this.vars.NewZ
      );
      if (this.toNumber(this.vars.Return) === 0) {
        this.stage.vars.cameraX = this.vars.NewX;
        this.stage.vars.cameraZ = this.vars.NewZ;
        this.vars.WalkFrame++;
        this.stage.vars.updateNeeded = 1;
      } else {
        this.vars.Increment = 2;
        while (
          !(
            this.compare(
              this.vars.Increment,
              Math.abs(this.toNumber(this.vars.ForwardsVel)) *
                this.toNumber(this.stage.vars.deltaTime) *
                20 +
                10
            ) > 0 || this.toNumber(this.vars.Return) === 0
          )
        ) {
          yield* this.safeTestForCollisionIn(
            this.stage.vars.cameraX,
            this.vars.NewX,
            this.toNumber(this.vars.CharY) + this.toNumber(this.vars.Increment),
            this.toNumber(this.vars.CharY) +
              this.toNumber(this.vars.PlayerHeight),
            this.stage.vars.cameraZ,
            this.vars.NewZ
          );
          this.vars.Increment += 2;
          yield;
        }
        if (this.toNumber(this.vars.Return) === 0) {
          this.stage.vars.cameraX = this.vars.NewX;
          this.stage.vars.cameraZ = this.vars.NewZ;
          this.vars.CharY += this.toNumber(this.vars.Increment);
          this.vars.WalkFrame++;
          this.stage.vars.updateNeeded = 1;
        } else {
          this.vars.ForwardsVel = 0;
        }
      }
    } else {
      this.vars.ForwardsVel = 0;
    }
    if (this.compare(Math.abs(this.toNumber(this.vars.SidewaysVel)), 0.1) > 0) {
      this.vars.NewX =
        this.toNumber(this.stage.vars.cameraX) +
        this.toNumber(this.vars.SidewaysVel) *
          (Math.cos(this.degToRad(this.toNumber(this.stage.vars.cameraRotX))) *
            (20 * this.toNumber(this.stage.vars.deltaTime)));
      this.vars.NewZ =
        this.toNumber(this.stage.vars.cameraZ) +
        this.toNumber(this.vars.SidewaysVel) *
          (Math.sin(this.degToRad(this.toNumber(this.stage.vars.cameraRotX))) *
            (20 * this.toNumber(this.stage.vars.deltaTime)));
      yield* this.safeTestForCollisionIn(
        this.stage.vars.cameraX,
        this.vars.NewX,
        this.toNumber(this.vars.CharY) + 1,
        this.toNumber(this.vars.CharY) + this.toNumber(this.vars.PlayerHeight),
        this.stage.vars.cameraZ,
        this.vars.NewZ
      );
      if (this.toNumber(this.vars.Return) === 0) {
        this.stage.vars.cameraX = this.vars.NewX;
        this.stage.vars.cameraZ = this.vars.NewZ;
        this.stage.vars.updateNeeded = 1;
        if (this.toNumber(this.vars.ForwardsVel) === 0) {
          this.vars.WalkFrame++;
        }
      } else {
        this.vars.Increment = 2;
        while (
          !(
            this.compare(
              this.vars.Increment,
              Math.abs(this.toNumber(this.vars.SidewaysVel)) *
                this.toNumber(this.stage.vars.deltaTime) *
                20 +
                10
            ) > 0 || this.toNumber(this.vars.Return) === 0
          )
        ) {
          yield* this.safeTestForCollisionIn(
            this.stage.vars.cameraX,
            this.vars.NewX,
            this.toNumber(this.vars.CharY) + this.toNumber(this.vars.Increment),
            this.toNumber(this.vars.CharY) +
              this.toNumber(this.vars.PlayerHeight),
            this.stage.vars.cameraZ,
            this.vars.NewZ
          );
          this.vars.Increment += 2;
          yield;
        }
        if (this.toNumber(this.vars.Return) === 0) {
          this.stage.vars.cameraX = this.vars.NewX;
          this.stage.vars.cameraZ = this.vars.NewZ;
          this.vars.CharY += this.toNumber(this.vars.Increment);
          this.stage.vars.updateNeeded = 1;
          if (this.toNumber(this.vars.ForwardsVel) === 0) {
            this.vars.WalkFrame++;
          }
        } else {
          this.vars.SidewaysVel = 0;
        }
      }
    } else {
      this.vars.SidewaysVel = 0;
    }
    if (this.compare(this.vars.VerticalVel, 0) > 0) {
      yield* this.testForCollisionIn(
        this.stage.vars.cameraX,
        this.stage.vars.cameraX,
        this.stage.vars.cameraY,
        this.toNumber(this.stage.vars.cameraY) +
          this.toNumber(this.vars.VerticalVel),
        this.stage.vars.cameraZ,
        this.stage.vars.cameraZ
      );
      if (this.toNumber(this.vars.Return) === 0) {
        this.vars.VerticalVel +=
          0 - this.toNumber(this.vars.ConstGravityStrength);
        this.vars.OnGround = 0;
      } else {
        this.vars.VerticalVel = 0;
      }
    } else {
      yield* this.testForCollisionIn(
        this.stage.vars.cameraX,
        this.stage.vars.cameraX,
        this.toNumber(this.vars.CharY) +
          this.toNumber(this.vars.VerticalVel) -
          1,
        this.toNumber(this.vars.CharY) - 1,
        this.stage.vars.cameraZ,
        this.stage.vars.cameraZ
      );
      if (this.toNumber(this.vars.Return) === 0) {
        if (
          this.compare(
            this.vars.VerticalVel,
            this.vars.ConstTerminalFallVelocity
          ) > 0
        ) {
          this.vars.VerticalVel +=
            0 - this.toNumber(this.vars.ConstGravityStrength);
        } else {
          this.vars.VerticalVel = this.vars.ConstTerminalFallVelocity;
        }
        this.vars.OnGround = 0;
      } else {
        if (this.toNumber(this.vars.OnGround) === 0) {
          this.vars.OnGround = 1;
          if (this.compare(this.vars.VerticalVel, -4) < 0) {
            this.vars.WalkFrame = 0;
          }
          this.vars.VerticalVel = 0;
          this.vars.Jumping = 0;
          if (this.compare(this.vars.CurrentBox, 0) > 0) {
            this.vars.Temp1 = this.itemOf(
              this.stage.vars.collisionBoxesY2,
              this.toNumber(this.vars.CurrentBox) - 2
            );
            if (
              this.compare(
                this.vars.Temp1,
                this.toNumber(this.vars.CharY) + 10
              ) < 0
            ) {
              this.vars.OldCharY = this.vars.CharY;
              this.vars.CharY = this.vars.Temp1;
            }
          } else {
            this.vars.OldCharY = this.vars.CharY;
          }
          if (!(this.compare(this.vars.OldCharY, this.vars.CharY) === 0)) {
            this.stage.vars.updateNeeded = 1;
          }
        }
      }
    }
    if (this.compare(Math.abs(this.toNumber(this.vars.VerticalVel)), 0.1) > 0) {
      this.vars.CharY += this.toNumber(this.vars.VerticalVel);
      this.stage.vars.updateNeeded = 1;
    } else {
      null;
    }
    if (this.toNumber(this.vars.Action) === 1) {
      if (
        this.compare(this.timer - this.toNumber(this.vars.ActionStart), 0.15) <
        0
      ) {
        this.vars.PlayerHeight =
          this.toNumber(this.vars.ConstPlayerFullHeight) -
          (this.toNumber(this.vars.ConstPlayerFullHeight) -
            this.toNumber(this.vars.ConstPlayerCrouchHeight)) *
            ((this.timer - this.toNumber(this.vars.ActionStart)) / 0.15);
        this.stage.vars.updateNeeded = 1;
      } else {
        this.vars.PlayerHeight = this.vars.ConstPlayerCrouchHeight;
        this.stage.vars.updateNeeded = 1;
      }
    } else {
      if (this.toNumber(this.vars.Action) === 2) {
        if (
          this.compare(
            this.timer - this.toNumber(this.vars.ActionStart),
            0.15
          ) < 0
        ) {
          this.vars.PlayerHeight =
            this.toNumber(this.vars.ConstPlayerCrouchHeight) +
            (this.toNumber(this.vars.ConstPlayerFullHeight) -
              this.toNumber(this.vars.ConstPlayerCrouchHeight)) *
              ((this.timer - this.toNumber(this.vars.ActionStart)) / 0.15);
          this.stage.vars.updateNeeded = 1;
        } else {
          this.vars.PlayerHeight = this.vars.ConstPlayerFullHeight;
          this.stage.vars.updateNeeded = 1;
        }
      } else {
        null;
      }
    }
    if (this.toNumber(this.vars.WalkFrame) % 12 === 0) {
      yield* this.getSurfaceBelow(1000);
      if (this.toNumber(this.vars.FloorSurface) === -1) {
        if (
          this.toNumber(this.itemOf(this.stage.vars.renderSettings, 13)) === 1
        ) {
          yield* this.startSound(
            this.random(
              this.toNumber(this.vars.ConstGroundFirstStepSound),
              this.toNumber(this.vars.ConstGroundLastStepSound)
            )
          );
        }
      } else {
        if (
          this.compare(
            this.itemOf(
              this.stage.vars.texturesSoundStart,
              this.itemOf(
                this.stage.vars.surfacesTexture,
                this.vars.FloorSurface - 1
              ) - 1
            ),
            -1
          ) > 0
        ) {
          yield* this.startSound(
            this.random(
              this.toNumber(
                this.itemOf(
                  this.stage.vars.texturesSoundStart,
                  this.itemOf(
                    this.stage.vars.surfacesTexture,
                    this.vars.FloorSurface - 1
                  ) - 1
                )
              ),
              this.toNumber(
                this.itemOf(
                  this.stage.vars.texturesSoundEnd,
                  this.itemOf(
                    this.stage.vars.surfacesTexture,
                    this.vars.FloorSurface - 1
                  ) - 1
                )
              )
            )
          );
        }
      }
      this.vars.WalkFrame++;
    }
    if (this.toNumber(this.stage.vars.updateNeeded) === 1) {
      this.stage.vars.cameraY =
        this.toNumber(this.vars.CharY) + this.toNumber(this.vars.PlayerHeight);
    }
  }

  *intersectTriangle(
    o0,
    o1,
    o2,
    d0,
    d1,
    d2,
    a0,
    a1,
    a2,
    b0,
    b1,
    b2,
    c0,
    c1,
    c2
  ) {
    this.vars.E10 = this.toNumber(b0) - this.toNumber(a0);
    this.vars.E11 = this.toNumber(b1) - this.toNumber(a1);
    this.vars.E12 = this.toNumber(b2) - this.toNumber(a2);
    this.vars.E20 = this.toNumber(c0) - this.toNumber(a0);
    this.vars.E21 = this.toNumber(c1) - this.toNumber(a1);
    this.vars.E22 = this.toNumber(c2) - this.toNumber(a2);
    this.vars.Pvec0 =
      this.toNumber(d1) * this.toNumber(this.vars.E22) -
      this.toNumber(d2) * this.toNumber(this.vars.E21);
    this.vars.Pvec1 =
      this.toNumber(d2) * this.toNumber(this.vars.E20) -
      this.toNumber(d0) * this.toNumber(this.vars.E22);
    this.vars.Pvec2 =
      this.toNumber(d0) * this.toNumber(this.vars.E21) -
      this.toNumber(d1) * this.toNumber(this.vars.E20);
    this.vars.Determiner =
      this.toNumber(this.vars.E10) * this.toNumber(this.vars.Pvec0) +
      (this.toNumber(this.vars.E11) * this.toNumber(this.vars.Pvec1) +
        this.toNumber(this.vars.E12) * this.toNumber(this.vars.Pvec2));
    if (this.compare(this.vars.Determiner, this.vars.ConstEpsilon) < 0) {
      this.vars.Intersects = 0;
    } else {
      this.vars.InvertedDeterminer = 1 / this.toNumber(this.vars.Determiner);
      this.vars.Tvec0 = this.toNumber(o0) - this.toNumber(a0);
      this.vars.Tvec1 = this.toNumber(o1) - this.toNumber(a1);
      this.vars.Tvec2 = this.toNumber(o2) - this.toNumber(a2);
      this.vars.U =
        (this.toNumber(this.vars.Pvec0) * this.toNumber(this.vars.Tvec0) +
          (this.toNumber(this.vars.Pvec1) * this.toNumber(this.vars.Tvec1) +
            this.toNumber(this.vars.Pvec2) * this.toNumber(this.vars.Tvec2))) *
        this.toNumber(this.vars.InvertedDeterminer);
      if (
        this.compare(this.vars.U, 0) < 0 ||
        this.compare(this.vars.U, 1) > 0
      ) {
        this.vars.Intersects = 0;
      } else {
        this.vars.Qvec0 =
          this.toNumber(this.vars.Tvec1) * this.toNumber(this.vars.E12) -
          this.toNumber(this.vars.Tvec2) * this.toNumber(this.vars.E11);
        this.vars.Qvec1 =
          this.toNumber(this.vars.Tvec2) * this.toNumber(this.vars.E10) -
          this.toNumber(this.vars.Tvec0) * this.toNumber(this.vars.E12);
        this.vars.Qvec2 =
          this.toNumber(this.vars.Tvec0) * this.toNumber(this.vars.E11) -
          this.toNumber(this.vars.Tvec1) * this.toNumber(this.vars.E10);
        this.vars.V =
          (this.toNumber(d0) * this.toNumber(this.vars.Qvec0) +
            (this.toNumber(d1) * this.toNumber(this.vars.Qvec1) +
              this.toNumber(d2) * this.toNumber(this.vars.Qvec2))) *
          this.toNumber(this.vars.InvertedDeterminer);
        if (
          this.compare(this.vars.V, 0) < 0 ||
          this.compare(
            this.toNumber(this.vars.U) + this.toNumber(this.vars.V),
            1
          ) > 0
        ) {
          this.vars.Intersects = 0;
        } else {
          this.vars.T =
            (this.toNumber(this.vars.E20) * this.toNumber(this.vars.Qvec0) +
              (this.toNumber(this.vars.E21) * this.toNumber(this.vars.Qvec1) +
                this.toNumber(this.vars.E22) *
                  this.toNumber(this.vars.Qvec2))) *
            this.toNumber(this.vars.InvertedDeterminer);
          this.vars.Intersects = 1;
        }
      }
    }
  }
}
